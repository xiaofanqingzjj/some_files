

IS_RELEASE=false

IS_RELEASE=$1

#CI_BUILD_NO=$2

python3 update_version.py

# 定义 properties 文件的路径
PROPERTIES_FILE="version.properties"

# 函数：读取 properties 文件中的属性值
get_property() {
    local property_key=$1
    grep "^${property_key}=" "$PROPERTIES_FILE" | cut -d'=' -f2-
}

# 读取属性值
versionName=$(get_property "versionName")

rm -f bin/*

./gradlew clean

if $IS_RELEASE; then
  echo './gradlew app:assembleRelease'
  ./gradlew app:assembleRelease

  mv app/build/outputs/apk/aosp/release/app-aosp-release.apk app/build/outputs/apk/aosp/release/DualApp-${versionName}-release.apk
  cp app/build/outputs/apk/aosp/release/*.apk bin/
else
  echo './gradlew app:assembleDebug'
  ./gradlew app:assembleDebug
  mv app/build/outputs/apk/aosp/debug/app-aosp-debug.apk app/build/outputs/apk/aosp/debug/DualApp-${versionName}-debug.apk
  cp app/build/outputs/apk/aosp/debug/*.apk bin/
fi





