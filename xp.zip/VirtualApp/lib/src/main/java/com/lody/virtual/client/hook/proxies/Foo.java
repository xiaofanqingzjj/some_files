package com.lody.virtual.client.hook.proxies;

public class Foo {
}
