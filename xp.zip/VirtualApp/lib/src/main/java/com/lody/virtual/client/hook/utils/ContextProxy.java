package com.lody.virtual.client.hook.utils;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.Log;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.os.VUserHandle;

import java.io.File;

public class ContextProxy extends ContextWrapper {

    static final String TAG = "ContextProxy";

    public ContextProxy(Context org) {
        super(org);
    }

    @Override
    public File getExternalFilesDir(String type) {
        File file =  super.getExternalFilesDir(type);
        file = replaceFilePath(file, getPackageName(), appExtStoragePath());
        Log.i(TAG, "getExternalFilesDir type:" + type + ", file:" + file);
        return file;
    }


    @Override
    public File[] getExternalFilesDirs(String type) {
        File[] result =  super.getExternalFilesDirs(type);
        replaceFilePaths(result, getPackageName(), appExtStoragePath());
        Log.d(TAG, "getExternalFilesDirs");
        return result;
    }

    @Override
    public File getExternalCacheDir() {
        File file =  super.getExternalCacheDir();
        Log.d(TAG, "getExternalCacheDir");
        replaceFilePath(file, getPackageName(), appExtStoragePath());
        return file;
    }

    @Override
    public File[] getExternalCacheDirs() {
        Log.d(TAG, "getExternalCacheDirs");
        File[] result =  super.getExternalCacheDirs();
        replaceFilePaths(result, getPackageName(), appExtStoragePath());
        return result;
    }

    @Override
    public File[] getExternalMediaDirs() {
        Log.d(TAG, "getExternalCacheDirs");
        File[] result =  super.getExternalMediaDirs();
        replaceFilePaths(result, getPackageName(), appExtStoragePath());
        return result;
    }

    private String appExtStoragePath() {
        // <host-pkg-name>/virtual/0/<app-pkg-name>
        return VirtualCore.get().getContext().getPackageName() + File.separator + getVirtualAppExternalRelationPath(VUserHandle.myUserId(), getPackageName());
    }

    private static void replaceFilePaths(File[] files, String oldPath, String newPath) {
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                files[i] = replaceFilePath(files[i], oldPath, newPath);
            }
        }
    }

    private static String getVirtualAppExternalRelationPath(int userId, String packageName) {
        return "virtual" + File.separator + userId + File.separator + packageName + File.separator;
    }

    private static File replaceFilePath(File file, String oldPath, String newPath) {
        String absolutePath = file.getAbsolutePath();
        File resultPath =  absolutePath.contains(newPath) ? file : new File(absolutePath.replace(oldPath, newPath));
        Log.d(TAG, "replaceFilePath:" + file  + ", newPath:" + resultPath);
        return resultPath;
    }

}
