package com.lody.virtual.client.core;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.lody.virtual.R;
import com.lody.virtual.client.VClientImpl;
import com.lody.virtual.client.env.Constants;
import com.lody.virtual.client.fixer.ContextFixer;
import com.lody.virtual.client.hook.delegate.ComponentDelegate;
import com.lody.virtual.client.hook.delegate.PhoneInfoDelegate;
import com.lody.virtual.client.hook.delegate.TaskDescriptionDelegate;
import com.lody.virtual.client.ipc.ServiceManagerNative;
import com.lody.virtual.client.ipc.VActivityManager;
import com.lody.virtual.client.ipc.VPackageManager;
import com.lody.virtual.client.stub.VASettings;
import com.lody.virtual.helper.compat.BundleCompat;
import com.lody.virtual.helper.utils.BitmapUtils;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.os.VUserHandle;
import com.lody.virtual.remote.InstalledAppInfo;
import com.lody.virtual.server.interfaces.IUiCallback;
import com.lody.virtual.server.pm.VAppManager;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import me.weishu.reflection.Reflection;
import mirror.android.app.ActivityThread;

/**
 * @author Lody
 * @version 3.5
 */
public final class VirtualCore {

    static final String TAG = "VirtualCore";

    public static final int GET_HIDDEN_APP = 0x00000001;

    public static final String TAICHI_PACKAGE = "me.weishu.exp";

    @SuppressLint("StaticFieldLeak")
    private static VirtualCore gCore = new VirtualCore();
    private final int myUid = Process.myUid();
    /**
     * Client Package Manager
     */
    private PackageManager unHookPackageManager;
    /**
     * Host package name
     */
    private String hostPkgName;
    /**
     * ActivityThread instance
     */
    private Object mainThread;
    private Context context;
    /**
     * Main ProcessName
     */
    private String mainProcessName;
    /**
     * Real Process Name
     */
    private String processName;
    private ProcessType processType;
    private boolean isStartUp;
    private PackageInfo hostPkgInfo;
    private int systemPid;
    private ConditionVariable initLock = new ConditionVariable();
    private PhoneInfoDelegate phoneInfoDelegate;
    private ComponentDelegate componentDelegate;
    private TaskDescriptionDelegate taskDescriptionDelegate;

    private VirtualCore() {
    }

    public static VirtualCore get() {
        return gCore;
    }

    public static PackageManager getPM() {
        return get().getPackageManager();
    }

    public static Object mainThread() {
        return get().mainThread;
    }

    public ConditionVariable getInitLock() {
        return initLock;
    }

    public int myUid() {
        return myUid;
    }

    public int myUserId() {
        return VUserHandle.getUserId(myUid);
    }

    public ComponentDelegate getComponentDelegate() {
        return componentDelegate == null ? ComponentDelegate.EMPTY : componentDelegate;
    }

    public void setComponentDelegate(ComponentDelegate delegate) {
        this.componentDelegate = delegate;
    }

    public PhoneInfoDelegate getPhoneInfoDelegate() {
        return phoneInfoDelegate;
    }

    public void setPhoneInfoDelegate(PhoneInfoDelegate phoneInfoDelegate) {
        this.phoneInfoDelegate = phoneInfoDelegate;
    }

    public void setCrashHandler(CrashHandler handler) {
        VClientImpl.get().setCrashHandler(handler);
    }

    public TaskDescriptionDelegate getTaskDescriptionDelegate() {
        return taskDescriptionDelegate;
    }

    public void setTaskDescriptionDelegate(TaskDescriptionDelegate taskDescriptionDelegate) {
        this.taskDescriptionDelegate = taskDescriptionDelegate;
    }

    public int[] getGids() {
        return hostPkgInfo.gids;
    }

    public Context getContext() {
        return context;
    }

    public PackageManager getPackageManager() {
        return context.getPackageManager();
    }

    public String getHostPkg() {
        return hostPkgName;
    }

    public PackageManager getUnHookPackageManager() {
        return unHookPackageManager;
    }


    /**
     * 初始化虚拟机
     * @param context
     * @throws Throwable
     */
    public void startup(Context context) throws Throwable {
        if (!isStartUp) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                throw new IllegalStateException("VirtualCore.startup() must called in main thread.");
            }
            Reflection.unseal(context);


            VASettings.STUB_CP_AUTHORITY = context.getPackageName() + "." + VASettings.STUB_DEF_AUTHORITY;
            ServiceManagerNative.SERVICE_CP_AUTH = context.getPackageName() + "." + ServiceManagerNative.SERVICE_DEF_AUTH;

            this.context = context;

            mainThread = ActivityThread.currentActivityThread.call();

            unHookPackageManager = context.getPackageManager();

            hostPkgInfo = unHookPackageManager.getPackageInfo(context.getPackageName(), PackageManager.GET_PROVIDERS);

            // 判断当前的进程类型
            detectProcessType();

            Log.i(TAG, "startup mainProcessName:" + mainProcessName + ", processName:" + processName + ", processType:" + processType);

            // 根据进程类型hook各种系统服务
            InvocationStubManager invocationStubManager = InvocationStubManager.getInstance();
            invocationStubManager.init();
            invocationStubManager.injectAll();

            //修复context
            ContextFixer.fixContext(context);

            isStartUp = true;
            if (initLock != null) {
                initLock.open();
                initLock = null;
            }
        }
    }

    public void waitForEngine() {
        ServiceManagerNative.ensureServerStarted();
    }

    public boolean isEngineLaunched() {
        String engineProcessName = getEngineProcessName();
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningAppProcessInfo info : am.getRunningAppProcesses()) {
            if (info.processName.endsWith(engineProcessName)) {
                return true;
            }
        }
        return false;
    }

    public String getEngineProcessName() {
        return context.getString(R.string.engine_process_name);
    }

    public void initialize(VirtualInitializer initializer) {
        if (initializer == null) {
            throw new IllegalStateException("Initializer = NULL");
        }
        switch (processType) {
            case Main:
                initializer.onMainProcess();
                break;
            case VAppClient:
                initializer.onVirtualProcess();
                break;
            case Server:
                initializer.onServerProcess();
                break;
            case CHILD:
                initializer.onChildProcess();
                break;
        }
    }

    private void detectProcessType() {
        // Host package name
        hostPkgName = context.getApplicationInfo().packageName;
        // Main process name
        mainProcessName = context.getApplicationInfo().processName;
        // Current process name
        processName = ActivityThread.getProcessName.call(mainThread);
        if (processName.equals(mainProcessName)) {
            processType = ProcessType.Main;
        } else if (processName.endsWith(Constants.SERVER_PROCESS_NAME)) {
            processType = ProcessType.Server;
        } else if (VActivityManager.get().isAppProcess(processName)) {
            processType = ProcessType.VAppClient;
        } else {
            processType = ProcessType.CHILD;
        }
        if (isVAppProcess()) {
            systemPid = VActivityManager.get().getSystemPid();
        }
    }

    public boolean isVAppProcess() {
        return ProcessType.VAppClient == processType;
    }

    public boolean isMainProcess() {
        return ProcessType.Main == processType;
    }

    public boolean isChildProcess() {
        return ProcessType.CHILD == processType;
    }

    public boolean isServerProcess() {
        return ProcessType.Server == processType;
    }

    public String getProcessName() {
        return processName;
    }

    public String getMainProcessName() {
        return mainProcessName;
    }

    @Deprecated
    public void preOpt(String pkg) throws IOException {
        /*
        InstalledAppInfo info = getInstalledAppInfo(pkg, 0);
        if (info != null && !info.dependSystem) {
            DexFile.loadDex(info.apkPath, info.getOdexFile().getPath(), 0).close();
        }*/
    }


    public boolean isXposedEnabled() {
        return !VirtualCore.get().getContext().getFileStreamPath(".disable_xposed").exists();
    }


    public boolean isPackageLaunchable(String packageName) {
        InstalledAppInfo info = getInstalledAppInfo(packageName, 0);
        return info != null
                && getLaunchIntent(packageName, info.getInstalledUsers()[0]) != null;
    }

    public Intent getLaunchIntent(String packageName, int userId) {
        return VPackageManager.get().getLaunchIntent(context, packageName, userId);
    }



    public abstract static class UiCallback extends IUiCallback.Stub {
    }

    public void setUiCallback(Intent intent, IUiCallback callback) {
        if (callback != null) {
            Bundle bundle = new Bundle();
            BundleCompat.putBinder(bundle,  Constants.VA_UI_CALLBACK, callback.asBinder());
            intent.putExtra(Constants.VA_SENDER, bundle);
        }
    }

    public static IUiCallback getUiCallback(Intent intent) {
        if (intent == null) {
            return null;
        }
        // only for launch intent.
        if (!Intent.ACTION_MAIN.equals(intent.getAction())) {
            return null;
        }
        try {
            Bundle bundle = intent.getBundleExtra(Constants.VA_SENDER);
            if (bundle != null) {
                IBinder uicallbackToken = BundleCompat.getBinder(bundle, Constants.VA_UI_CALLBACK);
                return IUiCallback.Stub.asInterface(uicallbackToken);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    public InstalledAppInfo getInstalledAppInfo(String pkg, int flags) {
        return VAppManager.get().getInstalledAppInfo(pkg, flags);
    }

    public boolean isStartup() {
        return isStartUp;
    }

    public Resources getResources(String pkg) throws Resources.NotFoundException {
        InstalledAppInfo installedAppInfo = getInstalledAppInfo(pkg, 0);
        if (installedAppInfo != null) {
            AssetManager assets = mirror.android.content.res.AssetManager.ctor.newInstance();
            mirror.android.content.res.AssetManager.addAssetPath.call(assets, installedAppInfo.apkPath);
            if (installedAppInfo.splitCodePaths != null) {
                for (String splitCodePath : installedAppInfo.splitCodePaths) {
                    mirror.android.content.res.AssetManager.addAssetPath.call(assets, splitCodePath);
                }
            }
            Resources hostRes = context.getResources();
            return new Resources(assets, hostRes.getDisplayMetrics(), hostRes.getConfiguration());
        }
        throw new Resources.NotFoundException(pkg);
    }

//    public synchronized ActivityInfo resolveActivityInfo(Intent intent, int userId) {
//        ActivityInfo activityInfo = null;
//        if (intent.getComponent() == null) {
//            ResolveInfo resolveInfo = VPackageManager.get().resolveIntent(intent, intent.getType(), 0, userId);
//            if (resolveInfo != null && resolveInfo.activityInfo != null) {
//                activityInfo = resolveInfo.activityInfo;
//                intent.setClassName(activityInfo.packageName, activityInfo.name);
//            }
//        } else {
//            activityInfo = resolveActivityInfo(intent.getComponent(), userId);
//        }
//        if (activityInfo != null) {
//            if (activityInfo.targetActivity != null) {
//                ComponentName componentName = new ComponentName(activityInfo.packageName, activityInfo.targetActivity);
//                activityInfo = VPackageManager.get().getActivityInfo(componentName, 0, userId);
//                intent.setComponent(componentName);
//            }
//        }
//        return activityInfo;
//    }
//
//    public ActivityInfo resolveActivityInfo(ComponentName componentName, int userId) {
//        return VPackageManager.get().getActivityInfo(componentName, 0, userId);
//    }
//
//    public ServiceInfo resolveServiceInfo(Intent intent, int userId) {
//        ServiceInfo serviceInfo = null;
//        ResolveInfo resolveInfo = VPackageManager.get().resolveService(intent, intent.getType(), 0, userId);
//        if (resolveInfo != null) {
//            serviceInfo = resolveInfo.serviceInfo;
//        }
//        return serviceInfo;
//    }
//
//    public void killApp(String pkg, int userId) {
//        VActivityManager.get().killAppByPkg(pkg, userId);
//    }
//
//    public void killAllApps() {
//        VActivityManager.get().killAllApps();
//    }


    /**
     * 系统是否安装了特定的app
     * @param packageName app的包名
     * @return
     */
    public boolean isOutsideInstalled(String packageName) {
        return getOutsideApplicationInfo(packageName) != null;
    }

    public ApplicationInfo getOutsideApplicationInfo(String packageName) {
        try {
            return unHookPackageManager.getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            VLog.w(TAG, "getOutsideApplicationInfo: %s", e);
            return null;
        }
    }

    public String getOutsideApkPath(String packageName) {
        ApplicationInfo ai = getOutsideApplicationInfo(packageName);
        if (ai != null) {
            String path = ai.publicSourceDir != null ? ai.publicSourceDir : ai.sourceDir;
            if (ai.splitPublicSourceDirs != null || ai.splitSourceDirs != null) {
                // 如果是拆分apk， path为目录
                path = new File(path).getParent();
            }
            return path;
        }
        return null;
    }


    public int getSystemPid() {
        return systemPid;
    }

    /**
     * Process type
     */
    private enum ProcessType {
        /**
         * Server process
         */
        Server,
        /**
         * Virtual app process
         */
        VAppClient,
        /**
         * Main process
         */
        Main,
        /**
         * Child process
         */
        CHILD
    }


    public static abstract class VirtualInitializer {
        public void onMainProcess() {
        }

        public void onVirtualProcess() {
        }

        public void onServerProcess() {
        }

        public void onChildProcess() {
        }
    }
}
