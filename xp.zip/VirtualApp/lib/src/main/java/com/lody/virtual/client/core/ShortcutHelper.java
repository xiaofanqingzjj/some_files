package com.lody.virtual.client.core;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.text.TextUtils;
import android.widget.Toast;

import com.lody.virtual.R;
import com.lody.virtual.client.env.Constants;
import com.lody.virtual.client.ipc.VPackageManager;
import com.lody.virtual.helper.utils.BitmapUtils;
import com.lody.virtual.os.VUserHandle;
import com.lody.virtual.remote.InstalledAppInfo;
import com.lody.virtual.server.pm.VAppManager;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ShortcutHelper {

    public interface OnEmitShortcutListener {
        Bitmap getIcon(Bitmap originIcon);

        String getName(String originName);
    }

    public static boolean createShortcut(Context context, int userId, String packageName, ShortcutHelper.OnEmitShortcutListener listener) {
        return createShortcut(context, userId, packageName, null, listener);
    }

    public static boolean createShortcut(Context context, int userId, String packageName, Intent splash, ShortcutHelper.OnEmitShortcutListener listener) {
        InstalledAppInfo setting = VAppManager.get().getInstalledAppInfo(packageName, 0);
        if (setting == null) {
            return false;
        }
        ApplicationInfo appInfo = setting.getApplicationInfo(userId);
        PackageManager pm = context.getPackageManager();
        String name;
        Bitmap icon;
        String id = packageName + userId;
        try {
            CharSequence sequence = appInfo.loadLabel(pm);
            name = sequence.toString();
            icon = BitmapUtils.drawableToBitmap(appInfo.loadIcon(pm));
        } catch (Throwable e) {
            return false;
        }
        if (listener != null) {
            String newName = listener.getName(name);
            if (newName != null) {
                name = newName;
            }
            Bitmap newIcon = listener.getIcon(icon);
            if (newIcon != null) {
                icon = newIcon;
            }
        }
        Intent targetIntent = VPackageManager.get().getLaunchIntent(context, packageName, userId);
        if (targetIntent == null) {
            return false;
        }
        Intent shortcutIntent = new Intent(Intent.ACTION_VIEW);
        shortcutIntent.setClassName(VirtualCore.get().getHostPkg(), Constants.SHORTCUT_PROXY_ACTIVITY_NAME);
        shortcutIntent.addCategory(Intent.CATEGORY_DEFAULT);
        if (splash != null) {
            shortcutIntent.putExtra(Constants.VA_SPLASH, splash.toUri(0));
        }
        shortcutIntent.putExtra(Constants.VA_INTENT, targetIntent);
        shortcutIntent.putExtra(Constants.VA_URI, targetIntent.toUri(0));
        shortcutIntent.putExtra(Constants.VA_USER_ID, userId);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            // bad parcel.
            shortcutIntent.removeExtra(Constants.VA_INTENT);

            Icon withBitmap = Icon.createWithBitmap(icon);
            ShortcutInfo likeShortcut = new ShortcutInfo.Builder(context, id)
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setIcon(withBitmap)
                    .setIntent(shortcutIntent)
                    .build();

            // crate app shortcuts.
            createShortcutAboveN(context, likeShortcut);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return createDeskShortcutAboveO(context, likeShortcut);
            }
        }


        Intent addIntent = new Intent();
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, name);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON, icon);
        addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        try {
            context.sendBroadcast(addIntent);
        } catch (Throwable ignored) {
            return false;
        }
        return true;
    }

    @TargetApi(Build.VERSION_CODES.N_MR1)
    private static boolean createShortcutAboveN(Context context, ShortcutInfo likeShortcut) {
        ShortcutManager shortcutManager = context.getSystemService(ShortcutManager.class);
        if (shortcutManager == null) {
            return false;
        }
        try {
            int max = shortcutManager.getMaxShortcutCountPerActivity();
            List<ShortcutInfo> dynamicShortcuts = shortcutManager.getDynamicShortcuts();
            if (dynamicShortcuts.size() >= max) {
                Collections.sort(dynamicShortcuts, new Comparator<ShortcutInfo>() {
                    @Override
                    public int compare(ShortcutInfo o1, ShortcutInfo o2) {
                        long r = o1.getLastChangedTimestamp() - o2.getLastChangedTimestamp();
                        return r == 0 ? 0 : (r > 0 ? 1 : -1);
                    }
                });

                ShortcutInfo remove = dynamicShortcuts.remove(0);// remove old.
                shortcutManager.removeDynamicShortcuts(Collections.singletonList(remove.getId()));
            }

            shortcutManager.addDynamicShortcuts(Collections.singletonList(likeShortcut));
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    private static boolean createDeskShortcutAboveO(Context context, ShortcutInfo info) {
        ShortcutManager shortcutManager = context.getSystemService(ShortcutManager.class);
        if (shortcutManager == null) {
            return false;
        }
        if (shortcutManager.isRequestPinShortcutSupported()) {
            // 当添加快捷方式的确认弹框弹出来时，将被回调
            // PendingIntent shortcutCallbackIntent = PendingIntent.getBroadcast(context, 0,
            // new Intent(context, MyReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT);

            List<ShortcutInfo> pinnedShortcuts = shortcutManager.getPinnedShortcuts();
            boolean exists = false;
            for (ShortcutInfo pinnedShortcut : pinnedShortcuts) {
                if (TextUtils.equals(pinnedShortcut.getId(), info.getId())) {
                    // already exist.
                    exists = true;
                    Toast.makeText(context, R.string.create_shortcut_already_exist, Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            if (!exists) {
                shortcutManager.requestPinShortcut(info, null);
            }
            return true;
        }
        return false;
    }

    public static boolean removeShortcut(Context context, int userId, String packageName, Intent splash, ShortcutHelper.OnEmitShortcutListener listener) {
        InstalledAppInfo setting = VAppManager.get().getInstalledAppInfo(packageName, 0);
        if (setting == null) {
            return false;
        }
        ApplicationInfo appInfo = setting.getApplicationInfo(userId);
        PackageManager pm = context.getPackageManager();
        String name;
        try {
            CharSequence sequence = appInfo.loadLabel(pm);
            name = sequence.toString();
        } catch (Throwable e) {
            return false;
        }
        if (listener != null) {
            String newName = listener.getName(name);
            if (newName != null) {
                name = newName;
            }
        }
        Intent targetIntent = VPackageManager.get().getLaunchIntent(context, packageName, userId);
        if (targetIntent == null) {
            return false;
        }
        Intent shortcutIntent = new Intent();
        shortcutIntent.setClassName(VirtualCore.get().getHostPkg(), Constants.SHORTCUT_PROXY_ACTIVITY_NAME);
        shortcutIntent.addCategory(Intent.CATEGORY_DEFAULT);
        if (splash != null) {
            shortcutIntent.putExtra(Constants.VA_SPLASH, splash.toUri(0));
        }
        shortcutIntent.putExtra(Constants.VA_INTENT, targetIntent);
        shortcutIntent.putExtra(Constants.VA_URI, targetIntent.toUri(0));
        shortcutIntent.putExtra(Constants.VA_USER_ID, VUserHandle.myUserId());

        Intent addIntent = new Intent();
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, name);
        addIntent.setAction("com.android.launcher.action.UNINSTALL_SHORTCUT");
        context.sendBroadcast(addIntent);
        return true;
    }

}
