package com.lody.virtual.wchat;

import android.app.Application;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import android.util.Pair;

import com.lody.virtual.client.hook.base.MethodInvocationStub;
import com.lody.virtual.client.hook.base.MethodProxy;
import com.lody.virtual.client.hook.utils.Utils;
import com.lody.virtual.helper.utils.DataUtil;
import com.lody.virtual.helper.utils.StackTraceUtil;

import java.lang.reflect.Field;
import java.lang.reflect.Method;


/**
 * hook 企业微信的日志打印
 */
public class WWorkLogProxy extends MethodInvocationStub<Object> {

    static final String TAG = "LogProxy";

    // 微信业务log类
    static final String BIZ_LOG_CLASS = "com.tencent.mars.xlog.Log";

    // log接口
    static final String LOG_INTERFACE = "com.tencent.mars.xlog.Log$LogImp";

    /**
     * 是否hook微信的日志
     */
    static final boolean isHookWChatLog = false;


    private static void printClassStaticFields(Class<?> clazz) {

        StatFs s;

        Log.d(TAG, clazz + ": Static fields of " + clazz.getName() + ":");
        Field[] fields = clazz.getDeclaredFields();

        for (Field field : fields) {
            // 检查字段是否是静态的
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                try {
                    // 获取静态字段的值
                    field.setAccessible(true);
                    Object value = field.get(null); // null 因为是静态字段
                    Log.d(TAG, field.getName() + " = " + value);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * hook微信的log
     */
    public static void hookWChatLog(Application app, String processName) {
        if (!isHookWChatLog) {
            return;
        }

        Log.i(TAG, "hookWChatLog processName:" + processName + ", sdCard:" + isSDCardMounted());


        try {
            // 获取 MyClass 的 Class 对象
            Class<?> bizLog = app.getClassLoader().loadClass(BIZ_LOG_CLASS);
            printClassStaticFields(bizLog);

            // 替换log的实现类
            Field mLogF = bizLog.getDeclaredField("logImp");
            mLogF.setAccessible(true);
            Log.d(TAG, "logField:" + mLogF.get(null));
            Object value = mLogF.get(null); //因为是静态字段
            if (value != null) {
                WWorkLogProxy logProxy = new WWorkLogProxy(value, app.getClassLoader());
                mLogF.setAccessible(true);
                // 修改静态字段
                mLogF.set(null, logProxy.getProxyInterface());
            }
//            // 修改logLevel
//            Field logLevel = bizLog.getField("a");
//            logLevel.setAccessible(true);
//            logLevel.set(null, 0);
//
//            printClassStaticFields(bizLog);

        } catch (Exception e) {
            Log.e(TAG, "hookWChatLog Error:", e);
        }
    }

    public WWorkLogProxy(Object baseInterface, ClassLoader classLoader) {
        super(baseInterface, getLogClass(classLoader));
        init();
    }

    public static boolean isSDCardMounted() {
        try {
            String externalStorageState = Environment.getExternalStorageState();
            if (externalStorageState != null && externalStorageState.equals("mounted")) {
                return true;
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    private static Class<?> getLogClass(ClassLoader classLoader) {
        try {
            return classLoader.loadClass(LOG_INTERFACE);
        } catch (ClassNotFoundException e) {
            Log.w(TAG, "forName " + LOG_INTERFACE + " error:", e);
            return null;
        }
    }

    private static Pair<String, String> parse(Object[] args) {
        Log.i(TAG, "parse:" + Utils.argsToString(args));
        final String tag = (String) args[1];
        final int tid = (int) args[4];
        final int pid = DataUtil.safeToInt(args[5]);
        final long threadId = (long) args[6];
        final String msg = (String) args[7];
        return new Pair<>(tag,  msg + "[" + "tid:" + tid + ", pid:" + pid + ", threadId:" + threadId + "]");
    }

    void init() {
        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logD";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.d(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logE";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.e(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logF";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.e(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logI";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.i(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logV";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.v(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logW";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.w(result.first, result.second);
                return super.call(who, method, args);
            }
        });
    }
}
