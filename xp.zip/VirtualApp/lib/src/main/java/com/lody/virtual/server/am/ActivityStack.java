package com.lody.virtual.server.am;

import static android.content.pm.ActivityInfo.LAUNCH_SINGLE_INSTANCE;
import static android.content.pm.ActivityInfo.LAUNCH_SINGLE_TASK;
import static android.content.pm.ActivityInfo.LAUNCH_SINGLE_TOP;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.env.VirtualRuntime;
import com.lody.virtual.client.stub.VASettings;
import com.lody.virtual.helper.utils.ArrayUtils;
import com.lody.virtual.helper.utils.ClassUtils;
import com.lody.virtual.helper.utils.CollectionUtils;
import com.lody.virtual.helper.utils.ComponentUtils;
import com.lody.virtual.helper.utils.StackTraceUtil;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.remote.AppTaskInfo;
import com.lody.virtual.remote.StubActivityRecord;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import mirror.android.app.ActivityManagerNative;
import mirror.android.app.ActivityThread;
import mirror.android.app.IActivityManager;
import mirror.android.app.IApplicationThread;
import mirror.com.android.internal.R_Hide;

/**
 * @author Lody
 */

/* package */ class ActivityStack {

    static final String TAG = "ActivityStack";

    /**
     * 系统的ActivityManager
     */
    private final ActivityManager mAM;

    /**
     * VAMS
     */
    private final VActivityManagerService mService;

    /**
     * 任务栈
     * [Key] = TaskId [Value] = TaskRecord
     * taskId->TaskRecord(activities， taskId， userId, affinity, taskRoot)
     */
    private final SparseArray<TaskRecord> mHistory = new SparseArray<>();


    ActivityStack(VActivityManagerService mService) {
        this.mService = mService;
        mAM = (ActivityManager) VirtualCore.get().getContext().getSystemService(Context.ACTIVITY_SERVICE);
    }

    private static void removeFlags(Intent intent, int flags) {
        intent.setFlags(intent.getFlags() & ~flags);
    }

    private static boolean containFlags(Intent intent, int flags) {
        return (intent.getFlags() & flags) != 0;
    }

    private static ActivityRecord topActivityInTask(TaskRecord task) {
        synchronized (task.activities) {
            for (int size = task.activities.size() - 1; size >= 0; size--) {
                ActivityRecord r = task.activities.get(size);
                if (!r.marked) {
                    return r;
                }
            }
            return null;
        }
    }


    private static void deliverNewIntentLocked(ActivityRecord sourceRecord, ActivityRecord targetRecord, Intent intent) {
        if (targetRecord == null) {
            return;
        }
        String creator = sourceRecord != null ? sourceRecord.component.getPackageName() : "android";
        try {
            targetRecord.process.client.scheduleNewIntent(creator, targetRecord.token, intent);
        } catch (RemoteException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    private TaskRecord findTaskByAffinityLocked(int userId, String affinity) {
        return CollectionUtils.find(mHistory, r -> (userId == r.userId && affinity.equals(r.affinity)));
    }

    private TaskRecord findTaskByIntentLocked(int userId, Intent intent) {
        return CollectionUtils.find(mHistory, r->(userId == r.userId && r.taskRoot != null && intent.getComponent().equals(r.taskRoot.getComponent())));
    }

    private ActivityRecord findActivityByToken(int userId, IBinder token) {
        ActivityRecord target = null;
        if (token != null) {
            for (int i = 0; i < this.mHistory.size(); i++) {
                TaskRecord task = this.mHistory.valueAt(i);
                if (task.userId != userId) {
                    continue;
                }
                synchronized (task.activities) {
                    for (ActivityRecord r : task.activities) {
                        if (r.token == token) {
                            target = r;
                        }
                    }
                }
            }
        }
        return target;
    }

    private static boolean markTaskByClearTarget(TaskRecord task, TaskClearMode clearTarget, ComponentName component) {
        boolean marked = false;
        synchronized (task.activities) {
            switch (clearTarget) {
                case CLEAR_TASK: {
                    for (ActivityRecord r : task.activities) {
                        r.marked = true;
                        marked = true;
                    }
                }
                break;
                case CLEAR_SPEC_ACTIVITY: {
                    for (ActivityRecord r : task.activities) {
                        if (r.component.equals(component)) {
                            r.marked = true;
                            marked = true;
                        }
                    }
                }
                break;
                case CLEAR_TOP: {
                    // 找到当前的activity
                    int N = task.activities.size();
                    while (N-- > 0) {
                        ActivityRecord r = task.activities.get(N);
                        if (r.component.equals(component)) {
                            marked = true;
                            break;
                        }
                    }
                    // 删除当前activity以上的activity
                    if (marked) {
                        while (N++ < task.activities.size() - 1) {
                            task.activities.get(N).marked = true;
                        }
                    }
                }
                break;
            }
        }
        return marked;
    }

    /**
     * 同步系统任务id，删除那些系统不存在任务
     *
     * App started in VA may be removed in OverView screen, then AMS.removeTask
     * will be invoked, all data struct about the task in AMS are released,
     * while the client's process is still alive. So remove related data in VA
     * as well. A new TaskRecord will be recreated in `onActivityCreated`
     */
    private void optimizeTasksLocked() {
        // noinspection deprecation
        // 获取当前系统的任务列表
        final List<ActivityManager.RecentTaskInfo> currentTaskInfos =  mAM.getRecentTasks(Integer.MAX_VALUE, ActivityManager.RECENT_WITH_EXCLUDED | ActivityManager.RECENT_IGNORE_UNAVAILABLE);

        // 删除Task中系统不存在的Task
        final Set<Integer> currentTaskIds =  CollectionUtils.toSet(currentTaskInfos, recentTaskInfo -> recentTaskInfo.id);
//        VLog.d(TAG, "optimizeTasksLocked currentTaskInfos:" + currentTaskIds + ", mHistory:" + mHistory);
        CollectionUtils.remove(mHistory, taskId -> !currentTaskIds.contains(taskId));


//        // 如果VAMS里的task不在recentTask里的话，就删除VAMS里的task
//        ArrayList<ActivityManager.RecentTaskInfo> recentTask = new ArrayList<>(currentTaskInfos);
//
//        int N = mHistory.size();
//        while (N-- > 0) {
//            TaskRecord task = mHistory.valueAt(N);
//            ListIterator<ActivityManager.RecentTaskInfo> iterator = recentTask.listIterator();
//            boolean taskAlive = false;
//            while (iterator.hasNext()) {
//                ActivityManager.RecentTaskInfo recentTaskInfo = iterator.next();
//                if (recentTaskInfo.id == task.taskId) {
//                    taskAlive = true;
//
//                    //
//                    iterator.remove();
//                    break;
//                }
//            }
//            if (!taskAlive) {
//                mHistory.removeAt(N);
//            }
//        }
    }


    int startActivitiesLocked(int userId, Intent[] intents, ActivityInfo[] infos, String[] resolvedTypes, IBinder token, Bundle options) {
        optimizeTasksLocked();
        TaskReuseMode reuseTarget = TaskReuseMode.CURRENT;
        Intent intent = intents[0];
        ActivityInfo info = infos[0];
        ActivityRecord resultTo = findActivityByToken(userId, token);
        if (resultTo != null && resultTo.launchMode == LAUNCH_SINGLE_INSTANCE) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        if (containFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TOP)) {
            removeFlags(intent, Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        }
        if (containFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TASK) && !containFlags(intent, Intent.FLAG_ACTIVITY_NEW_TASK)) {
            removeFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TASK);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            switch (info.documentLaunchMode) {
                case ActivityInfo.DOCUMENT_LAUNCH_INTO_EXISTING:
                    reuseTarget = TaskReuseMode.DOCUMENT;
                    break;
                case ActivityInfo.DOCUMENT_LAUNCH_ALWAYS:
                    reuseTarget = TaskReuseMode.MULTIPLE;
                    break;
            }
        }
        if (containFlags(intent, Intent.FLAG_ACTIVITY_NEW_TASK)) {
            reuseTarget = containFlags(intent, Intent.FLAG_ACTIVITY_MULTIPLE_TASK) ? TaskReuseMode.MULTIPLE : TaskReuseMode.AFFINITY;
        } else if (info.launchMode == LAUNCH_SINGLE_TASK) {
            reuseTarget = containFlags(intent, Intent.FLAG_ACTIVITY_MULTIPLE_TASK) ? TaskReuseMode.MULTIPLE : TaskReuseMode.AFFINITY;
        }
        if (resultTo == null && reuseTarget == TaskReuseMode.CURRENT) {
            reuseTarget = TaskReuseMode.AFFINITY;
        }
        String affinity = ComponentUtils.getTaskAffinity(info);
        TaskRecord reuseTask = null;
        if (reuseTarget == TaskReuseMode.AFFINITY) {
            reuseTask = findTaskByAffinityLocked(userId, affinity);
        } else if (reuseTarget == TaskReuseMode.CURRENT) {
            reuseTask = resultTo.task;
        } else if (reuseTarget == TaskReuseMode.DOCUMENT) {
            reuseTask = findTaskByIntentLocked(userId, intent);
        }
        Intent[] destIntents = startActivitiesProcess(userId, intents, infos, resultTo);
        if (reuseTask == null) {
            realStartActivitiesLocked(null, destIntents, resolvedTypes, options);
        } else {
            ActivityRecord top = topActivityInTask(reuseTask);
            if (top != null) {
                realStartActivitiesLocked(top.token, destIntents, resolvedTypes, options);
            }
        }
        return 0;
    }

    private Intent[] startActivitiesProcess(int userId, Intent[] intents, ActivityInfo[] infos, ActivityRecord resultTo) {
        Intent[] destIntents = new Intent[intents.length];
        for (int i = 0; i < intents.length; i++) {
            destIntents[i] = startActivityProcess(userId, resultTo, intents[i], infos[i]);
        }
        return destIntents;
    }


    int startActivityLocked(int userId, Intent intent, ActivityInfo info, IBinder resultTo, Bundle options,
                            String resultWho, int requestCode) {
        // 同步任务栈
        optimizeTasksLocked();

        Intent destIntent;

        // 查找发起者Activity
        ActivityRecord sourceRecord = findActivityByToken(userId, resultTo);

        // 查找发起者所在的TaskRecord
        TaskRecord sourceTask = sourceRecord != null ? sourceRecord.task : null;

        // Task的复用方式，默认复用当前任务栈
        TaskReuseMode taskReuseMode = TaskReuseMode.CURRENT;

        // 如果任务栈中存在启动的Activity，删除任务栈中Activity的方式，默认不删除任何Activity
        TaskClearMode taskClearMode = TaskClearMode.CLEAR_NOTHING;

        if (intent.getComponent() == null) {
            intent.setComponent(new ComponentName(info.packageName, info.name));
        }

        // 如果没有sourceRecord是LAUNCH_SINGLE_INSTANCE，使用新Task运行Intent
        if (sourceRecord != null && sourceRecord.launchMode == LAUNCH_SINGLE_INSTANCE) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }

        boolean clearTop = containFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TOP); // 删除任务栈中对应Activity之上的的Activity
        if (clearTop) {
            removeFlags(intent, Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            taskClearMode = TaskClearMode.CLEAR_TOP;
        }

        boolean clearTask = containFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TASK); // 如果Activity在某个栈中，清除目标任务栈，这个一般需要和FLAG_ACTIVITY_NEW_TASK一起用，使用一个新的Task创建目标Activity
        if (clearTask) {  //FLAG_ACTIVITY_CLEAR_TASK必须和FLAG_ACTIVITY_NEW_TASK联用
            if (containFlags(intent, Intent.FLAG_ACTIVITY_NEW_TASK)) {
                taskClearMode = TaskClearMode.CLEAR_TASK;
            } else {
                // CLEAR_TASK必须和NEW_TASK一起用，否则抛弃这个标志
                removeFlags(intent, Intent.FLAG_ACTIVITY_CLEAR_TASK);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            switch (info.documentLaunchMode) {
                case ActivityInfo.DOCUMENT_LAUNCH_INTO_EXISTING:
                    taskClearMode = TaskClearMode.CLEAR_TASK;
                    taskReuseMode = TaskReuseMode.DOCUMENT;
                    break;
                case ActivityInfo.DOCUMENT_LAUNCH_ALWAYS:
                    taskReuseMode = TaskReuseMode.MULTIPLE;
                    break;
            }
        }

        // activity在目标栈顶则复用
        boolean singleTop = false;
        switch (info.launchMode) { // 要启动Activity的launchMode
            case LAUNCH_SINGLE_TOP: { // 如果要启动的Activity已经在栈顶，则复用
                singleTop = true;
                if (containFlags(intent, Intent.FLAG_ACTIVITY_NEW_TASK)) {
                    taskReuseMode = containFlags(intent, Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                            ? TaskReuseMode.MULTIPLE
                            : TaskReuseMode.AFFINITY;
                }
            }
            break;
            case LAUNCH_SINGLE_TASK: { // 找到affinity所在的任务，并任务栈里只保留一个实例，并删除栈中activity之上的activity
                clearTop = false;
                taskClearMode = TaskClearMode.CLEAR_TOP;
                taskReuseMode = containFlags(intent, Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                        ? TaskReuseMode.MULTIPLE
                        : TaskReuseMode.AFFINITY;
            }
            break;
            case LAUNCH_SINGLE_INSTANCE: {
                clearTop = false;
                taskClearMode = TaskClearMode.CLEAR_TOP;
                taskReuseMode = TaskReuseMode.AFFINITY;
            }
            break;
            default: {
                if (containFlags(intent, Intent.FLAG_ACTIVITY_SINGLE_TOP)) {
                    singleTop = true;
                }
            }
            break;
        }
        if (taskClearMode == TaskClearMode.CLEAR_NOTHING) {
            if (containFlags(intent, Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) {
                taskClearMode = TaskClearMode.CLEAR_SPEC_ACTIVITY;
            }
        }
        if (sourceTask == null && taskReuseMode == TaskReuseMode.CURRENT) {
            taskReuseMode = TaskReuseMode.AFFINITY;
        }

        // 获取activity的taskAffinity
        String affinity = ComponentUtils.getTaskAffinity(info);

        // 查找当前可复用的Task
        TaskRecord reuseTask = null;
        switch (taskReuseMode) {
            case AFFINITY:
                reuseTask = findTaskByAffinityLocked(userId, affinity);
                break;
            case DOCUMENT:
                reuseTask = findTaskByIntentLocked(userId, intent);
                break;
            case CURRENT:
                reuseTask = sourceTask;
                break;
            default:
                break;
        }


        VLog.d(TAG, "startActivityLocked userId:" + userId + ", intent:" + intent.getComponent()
                + ", reuseTask:" + reuseTask + ", clearTarget:" + taskClearMode + ", reuseTarget:" + taskReuseMode
                + ", launchMode:" + info.launchMode + ",  clearTop:" + clearTop + ", clearTask:" + clearTask + ", singleTop:" + singleTop + ", sourceTask:" + sourceTask
        );

        if (reuseTask == null) { // 没有复用的Task
            // 开启一个新Task， 开新任务的方式就是向AMS发送带newTask标记的intent
            // 这个任务如何同步到VAMS里来呢？
            startActivityInNewTaskLocked(userId, intent, info, options);
        } else {
            // 找到有可复用的Task

            // 把可复用的Task放到顶部
            mAM.moveTaskToFront(reuseTask.taskId, 0);

            boolean delivered = false;

            // 需要删除栈里的Activity
            if (taskClearMode.deliverIntent || singleTop) {

                // 根据clearTarget标记栈中哪些Activity需要关闭，返回true表示有需要关闭的Activity
                boolean taskMarked = markTaskByClearTarget(reuseTask, taskClearMode, intent.getComponent());

                // 找到任务栈顶部未被标记的Activity
                ActivityRecord topRecord = topActivityInTask(reuseTask);

                if (clearTop && !singleTop && topRecord != null && taskMarked) {
                    topRecord.marked = true;
                }
                // Target activity is on top
                if (topRecord != null && !topRecord.marked && topRecord.component.equals(intent.getComponent())) {
                    // 向目标Activity发送onNewIntent
                    deliverNewIntentLocked(sourceRecord, topRecord, intent);
                    delivered = true;
                }

                if (taskMarked) {
                    synchronized (mHistory) {
                        scheduleFinishMarkedActivityLocked();
                    }
                }
            }

            // 如果前面没有把已存在的Activity挪到前面来，就在当前的任务栈里启动Activity
            boolean startTaskToFront = !clearTask && !clearTop && ComponentUtils.isSameIntent(intent, reuseTask.taskRoot);
            if (!startTaskToFront && !delivered) {
                // 开启目标进程
                destIntent = startActivityProcess(userId, sourceRecord, intent, info);
                if (destIntent != null) {
                    // 在原Task栈上启动Activity
                    startActivityFromSourceTask(reuseTask, destIntent, info, resultWho, requestCode, options);
                }
            }
        }
        return 0;
    }

    /**
     * 在一个新的Task中启动Activity
     */
    private void startActivityInNewTaskLocked(int userId, Intent intent, ActivityInfo info, Bundle options) {
        VLog.d(TAG, "startActivityInNewTaskLocked userId:" + userId + ", intent:" + intent + ", info:" + info);
        // 创建进程
        Intent destIntent = startActivityProcess(userId, null, intent, info);
        if (destIntent != null) {
            // 向系统发送创建新任务的Activity请求
            destIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            destIntent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            destIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                // noinspection deprecation
                destIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
            } else {
                destIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
            }

            //调用系统AMS的startActivity
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                VirtualCore.get().getContext().startActivity(destIntent, options);
            } else {
                VirtualCore.get().getContext().startActivity(destIntent);
            }
        }
    }

    private void scheduleFinishMarkedActivityLocked() {
        int N = mHistory.size();
        while (N-- > 0) {
            final TaskRecord task = mHistory.valueAt(N);
            for (final ActivityRecord r : task.activities) {
                if (!r.marked) {
                    continue;
                }
                VirtualRuntime.getUIHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            r.process.client.finishActivity(r.token);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        }
    }

    private void startActivityFromSourceTask(TaskRecord task, Intent intent, ActivityInfo info, String resultWho,
                                             int requestCode, Bundle options) {
        VLog.i(TAG, "startActivityFromSourceTask info:" + info);

        // 获取task最顶层的Activity
        ActivityRecord top = task.activities.isEmpty() ? null : task.activities.get(task.activities.size() - 1);
        if (top != null) {
            //
            if (startActivityProcess(task.userId, top, intent, info) != null) {
                realStartActivityLocked(top.token, intent, resultWho, requestCode, options);
            }
        }
    }


    private void realStartActivitiesLocked(IBinder resultTo, Intent[] intents, String[] resolvedTypes, Bundle options) {
        Class<?>[] types = IActivityManager.startActivities.paramList();
        Object[] args = new Object[types.length];
        if (types[0] == IApplicationThread.TYPE) {
            args[0] = ActivityThread.getApplicationThread.call(VirtualCore.mainThread());
        }
        int pkgIndex = ArrayUtils.protoIndexOf(types, String.class);
        int intentsIndex = ArrayUtils.protoIndexOf(types, Intent[].class);
        int resultToIndex = ArrayUtils.protoIndexOf(types, IBinder.class, 2);
        int optionsIndex = ArrayUtils.protoIndexOf(types, Bundle.class);
        int resolvedTypesIndex = intentsIndex + 1;
        if (pkgIndex != -1) {
            args[pkgIndex] = VirtualCore.get().getHostPkg();
        }
        args[intentsIndex] = intents;
        args[resultToIndex] = resultTo;
        args[resolvedTypesIndex] = resolvedTypes;
        args[optionsIndex] = options;
        ClassUtils.fixArgs(types, args);
        IActivityManager.startActivities.call(ActivityManagerNative.getDefault.call(),
                (Object[]) args);
    }


    /**
     * 调用系统的AMS的startActivity方法
     * @param resultTo 要返回的Activity的token
     * @param intent 启动的Intent
     * @param resultWho 返回的Activity的标识,一般在ActivityGroup才有效
     * @param requestCode 请求码
     * @param options 启动的选项
     */
    private void realStartActivityLocked(IBinder resultTo,
                                         Intent intent,
                                         String resultWho,
                                         int requestCode,
                                         Bundle options) {

        Class<?>[] types = mirror.android.app.IActivityManager.startActivity.paramList();
        Object[] args = new Object[types.length];

        if (types[0] == IApplicationThread.TYPE) {
            args[0] = ActivityThread.getApplicationThread.call(VirtualCore.mainThread());
        }
        int intentIndex = ArrayUtils.protoIndexOf(types, Intent.class);
        int resultToIndex = ArrayUtils.protoIndexOf(types, IBinder.class, 2);
        int optionsIndex = ArrayUtils.protoIndexOf(types, Bundle.class);

        int resolvedTypeIndex = intentIndex + 1;
        int resultWhoIndex = resultToIndex + 1;
        int requestCodeIndex = resultToIndex + 2;

        args[intentIndex] = intent;
        args[resultToIndex] = resultTo;
        args[resultWhoIndex] = resultWho;
        args[requestCodeIndex] = requestCode;
        if (optionsIndex != -1) {
            args[optionsIndex] = options;
        }
        args[resolvedTypeIndex] = intent.getType();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            args[intentIndex - 1] = VirtualCore.get().getHostPkg();
        }
        ClassUtils.fixArgs(types, args);

        // 调用系统的AMS
        mirror.android.app.IActivityManager.startActivity.call(ActivityManagerNative.getDefault.call(), args);
    }

    private static String fetchStubActivity(int vpid, ActivityInfo targetInfo) {

        boolean isFloating = false;
        boolean isTranslucent = false;
        boolean showWallpaper = false;
        try {
            int[] R_Styleable_Window = R_Hide.styleable.Window.get();
            int R_Styleable_Window_windowIsTranslucent = R_Hide.styleable.Window_windowIsTranslucent.get();
            int R_Styleable_Window_windowIsFloating = R_Hide.styleable.Window_windowIsFloating.get();
            int R_Styleable_Window_windowShowWallpaper = R_Hide.styleable.Window_windowShowWallpaper.get();

            AttributeCache.Entry ent = AttributeCache.instance().get(targetInfo.packageName, targetInfo.theme,
                    R_Styleable_Window);
            if (ent != null && ent.array != null) {
                showWallpaper = ent.array.getBoolean(R_Styleable_Window_windowShowWallpaper, false);
                isTranslucent = ent.array.getBoolean(R_Styleable_Window_windowIsTranslucent, false);
                isFloating = ent.array.getBoolean(R_Styleable_Window_windowIsFloating, false);
            }else{
                Resources resources=VirtualCore.get().getResources(targetInfo.packageName);
                if(resources!=null) {
                    TypedArray typedArray = resources.newTheme().obtainStyledAttributes(targetInfo.theme, R_Styleable_Window);
                    if(typedArray!=null){
                        showWallpaper = typedArray.getBoolean(R_Styleable_Window_windowShowWallpaper, false);
                        isTranslucent = typedArray.getBoolean(R_Styleable_Window_windowIsTranslucent, false);
                        isFloating = typedArray.getBoolean(R_Styleable_Window_windowIsFloating, false);
                    }
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

        // deal with manifest Activity style android:excludeFromRecents="true", becasue Mobile Legends has two recent task
        boolean isExcludeFromRecents = ((targetInfo.flags & ActivityInfo.FLAG_EXCLUDE_FROM_RECENTS) != 0);
        if (isExcludeFromRecents) {
            return VASettings.getStubExcludeFromRecentActivityName(vpid);
        }

        boolean isDialogStyle = isFloating || isTranslucent || showWallpaper;
        if (isDialogStyle) {
            return VASettings.getStubDialogName(vpid);
        } else {
            return VASettings.getStubActivityName(vpid);
        }
    }


    /**
     * 启动Activity所在的进程
     * 并把原始Intent信息封装成StubActivityRecord添加到一个占位的Intent中，在目标进程中启动占位Activity
     * @param userId 用户id
     * @param sourceRecord 前一个Activity
     * @param intent 启动的Intent
     * @param activityInfo 启动的ActivityInfo
     * @return 占位Activity的Intent
     */
    private Intent startActivityProcess(int userId, ActivityRecord sourceRecord, Intent intent, ActivityInfo activityInfo) {

        ProcessRecord targetApp = mService.startProcessIfNeedLocked(activityInfo.processName, userId, activityInfo.packageName, "startActivity " + activityInfo.name);
        if (targetApp == null) {
            return null;
        }
        return createPlaceHolderActivityIntent(userId, sourceRecord, intent, activityInfo, targetApp.vpid);
    }

    /**
     * 创建一个打开占位Activity的Intent
     */
    private static Intent createPlaceHolderActivityIntent(int userId, ActivityRecord sourceRecord, Intent intent, ActivityInfo activityInfo, int vpid) {
        Intent targetIntent = new Intent();
        targetIntent.setClassName(VirtualCore.get().getHostPkg(), fetchStubActivity(vpid, activityInfo));

        ComponentName component = intent.getComponent();
        if (component == null) {
            component = ComponentUtils.toComponentName(activityInfo);
        }
        targetIntent.setType(component.flattenToString());

        StubActivityRecord saveInstance = new StubActivityRecord(new Intent(intent), activityInfo,
                sourceRecord != null ? sourceRecord.component : null, userId);
        saveInstance.saveToIntent(targetIntent);
        return targetIntent;
    }

    /**
     * AMS Activity的回调
     * 同步AMS和VAMS的task
     */
    void onActivityCreated(ProcessRecord targetApp, ComponentName component, ComponentName caller, IBinder token,
                           Intent taskRoot, String affinity, int taskId, int launchMode, int flags) {
        VLog.d(TAG, "onActivityCreated targetApp:" + targetApp + ", component:" + component
                + ", caller:" + caller + ", token:" + token + ", taskRoot:" + taskRoot
                + ", affinity:" + affinity + ", taskId:" + taskId + ", launchMode:" + launchMode
                + ", flags:" + flags + ", stack:" + StackTraceUtil.getCurrentStackTrace()
        );
        synchronized (mHistory) {
            // 同步系统的任务栈
            optimizeTasksLocked();

            TaskRecord task = mHistory.get(taskId);
            if (task == null) {
                // 本地没有对应的任务，创建一个新的任务添加到任务栈中
                task = new TaskRecord(taskId, targetApp.userId, affinity, taskRoot);
                mHistory.put(taskId, task);
            }

            // 把Activity添加到Task的activity中
            ActivityRecord record = new ActivityRecord(task, component, caller, token, targetApp.userId, targetApp,
                    launchMode, flags, affinity);
            synchronized (task.activities) {
                task.activities.add(record);
            }
        }
    }

    void onActivityResumed(int userId, IBinder token) {

        synchronized (mHistory) {
            optimizeTasksLocked();
            ActivityRecord r = findActivityByToken(userId, token);
//            VLog.d(TAG, "onActivityResume userId:" + userId + ", activityRecord:" + r + ", stack:" + StackTraceUtil.getCurrentStackTrace());
            if (r != null) {
                synchronized (r.task.activities) {
                    r.task.activities.remove(r);
                    r.task.activities.add(r);
                }
            }
        }
    }

    ActivityRecord onActivityDestroyed(int userId, IBinder token) {

        synchronized (mHistory) {
            optimizeTasksLocked();
            ActivityRecord r = findActivityByToken(userId, token);
            VLog.i(TAG, "onActivityDestroyed userId:" + userId + ", token:" + token + ", r:" + r);
            if (r != null) {
                synchronized (r.task.activities) {
                    r.task.activities.remove(r);
                    // We shouldn't remove task at this point,
                    // it will be removed by optimizeTasksLocked().
                }
            }
            return r;
        }
    }

    /**
     * 删除任务栈中特定进程的Activity
     * @param diedProcess
     */
    void processDied(ProcessRecord diedProcess) {
        synchronized (mHistory) {
            optimizeTasksLocked();
            int N = mHistory.size();
            while (N-- > 0) {
                TaskRecord task = mHistory.valueAt(N);
                synchronized (task.activities) {
                    Iterator<ActivityRecord> iterator = task.activities.iterator();
                    while (iterator.hasNext()) {
                        ActivityRecord r = iterator.next();
                        if (r.process.pid == diedProcess.pid) {
                            iterator.remove();
                            if (task.activities.isEmpty()) {
                                mHistory.remove(task.taskId);
                            }
                        }
                    }
                }
            }

        }
    }

    String getPackageForToken(int userId, IBinder token) {
        synchronized (mHistory) {
            ActivityRecord r = findActivityByToken(userId, token);
            if (r != null) {
                return r.component.getPackageName();
            }
            return null;
        }
    }

    ComponentName getCallingActivity(int userId, IBinder token) {
        synchronized (mHistory) {
            ActivityRecord r = findActivityByToken(userId, token);
            if (r != null) {
                return r.caller != null ? r.caller : r.component;
            }
            return null;
        }
    }

    public String getCallingPackage(int userId, IBinder token) {
        synchronized (mHistory) {
            ActivityRecord r = findActivityByToken(userId, token);
            if (r != null) {
                return r.caller != null ? r.caller.getPackageName() : "android";
            }
            return "android";
        }
    }

    AppTaskInfo getTaskInfo(int taskId) {
        synchronized (mHistory) {
            TaskRecord task = mHistory.get(taskId);
            if (task != null) {
                return task.getAppTaskInfo();
            }
            return null;
        }
    }

    ComponentName getActivityClassForToken(int userId, IBinder token) {
        synchronized (mHistory) {
            ActivityRecord r = findActivityByToken(userId, token);
            if (r != null) {
                return r.component;
            }
            return null;
        }
    }


    /**
     * 任务的复用类型
     */
    private enum TaskReuseMode {
        CURRENT, // 和source同一个Task
        AFFINITY, // 根据affinity查找同名Task
        DOCUMENT, // 和task root相等的task
        MULTIPLE // 新启一个任务
    }

    /**
     * Task 中Activity的删除类型
     */
    private enum TaskClearMode {
        CLEAR_NOTHING, // 不删除任何Activity: nothing
        CLEAR_SPEC_ACTIVITY, // 删除Activity : clearSpec
        CLEAR_TASK(true), // 删除整个Task里的Activity： clearTask
        CLEAR_TOP(true); // 删除Task顶部的Activity: clearTop

        boolean deliverIntent;

        TaskClearMode() {
            this(false);
        }

        TaskClearMode(boolean deliverIntent) {
            this.deliverIntent = deliverIntent;
        }
    }


}