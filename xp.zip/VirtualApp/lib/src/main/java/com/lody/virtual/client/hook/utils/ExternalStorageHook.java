package com.lody.virtual.client.hook.utils;

import android.content.Context;
import android.content.ContextWrapper;
import android.util.Log;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.helper.utils.Reflect;


public class ExternalStorageHook {

    static final String TAG = "ExternalStorageHook";

    public static void processContext(Context hostContext, android.content.Context appContext) {
        if (!VirtualCore.get().isVAppProcess()) {
            return;
        }
        // 为appContext创建一个代理
        if (appContext instanceof ContextWrapper) {
            final ContextWrapper wrapper = ((ContextWrapper)appContext);
            Context proxy = new ContextProxy(wrapper.getBaseContext());
            Reflect.on(appContext).set("mBase", proxy);
            Log.d(TAG, "hookContextImpl appContext:" + appContext +  ",  baseContext:" + wrapper.getBaseContext());
        }

    }
}
