package com.lody.virtual.client.hook.proxies.os;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;

import com.lody.virtual.client.hook.base.BinderInvocationProxy;
import com.lody.virtual.client.hook.base.MethodProxy;
import com.lody.virtual.helper.utils.VLog;

import java.lang.reflect.Method;

import mirror.android.os.IVibratorManagerService;

/**
 * 拦截震动服务
 */
@TargetApi(Build.VERSION_CODES.S)
public class VibratorManagerServiceStub extends BinderInvocationProxy {


    public VibratorManagerServiceStub() {
        super(IVibratorManagerService.Stub.asInterface, Context.VIBRATOR_MANAGER_SERVICE);
    }

    @Override
    protected void onBindMethods() {
        super.onBindMethods();
        addMethodProxy(new Vibrate());
    }

     private static class Vibrate extends MethodProxy {

        static final String TAG = "Vibrate";

        @Override
        public String getMethodName() {
            return "vibrate";
        }

         @Override
         public Object call(Object who, Method method, Object... args) throws Throwable {
             VLog.w(TAG, "call: who = [" + who + "], method = [" + method + "], args = [" + args + "]");
//             return super.call(who, method, args);
             return null;
         }
     }
}
