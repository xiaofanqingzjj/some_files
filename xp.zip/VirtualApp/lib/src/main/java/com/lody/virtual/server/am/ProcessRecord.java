package com.lody.virtual.server.am;

import android.content.pm.ApplicationInfo;
import android.os.Binder;
import android.os.IInterface;

import com.lody.virtual.client.IVClient;
import com.lody.virtual.os.VUserHandle;
import com.lody.virtual.server.ProcessInfo;

import java.util.HashSet;
import java.util.Objects;


/**
 * 当前启动的进程信息
 */
public final class ProcessRecord extends Binder implements Comparable<ProcessRecord> {

//	final ConditionVariable lock = new ConditionVariable();
	public final ApplicationInfo info; // all about the first app in the process
	public final  String processName; // name of the process

	/**
	 * 进程所属的package
	 * 多个app可能运行在同一个进程
	 */
	public final HashSet<String> pkgList = new HashSet<>(); // List of packages
	public IVClient client;
	IInterface appThread;
	public int pid;
	public int vuid;
	public int vpid;
	public int userId;
	boolean doneExecuting;
    int priority;

	public ProcessRecord(ApplicationInfo info, String processName, int vuid, int vpid) {
		this.info = info;
		this.vuid = vuid;
		this.vpid = vpid;
		this.userId = VUserHandle.getUserId(vuid);
		this.processName = processName;
	}




	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		ProcessRecord record = (ProcessRecord) o;
		return Objects.equals(processName, record.processName);
	}

    @Override
    public int compareTo(ProcessRecord another) {
        return this.priority - another.priority;
    }

	public ProcessInfo toParcelable() {
		return new ProcessInfo(this);
	}

	@Override
	public String toString() {
		return "ProcessRecord{" +
				"info=" + info +
				", processName='" + processName + '\'' +
				", pid=" + pid +
				", vuid=" + vuid +
				", vpid=" + vpid +
				", userId=" + userId +
				", priority=" + priority +
				'}';
	}

}
