package com.lody.virtual.client;

import android.annotation.SuppressLint;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Environment;
import android.system.ErrnoException;
import android.system.Os;
import android.util.Log;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.ipc.VirtualStorageManager;
import com.lody.virtual.helper.compat.StorageManagerCompat;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.os.VEnvironment;
import com.lody.virtual.os.VUserHandle;
import com.lody.virtual.remote.VDeviceInfo;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

class IORedirectHelper {

    static final String TAG = "IORedirectHelper";


    @SuppressLint("SdCardPath")
    static void startIOUniformer(VDeviceInfo deviceInfo, VClientImpl.AppBindData appBindData) {

        String processName = appBindData.processName;


        // wlan、wifi、eth0的映射
        final int userId = VUserHandle.myUserId();
        String wifiMacAddressFile = deviceInfo.getWifiFile(userId).getPath();
        NativeEngine.redirectDirectory(processName, "/sys/class/net/wlan0/address", wifiMacAddressFile);
        NativeEngine.redirectDirectory(processName, "/sys/class/net/eth0/address", wifiMacAddressFile);
        NativeEngine.redirectDirectory(processName, "/sys/class/net/wifi/address", wifiMacAddressFile);



        // app自身的沙盒目录
        // org: /data/data/<packageName>/
        final ApplicationInfo info = appBindData.appInfo;

        final String dataDir = info.dataDir;

        // 老的用户目录
        NativeEngine.redirectDirectory(processName, "/data/data/" + info.packageName, dataDir);

        // 4.2后带用户id的目录
        NativeEngine.redirectDirectory(processName, "/data/user/0/" + info.packageName, dataDir);

        // 加密用户目录
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            NativeEngine.redirectDirectory(processName, "/data/user_de/0/" + info.packageName, dataDir);
        }


        // org:VA_ROOT/data/user/<userId>/<package-Name>/lib -> new: VA_ROOT/data/app/<packageName>/lib
//        String libPath = VEnvironment.getAppLibDirectory(info.packageName).getAbsolutePath();
//
//        String userLibPath = new File(VEnvironment.getUserSystemDirectory(userId), info.packageName + "/lib").getAbsolutePath();
//        NativeEngine.redirectDirectory(processName, userLibPath, libPath);
//
//        // so目录映射到沙盒的so目录
//        // org: /data/data/<packageName>/lib -> new: VA_ROOT/data/app/<packageName>/lib
//        NativeEngine.redirectDirectory(processName, "/data/data/" + info.packageName + "/lib/", libPath);
//        NativeEngine.redirectDirectory(processName, "/data/user/0/" + info.packageName + "/lib/", libPath);
//
//        //
//        File dataUserLib = new File(VEnvironment.getDataUserPackageDirectory(userId, info.packageName), "lib");
//        if (!dataUserLib.exists()) {
//            try {
//                Os.symlink(libPath, dataUserLib.getPath());
//            } catch (ErrnoException e) {
//                VLog.w(TAG, "symlink error", e);
//            }
//        }

        // 虚拟sd卡的映射
        setupVirtualStorage(processName, info, userId);

        // 开启io重定向
        NativeEngine.enableIORedirect();
    }

    // sd卡路径的映射
    private static void setupVirtualStorage(String processName, ApplicationInfo info, int userId) {


        VirtualStorageManager vsManager = VirtualStorageManager.get();
        boolean enable = vsManager.isVirtualStorageEnable(info.packageName, userId);
        Log.d(TAG, "setupVirtualStorage info:" + info.packageName + ", enable:" + enable);
        // Android 11, force enable storage redirect.
        if (!enable && !(Build.VERSION.SDK_INT >= 30)) {
            // There are lots of situation to deal, I am tired, disable it now.
            // such as: FileProvider.
            return;
        }



        // 虚拟sd卡
        // 原来在：/sdcard/VirtualXposed/vsdcard/<userId>/
        // 新：/sdcard/Android/data/<package-name>/files/VirtualXposed/vsdcard/<userId>
        File vsDir = VEnvironment.getVirtualStorageDir(info.packageName, userId);
        Log.d(TAG, "setupVirtualStorage info:" + info.packageName + ", vsDir:" + vsDir + ", vsDir.exits:" + vsDir.exists());
        if (!vsDir.exists() || !vsDir.isDirectory()) {
            Log.d(TAG, "setupVirtualStorage not exit return");
            return;
        }


        // 外部sd卡的挂载目录，比如/sdcard/
        HashSet<String> storageRoots = getMountPoints();
        VLog.w(TAG, "setupVirtualStorage storageRoots:" + storageRoots);


        // 白名单里的路径不做重定向
        Set<String> whiteList = new HashSet<>();
        whiteList.add(Environment.DIRECTORY_PODCASTS);
        whiteList.add(Environment.DIRECTORY_RINGTONES);
        whiteList.add(Environment.DIRECTORY_ALARMS);
        whiteList.add(Environment.DIRECTORY_NOTIFICATIONS);
        whiteList.add(Environment.DIRECTORY_PICTURES);
        whiteList.add(Environment.DIRECTORY_MOVIES);
        whiteList.add(Environment.DIRECTORY_DOWNLOADS);
        whiteList.add(Environment.DIRECTORY_DCIM);
        // Android 11, do not tryna fetch this directory directly or crash.
        // See docs below...
        if (Build.VERSION.SDK_INT < 30) {
            whiteList.add("Android/obb");
        }
        if (Build.VERSION.SDK_INT >= 19) {
            whiteList.add(Environment.DIRECTORY_DOCUMENTS);
        }

        // ensure virtual storage white directory exists.
        // 把sdcard根目录下的一些目录在虚拟vsdcard/0/中也创建一份。
        for (String whiteDir : whiteList) {
            File originalDir = new File(VEnvironment.getExternalStorageDirectory(), whiteDir);
            if (!originalDir.exists()) {
                continue;
            }

            File virtualDir = new File(vsDir, whiteDir);
            //noinspection ResultOfMethodCallIgnored
            virtualDir.mkdirs();
        }

        String vsPath = vsDir.getAbsolutePath();
        NativeEngine.whitelist(vsPath, true);

        // 应用的私有目录：/Android/data/<host-packageName>/virtual/<userId>/
        final String privatePath = VEnvironment.getVirtualPrivateStorageDir(userId).getAbsolutePath();

        NativeEngine.whitelist(privatePath, true);

//        whiteList.add("Android/data/com.tencent.mulapp/virtual/1");



        for (String storageRoot : storageRoots) {
            for (String whiteDir : whiteList) {
                // white list, do not redirect
                String whitePath = new File(storageRoot, whiteDir).getAbsolutePath();
                NativeEngine.whitelist(whitePath, true);
            }

            // Android 11 -> see https://developer.android.com/training/data-storage#scoped-storage
            // 安卓11 打开这个链接看看 https://developer.android.google.cn/training/data-storage#scoped-storage
            // see https://android-opengrok.bangnimang.net/android-11.0.0_r8/xref/frameworks/base/core/java/android/os/Environment.java

            // redirect /sdcard/Android/data/ -> /sdcard/Android/data/<host>/virtual/<user>/
            NativeEngine.redirectDirectory(processName, new File(storageRoot, "Android/data/").getAbsolutePath(), privatePath);

            // redirect /sdcard/Android/obb/ -> /sdcard/Android/data/<host>/virtual/<user>/
            NativeEngine.redirectDirectory(processName, new File(storageRoot, "Android/obb/").getAbsolutePath(), privatePath);

            // redirect /sdcard/ -> vsdcard

            // 为啥要把根路径也映射过去？
//            NativeEngine.redirectDirectory(processName, storageRoot, vsPath);
        }
    }

    @SuppressLint("SdCardPath")
    private static HashSet<String> getMountPoints() {
        HashSet<String> mountPoints = new HashSet<>(3);

        mountPoints.add("/mnt/sdcard/");
        mountPoints.add("/sdcard/");
        // Redmi 10X Pro, Pixel 5... More mount points?
        // 1@die.lu
        mountPoints.add("/storage/self/primary/");

        String[] points = StorageManagerCompat.getAllPoints(VirtualCore.get().getContext());
        if (points != null) {
            Collections.addAll(mountPoints, points);
        }

        //
        mountPoints.add(VEnvironment.getExternalStorageDirectory().getAbsolutePath());

        return mountPoints;

    }
}
