package com.lody.virtual.server.am;

import android.content.ComponentName;
import android.os.IBinder;

/**
 * Activity在AMS里的记录
 * @author Lody
 */

/* package */ class ActivityRecord {
	// 所属任务
	public TaskRecord task;

	// Activity组件信息
	public ComponentName component;

	// 启动组件
	public ComponentName caller;

	// 在真实AMS中的记录
	public IBinder token;

	// 用户id
	public int userId;

	// 进程信息
	public ProcessRecord process;

	// 启动模式
	public int launchMode;

	// 启动flags
	public int flags;

	// 标记是否在该次Activity请求中finish这个Activity
	public boolean marked;

	// 任务标识
	public String affinity;

	public ActivityRecord(TaskRecord task, ComponentName component, ComponentName caller, IBinder token, int userId, ProcessRecord process, int launchMode, int flags, String affinity) {
		this.task = task;
		this.component = component;
		this.caller = caller;
		this.token = token;
		this.userId = userId;
		this.process = process;
		this.launchMode = launchMode;
		this.flags = flags;
		this.affinity = affinity;
	}

	@Override
	public String toString() {
		return "ActivityRecord{" +
				"task=" + task +
				", component=" + component +
				", caller=" + caller +
				", token=" + token +
				", userId=" + userId +
				", process=" + process +
				", launchMode=" + launchMode +
				", flags=" + flags +
				", marked=" + marked +
				", affinity='" + affinity + '\'' +
				'}';
	}
}
