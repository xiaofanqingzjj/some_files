package com.lody.virtual.client.stub;

/**
 * @author Lody
 *
 */
public abstract class StubDialog extends StubActivity {


	public static class C0 extends StubDialog {
	}

	public static class C1 extends StubDialog {
	}

	public static class C2 extends StubDialog {
	}

	public static class C3 extends StubDialog {
	}

	public static class C4 extends StubDialog {
	}

	public static class C5 extends StubDialog {
	}

	public static class C6 extends StubDialog {
	}

	public static class C7 extends StubDialog {
	}

	public static class C8 extends StubDialog {
	}

	public static class C9 extends StubDialog {
	}

	public static class C10 extends StubDialog {
	}

	public static class C11 extends StubDialog {
	}

	public static class C12 extends StubDialog {
	}

	public static class C13 extends StubDialog {
	}

	public static class C14 extends StubDialog {
	}

	public static class C15 extends StubDialog {
	}

	public static class C16 extends StubDialog {
	}

	public static class C17 extends StubDialog {
	}

	public static class C18 extends StubDialog {
	}

	public static class C19 extends StubDialog {
	}

	public static class C20 extends StubDialog {
	}

	public static class C21 extends StubDialog {
	}

	public static class C22 extends StubDialog {
	}

	public static class C23 extends StubDialog {
	}

	public static class C24 extends StubDialog {
	}

	public static class C25 extends StubDialog {
	}

	public static class C26 extends StubDialog {
	}

	public static class C27 extends StubDialog {
	}

	public static class C28 extends StubDialog {
	}

	public static class C29 extends StubDialog {
	}

	public static class C30 extends StubDialog {
	}

	public static class C31 extends StubDialog {
	}

	public static class C32 extends StubDialog {
	}

	public static class C33 extends StubDialog {
	}

	public static class C34 extends StubDialog {
	}

	public static class C35 extends StubDialog {
	}

	public static class C36 extends StubDialog {
	}

	public static class C37 extends StubDialog {
	}

	public static class C38 extends StubDialog {
	}

	public static class C39 extends StubDialog {
	}

	public static class C40 extends StubDialog {
	}

	public static class C41 extends StubDialog {
	}

	public static class C42 extends StubDialog {
	}

	public static class C43 extends StubDialog {
	}

	public static class C44 extends StubDialog {
	}

	public static class C45 extends StubDialog {
	}

	public static class C46 extends StubDialog {
	}

	public static class C47 extends StubDialog {
	}

	public static class C48 extends StubDialog {
	}

	public static class C49 extends StubDialog {
	}

	public static class C50 extends StubDialog {
	}

	public static class C51 extends StubDialog {
	}

	public static class C52 extends StubDialog {
	}

	public static class C53 extends StubDialog {
	}

	public static class C54 extends StubDialog {
	}

	public static class C55 extends StubDialog {
	}

	public static class C56 extends StubDialog {
	}

	public static class C57 extends StubDialog {
	}

	public static class C58 extends StubDialog {
	}

	public static class C59 extends StubDialog {
	}

	public static class C60 extends StubDialog {
	}

	public static class C61 extends StubDialog {
	}

	public static class C62 extends StubDialog {
	}

	public static class C63 extends StubDialog {
	}

	public static class C64 extends StubDialog {
	}

	public static class C65 extends StubDialog {
	}

	public static class C66 extends StubDialog {
	}

	public static class C67 extends StubDialog {
	}

	public static class C68 extends StubDialog {
	}

	public static class C69 extends StubDialog {
	}

	public static class C70 extends StubDialog {
	}

	public static class C71 extends StubDialog {
	}

	public static class C72 extends StubDialog {
	}

	public static class C73 extends StubDialog {
	}

	public static class C74 extends StubDialog {
	}

	public static class C75 extends StubDialog {
	}

	public static class C76 extends StubDialog {
	}

	public static class C77 extends StubDialog {
	}

	public static class C78 extends StubDialog {
	}

	public static class C79 extends StubDialog {
	}

	public static class C80 extends StubDialog {
	}

	public static class C81 extends StubDialog {
	}

	public static class C82 extends StubDialog {
	}

	public static class C83 extends StubDialog {
	}

	public static class C84 extends StubDialog {
	}

	public static class C85 extends StubDialog {
	}

	public static class C86 extends StubDialog {
	}

	public static class C87 extends StubDialog {
	}

	public static class C88 extends StubDialog {
	}

	public static class C89 extends StubDialog {
	}

	public static class C90 extends StubDialog {
	}

	public static class C91 extends StubDialog {
	}

	public static class C92 extends StubDialog {
	}

	public static class C93 extends StubDialog {
	}

	public static class C94 extends StubDialog {
	}

	public static class C95 extends StubDialog {
	}

	public static class C96 extends StubDialog {
	}

	public static class C97 extends StubDialog {
	}

	public static class C98 extends StubDialog {
	}

	public static class C99 extends StubDialog {
	}


}
