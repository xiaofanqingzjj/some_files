package com.lody.virtual.server;

import android.content.pm.ApplicationInfo;
import android.os.Parcel;
import android.os.Parcelable;

import com.lody.virtual.server.am.ProcessRecord;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


/**
 * 进程记录信息，用来给IPC调用
 */
public final class ProcessInfo implements Parcelable {


	public final ApplicationInfo info;
	public final  String processName;
	public HashSet<String> pkgList = new HashSet<>();
	public int pid;
	public int vuid;
	public int vpid;
	public int userId;


	public ProcessInfo(ProcessRecord processRecord) {
		this.info = processRecord.info;
		this.processName = processRecord.processName;
		this.pkgList = processRecord.pkgList;
		this.pid = processRecord.pid;
		this.vpid = processRecord.vpid;
		this.vuid = processRecord.vuid;
		this.userId = processRecord.userId;

	}


	protected ProcessInfo(Parcel in) {
		info = in.readParcelable(ApplicationInfo.class.getClassLoader());
		processName = in.readString();
		List<String> pkgListAsList = new ArrayList<>();
		in.readStringList(pkgListAsList);
		pkgList.addAll(pkgListAsList);
		pid = in.readInt();
		vuid = in.readInt();
		vpid = in.readInt();
		userId = in.readInt();
	}

	public static final Creator<ProcessInfo> CREATOR = new Creator<ProcessInfo>() {
		@Override
		public ProcessInfo createFromParcel(Parcel in) {
			return new ProcessInfo(in);
		}

		@Override
		public ProcessInfo[] newArray(int size) {
			return new ProcessInfo[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeParcelable(info, flags);
		dest.writeString(processName);
		dest.writeStringList(new ArrayList<>(pkgList));
		dest.writeInt(pid);
		dest.writeInt(vuid);
		dest.writeInt(vpid);
		dest.writeInt(userId);
	}

	@Override
	public String toString() {
		return "ProcessInfo{" +
				"info=" + info +
				", processName='" + processName + '\'' +
				", pkgList=" + pkgList +
				", pid=" + pid +
				", vuid=" + vuid +
				", vpid=" + vpid +
				", userId=" + userId +
				'}';
	}
}
