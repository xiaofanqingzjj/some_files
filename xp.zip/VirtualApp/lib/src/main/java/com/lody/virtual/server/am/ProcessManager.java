package com.lody.virtual.server.am;

import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Process;
import android.os.RemoteException;

import com.lody.virtual.client.IVClient;
import com.lody.virtual.client.env.Constants;
import com.lody.virtual.client.ipc.ProviderCall;
import com.lody.virtual.client.stub.VASettings;
import com.lody.virtual.helper.collection.ArrayMap;
import com.lody.virtual.helper.collection.SparseArray;
import com.lody.virtual.helper.compat.ApplicationThreadCompat;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.os.VUserHandle;

import java.util.ArrayList;
import java.util.List;


/**
 * VAMS的进程管理器
 */
public class ProcessManager {

    static final String TAG = "ProcessManager";

    /**
     * 当前运行的进程记录
     */
    private final ProcessMap<ProcessRecord> mProcessNames = new ProcessMap<>();
    private final SparseArray<ProcessRecord> mPidsSelfLocked = new SparseArray<>();

    private ProcessObserver observer;

    /**
     * 添加一个进程记录
     *
     * @param processRecord 进程记录
     */
    synchronized void add(ProcessRecord processRecord) {
        VLog.i(TAG, "add:" + processRecord);
        // 把进程保存到VAMS
        mProcessNames.put(processRecord.processName, processRecord.vuid, processRecord);
        mPidsSelfLocked.put(processRecord.pid, processRecord);

        // 通知观察者
        if (observer != null) {
            observer.onProcessCreated(processRecord.toParcelable());
        }
    }

    synchronized List<ProcessRecord> allProcessList() {
        List<ProcessRecord> records = sparseArrayToList(mPidsSelfLocked);
        VLog.i(TAG, "allProcessList:" + records);
        return records;
    }

    public void setProcessObserver(ProcessObserver observer) {
        this.observer = observer;
    }

    public void unregisterProcessObserver(ProcessObserver observer) {
        this.observer = null;
    }


    private static <T> List<T> sparseArrayToList(SparseArray<T> sparseArray) {
        List<T> list = new ArrayList<>();
        for (int i = 0; i < sparseArray.size(); i++) {
            list.add(sparseArray.valueAt(i));
        }
        return list;
    }

    /**
     * 删除一个进程记录
     *
     * @param processRecord
     */
    synchronized void remove(ProcessRecord processRecord) {
        VLog.i(TAG, "remove:" + processRecord);
        // 从进程列表中删除
        mProcessNames.remove(processRecord.processName, processRecord.vuid);
        mPidsSelfLocked.remove(processRecord.pid);

        // 通知观察者
        // 通知观察者
        if (observer != null) {
            observer.onProcessDied(processRecord.toParcelable());
        }
    }


    /**
     * 当前运行的进程数
     */
    synchronized int count() {
        return mPidsSelfLocked.size();
    }

    /**
     * 根据pid查找进程记录
     */
    synchronized ProcessRecord findProcess(int pid) {
        return findProcessLocked(pid);
    }

    ProcessRecord findProcessLocked(int pid) {
        return mPidsSelfLocked.get(pid);
    }


    synchronized ProcessRecord findProcess(String processName, int vuid) {
        return findProcessLocked(processName, vuid);
    }

    public ProcessRecord findProcessLocked(String processName, int vuid) {
        return mProcessNames.get(processName, vuid);
    }

    /**
     * 根据pid获取进程的vuid
     */
    int getUidByPid(int pid) {
        ProcessRecord r = findProcessLocked(pid);
        if (r != null) {
            return r.vuid;
        }
        return -1;
    }


    /**
     * 获取一个可用的vpid
     */
    synchronized int queryFreeStubProcessPid() {
        for (int vpid = 0; vpid < VASettings.STUB_COUNT; vpid++) {
            int N = mPidsSelfLocked.size();
            boolean using = false;
            while (N-- > 0) {
                ProcessRecord r = mPidsSelfLocked.valueAt(N);
                if (r.vpid == vpid) {
                    using = true;
                    break;
                }
            }
            if (using) {
                continue;
            }
            return vpid;
        }
        return -1;
    }

    /**
     * 关闭所有的进程
     */
    synchronized void killAllApps() {
        for (int i = 0; i < mPidsSelfLocked.size(); i++) {
            ProcessRecord r = mPidsSelfLocked.valueAt(i);
            killProcess(r.pid);
        }
    }

    private static void killProcess(int pid) {
        try {
            Process.killProcess(pid);
        } catch (Exception e) {
            VLog.w(TAG, "killProcess error", e);
        }
    }


    /**
     * 关闭目标包名的进程，除了指定的用户id
     * @param userId
     */
    synchronized void killAppByPackageNameUnlessUser(final String packageName, int userId) {
        ArrayMap<String, SparseArray<ProcessRecord>> map = mProcessNames.getMap();
        int N = map.size();
        while (N-- > 0) {
            SparseArray<ProcessRecord> uids = map.valueAt(N);
            for (int i = 0; i < uids.size(); i++) {
                ProcessRecord r = uids.valueAt(i);
                if (r.pkgList.contains(packageName)) {
                    if (userId != r.userId) {
                        killProcess(r.pid);
                    }
                }
            }
        }
    }

    /**
     * 关闭指定的进程
     *
     * @param packageName 包名
     * @param userId      分身用户id
     */
    synchronized void killAppByPackageName(final String packageName, int userId) {
        ArrayMap<String, SparseArray<ProcessRecord>> map = mProcessNames.getMap();
        int N = map.size();
        while (N-- > 0) {
            SparseArray<ProcessRecord> uids = map.valueAt(N);
            for (int i = 0; i < uids.size(); i++) {
                ProcessRecord r = uids.valueAt(i);
                if (userId != VUserHandle.USER_ALL) {
                    if (r.userId != userId) {
                        continue;
                    }
                }

                // 关闭所有包名为目标包名的进程
                if (r.pkgList.contains(packageName)) {
                    killProcess(r.pid);
                }
            }
        }
    }

    /**
     * 判断某个app的进程是否存在
     *
     * @param packageName
     * @param userId
     * @return
     */
    synchronized boolean isAppRunning(String packageName, int userId) {
        boolean running = false;
        int N = mPidsSelfLocked.size();
        while (N-- > 0) {
            ProcessRecord r = mPidsSelfLocked.valueAt(N);
            if (r.userId == userId && r.info.packageName.equals(packageName)) {
                running = true;
                break;
            }
        }
        VLog.i(TAG, "isAppRunning packageName:" + packageName + ", userId:" + userId + ", running:" + running);
        return running;
    }

    /**
     * @param processName
     * @param uid
     */
    synchronized void killApplicationProcess(final String processName, int uid) {
        ProcessRecord r = mProcessNames.get(processName, uid);
        if (r != null) {
            killProcess(r.pid);
        }
    }

    /**
     * 关闭特定用户下所有的进程
     *
     * @param userId
     * @return
     */
    synchronized int stopUser(int userId) {
        int N = mPidsSelfLocked.size();
        while (N-- > 0) {
            ProcessRecord r = mPidsSelfLocked.valueAt(N);
            if (r.userId == userId) {
                killProcess(r.pid);
            }
        }
        return 0;
    }


    /**
     * 创建进程
     * @param vuid vuid
     * @param vpid vpid
     * @param info app信息
     * @param processName 进程名
     * @param processDead 进程死亡监听
     * @return 进程记录
     */
    ProcessRecord performStartProcessLocked(int vuid, int vpid, ApplicationInfo info, String processName, final OnProcessDead processDead) {

        VLog.i(TAG,"performStartProcessLocked vuid:" + vuid + ", vpid:" + vpid + ", processName:" + processName + ", info:" + info);

        final ProcessRecord processRecord = new ProcessRecord(info, processName, vuid, vpid);

        Bundle extras = new Bundle();
        extras.putBinder(Constants.VA_BINDER, processRecord);
        extras.putInt(Constants.VA_VUID, vuid);
        extras.putString(Constants.VA_PROCESS, processName);
        extras.putString(Constants.VA_PKG, info.packageName);

        /*
         * 调用ContentProvider的一个方法，因为ContentProvider被声明成在独立的进程运行，这时候系统会为其创建一个进程
         */
        Bundle res = ProviderCall.call(VASettings.getStubAuthority(vpid), Constants.VA_INIT_PROCESS, null, extras);
        if (res == null) {
            VLog.e(TAG,"call ProviderCall.call failed" );
            return null;
        }

        // 返回操作系统分配的pid
        final int pid = res.getInt(Constants.VA_PID);
        // 获取进程返回的VClientImpl对象
        final IBinder vClient = res.getBinder(Constants.VA_CLIENT);
        if (vClient == null) {
            VLog.e(TAG,"Get VA_CLIENT error" );
            return null;
        }


        attachClient(processRecord, pid, vClient, processDead);
        add(processRecord);

        return processRecord;
    }


    /**
     * 关联进程记录和客户端进程
     * 1.进程记录持有客户端进程的ApplicationThread
     * 2.把进程记录对象给VClientImpl保存
     * 3.监听vClient是否被杀
     *
     * 保存进程记录到VAMS
     * @param pid 进程id
     * @param vClient VClientImpl对象
     */
    private void attachClient(final ProcessRecord processRecord, final int pid, final IBinder vClient, final OnProcessDead processDead) {

        // 监听客户端进程是否被杀
        try {
            vClient.linkToDeath(new IBinder.DeathRecipient() {
                @Override
                public void binderDied() {
                    VLog.e(TAG, "onProcess Died pid:" + pid + ", name:" + processRecord.processName);
                    vClient.unlinkToDeath(this, 0);

                    // 删除进程记录
                    remove(processRecord);
                    // 通知任务栈，删除栈里对应进程的任务
                    if (processDead != null) {
                        processDead.onProcessDead(processRecord);
                    }
                }
            }, 0);
        } catch (RemoteException e) {
            VLog.e(TAG, "", e);
        }

        // 保存进程记录到VAMS

        // 还原IVClient接口
        final IVClient client = IVClient.Stub.asInterface(vClient);
        if (client == null) {
            Process.killProcess(pid);
            return;
        }

        ProcessRecord app = null;
        try {
            IBinder token = client.getToken();
            if (token instanceof ProcessRecord) {
                app = (ProcessRecord) token;
            }
            VLog.i(TAG, "getRemoteProcessRecord:" + token + ", app:" + app);
        } catch (RemoteException e) {
            // process has dead
        }

        // 获取进程的ApplicationThread对象
        IInterface thread = null;
        try {
            thread = ApplicationThreadCompat.asInterface(client.getAppThread());
        } catch (RemoteException e) {
            // process has dead
            VLog.e(TAG, "", e);
        }
        if (thread == null) {
            Process.killProcess(pid);
            return;
        }



        processRecord.client = client;
        processRecord.appThread = thread;
        processRecord.pid = pid;
    }

    interface OnProcessDead {
        void onProcessDead(ProcessRecord processRecord);
    }

    interface ProcessObserver {
        void onProcessCreated(com.lody.virtual.server.ProcessInfo processInfo);

        void onProcessDied(com.lody.virtual.server.ProcessInfo processInfo);
    }
}
