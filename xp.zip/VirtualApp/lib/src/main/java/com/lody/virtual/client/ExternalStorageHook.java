package com.lody.virtual.client;

import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;

import com.lody.virtual.os.VUserHandle;

import java.io.File;

import mirror.android.app.ContextImpl;

/* compiled from: ExternalStorageHook.java */
/* loaded from: classes.dex */
public class ExternalStorageHook {

//    /* renamed from: a */
//    private static final boolean isFeatureAEnabled = Features.f6476a;
//
//    /* renamed from: b */
//    private static final boolean isFeatureBEnabled = Features.f6477b;
//
//    /* renamed from: c */
//    private static final String TAG = ExternalStorageHook.class.getSimpleName();
//
//
//    public static void handleContext(Context context, Context context2) {
//        try {
//            processContext(context, context2);
//        } catch (Exception unused) {
//            // ignore
//        }
//    }
//
//
//    /**
//     *
//     * @param context
//     * @param context2
//     * @throws ClassNotFoundException
//     */
//    private static void processContext(Context context, Context context2) throws ClassNotFoundException {
//        if (context2 == null) {
//            return;
//        }
//        if (context2 instanceof ContextWrapper) {
//            context2 = ((ContextWrapper) context2).getBaseContext();
//        }
//        if (ContextImpl.isInstance(context2)) {
//            if (Build.VERSION.SDK_INT > 10) {
//                context2.getObbDir();
//            }
//            context2.getExternalCacheDir();
//            context2.getExternalFilesDir(null);
//
//            if (Build.VERSION.SDK_INT >= 21) {
//                context2.getExternalMediaDirs();
//            }
//            ContextImpl.mObbDir(context2);
//
//            File mExternalFilesDir = ContextImpl.mExternalFilesDir(context2);
//            File mExternalCacheDir = ContextImpl.mExternalCacheDir(context2);
//
//            ContextImpl.mExternalObbDirs(context2);
//
//            File[] mExternalFilesDirs = ContextImpl.mExternalFilesDirs(context2);
//            File[] mExternalCacheDirs = ContextImpl.mExternalCacheDirs(context2);
//            File[] mExternalMediaDirs = ContextImpl.mExternalMediaDirs(context2);
//
//
//            String appExtStoragePath = context.getPackageName() + File.separator + getVirualAppExtenalRelationPath(VUserHandle.myUserId(), context2.getPackageName());
//
//            String packageName = context2.getPackageName();
//            if (mExternalFilesDir != null) {
//                ContextImpl.mExternalFilesDir(context2, replaceFilePath(mExternalFilesDir, packageName, appExtStoragePath));
//            }
//            if (mExternalCacheDir != null) {
//                ContextImpl.mExternalCacheDir(context2, replaceFilePath(mExternalCacheDir, packageName, appExtStoragePath));
//            }
//            if (mExternalFilesDirs != null) {
//                for (int i2 = 0; i2 < mExternalFilesDirs.length; i2++) {
//                    mExternalFilesDirs[i2] = replaceFilePath(mExternalFilesDirs[i2], packageName, appExtStoragePath);
//                }
//            }
//            if (mExternalCacheDirs != null) {
//                for (int i3 = 0; i3 < mExternalCacheDirs.length; i3++) {
//                    mExternalCacheDirs[i3] = replaceFilePath(mExternalCacheDirs[i3], packageName, appExtStoragePath);
//                }
//            }
//            if (mExternalMediaDirs != null) {
//                for (int i4 = 0; i4 < mExternalMediaDirs.length; i4++) {
//                    mExternalMediaDirs[i4] = replaceFilePath(mExternalMediaDirs[i4], packageName, appExtStoragePath);
//                }
//            }
//            if (Build.VERSION.SDK_INT > 10) {
//                context2.getObbDir();
//            }
//            context2.getExternalCacheDir();
//            context2.getExternalFilesDir(null);
//            if (Build.VERSION.SDK_INT >= 21) {
//                context2.getExternalMediaDirs();
//            }
//        }
//    }
//
//    private static String getVirualAppExtenalRelationPath(int userId, String packageName) {
//        return Env.VIRTUAL_ENVIRONMENT + File.separator + userId + File.separator + packageName + File.separator;
//    }
//
//    private static File replaceFilePath(File file, String oldPath, String newPath) {
//        String absolutePath = file.getAbsolutePath();
//        return absolutePath.indexOf(newPath) > 0 ? file : new File(absolutePath.replace(oldPath, newPath));
//    }
}
