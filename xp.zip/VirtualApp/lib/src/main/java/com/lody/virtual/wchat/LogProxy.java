package com.lody.virtual.wchat;

import android.app.Application;
import android.util.Log;
import android.util.Pair;

import com.lody.virtual.client.hook.base.MethodInvocationStub;
import com.lody.virtual.client.hook.base.MethodProxy;

import java.lang.reflect.Field;
import java.lang.reflect.Method;


/**
 * hook 微信 8.0.53版本的日志打印，用来分析微信不能登录的问题
 */
public class LogProxy extends MethodInvocationStub<Object> {

    static final String TAG = "LogProxy";

    // 微信业务log类
    static final String BIZ_LOG_CLASS = "com.tencent.mm.sdk.platformtools.l2";

    // log接口
    static final String LOG_INTERFACE = "com.tencent.mm.sdk.platformtools.n2";

    /**
     * 是否hook微信的日志
     */
    static final boolean isHookWChatLog = false;


    private static void printClassStaticFields(Class<?> clazz) {
        Log.d(TAG, clazz + ": Static fields of " + clazz.getName() + ":");
        Field[] fields = clazz.getDeclaredFields();

        for (Field field : fields) {
            // 检查字段是否是静态的
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                try {
                    // 获取静态字段的值
                    Object value = field.get(null); // null 因为是静态字段
                    Log.d(TAG, field.getName() + " = " + value);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * hook微信的log
     */
    public static void hookWChatLog(Application app, String processName) {
        if (!isHookWChatLog) {
            return;
        }

        Log.i(TAG, "hookWChatLog processName:" + processName);
        try {
            // 获取 MyClass 的 Class 对象
            Class<?> bizLog = app.getClassLoader().loadClass(BIZ_LOG_CLASS);
            printClassStaticFields(bizLog);

            // 替换log的实现类
            Field mLogF = bizLog.getField("b");
            Log.d(TAG, "logField:" + mLogF.get(null));
            Object value = mLogF.get(null); //因为是静态字段
            if (value != null) {
                LogProxy logProxy = new LogProxy(value, app.getClassLoader());
                mLogF.setAccessible(true);
                // 修改静态字段
                mLogF.set(null, logProxy.getProxyInterface());
            }
            // 修改logLevel
            Field logLevel = bizLog.getField("a");
            logLevel.setAccessible(true);
            logLevel.set(null, 0);

            printClassStaticFields(bizLog);

        } catch (Exception e) {
            Log.e(TAG, "hookWChatLog Error:", e);
        }
    }

    public LogProxy(Object baseInterface, ClassLoader classLoader) {
        super(baseInterface, getLogClass(classLoader));
        init();
    }

    private static Class<?> getLogClass(ClassLoader classLoader) {
        try {
            return classLoader.loadClass(LOG_INTERFACE);
        } catch (ClassNotFoundException e) {
            Log.w(TAG, "forName " + LOG_INTERFACE + " error:", e);
            return null;
        }
    }

    private static Pair<String, String> parse(Object[] args) {
        final String tag = (String) args[1];
        final int tid = (int) args[4];
        final int pid = (int) args[5];
        final long threadId = (long) args[6];
        final long mainThreadId = (long) args[7];
        final String msg = (String) args[8];
        return new Pair<>(tag,  msg + "[" + "tid:" + tid + ", pid:" + pid + ", threadId:" + threadId + ", mainThreadId:" + mainThreadId + "]");
    }

    void init() {
        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logD";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.d(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logE";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.e(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logF";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.e(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logI";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.i(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logV";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.v(result.first, result.second);
                return super.call(who, method, args);
            }
        });

        addMethodProxy(new MethodProxy() {
            @Override
            public String getMethodName() {
                return "logW";
            }

            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                Pair<String, String> result = parse(args);
                Log.w(result.first, result.second);
                return super.call(who, method, args);
            }
        });
    }
}
