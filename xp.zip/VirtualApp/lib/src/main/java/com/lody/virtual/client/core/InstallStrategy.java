package com.lody.virtual.client.core;

/**
 * 安装策略
 * @author Lody
 *
 *
 */
public interface InstallStrategy {

	/**
	 * 如果已经存在则终止安装
	 */
	int TERMINATE_IF_EXIST = 0x01 << 1;

	/**
	 * 如果已经存在则更新安装
	 */
	int UPDATE_IF_EXIST = 0x01 << 2;

	/**
	 * 比较版本号,如果已经安装的版本号大于等于新版本,则不安装
	 */
	int COMPARE_VERSION = 0X01 << 3;

	/**
	 * 忽略新版本
	 */
	int IGNORE_NEW_VERSION = 0x01 << 4;

	/**
	 * 如果系统已经安装了这个应用,则依赖系统安装
	 */
	int DEPEND_SYSTEM_IF_EXIST = 0x01 << 5;

	/**
	 * 跳过dexopt优化
	 */
	int SKIP_DEX_OPT = 0x01 << 6;
}
