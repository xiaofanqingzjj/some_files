package com.lody.virtual.client.ipc;

import android.app.Activity;
import android.content.pm.ActivityInfo;

public class ActivityClientRecord {
	public Activity activity;
	public ActivityInfo info;
}