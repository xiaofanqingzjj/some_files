package com.lody.virtual.helper.utils;


import android.util.SparseArray;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Provides some tool methods for manipulating collections
 */
public class CollectionUtils {

    static final String TAG = "CollectionUtils";

    @FunctionalInterface
    public interface Convert<S, T> {
        T convert(S s);
    }


    /**
     * 把一个List转成Set
     */
    public static <S, T> Set<T> toSet(Collection<S> source, Convert<S, T> convert) {
        Set<T> result = new HashSet<>();
        for (S i : source) {
            result.add(convert.convert(i));
        }
        return result;
    }


    @FunctionalInterface
    public interface Condition<T> {
        boolean test(T t);
    }

    public static <E> E find(SparseArray<E> sparseArray, Condition<E> condition) {
        for (int i = 0; i < sparseArray.size(); i++) {
            E r = sparseArray.valueAt(i);
            if (condition.test(r)) {
                return r;
            }
        }
        return null;
    }

    public static <E> void remove(SparseArray<E> sparseArray, Condition<Integer> condition) {
        // 从后向前遍历
        for (int i = sparseArray.size() - 1; i >= 0; i--) {
            int key = sparseArray.keyAt(i);
            if (condition.test(key)) {
                sparseArray.remove(key);
            }
        }
    }

    public static <E> void remove2(SparseArray<E> sparseArray, Condition<E> condition) {
        // 从后向前遍历
        for (int i = sparseArray.size() - 1; i >= 0; i--) {
            E key = sparseArray.valueAt(i);
            if (condition.test(key)) {
                sparseArray.removeAt(i);
            }
        }
    }



}

