package com.lody.virtual.client.env;

import android.content.Intent;

import com.lody.virtual.client.stub.ShortcutHandleActivity;
import com.lody.virtual.helper.utils.EncodeUtils;

import java.util.Arrays;
import java.util.List;

/**
 * @author Lody
 *
 */
public class Constants {

	public static final String EXTRA_USER_HANDLE = "android.intent.extra.user_handle";
	/**
	 * If an apk declared the "fake-signature" attribute on its Application TAG,
	 * we will use its signature instead of the real signature.
	 *
	 * For more detail, please see :
	 * https://github.com/microg/android_packages_apps_GmsCore/blob/master/
	 * patches/android_frameworks_base-M.patch.
	 */
	public static final String FEATURE_FAKE_SIGNATURE = "fake-signature";
	public static final String ACTION_PACKAGE_ADDED = "virtual." + Intent.ACTION_PACKAGE_ADDED;
	public static final String ACTION_PACKAGE_REMOVED = "virtual." + Intent.ACTION_PACKAGE_REMOVED;
	public static final String ACTION_PACKAGE_CHANGED = "virtual." + Intent.ACTION_PACKAGE_CHANGED;
	public static final String ACTION_USER_ADDED = "virtual." + "android.intent.action.USER_ADDED";
	public static final String ACTION_USER_REMOVED = "virtual." + "android.intent.action.USER_REMOVED";
	public static final String ACTION_USER_INFO_CHANGED = "virtual." + "android.intent.action.USER_CHANGED";
	public static final String ACTION_USER_STARTED = "Virtual." + "android.intent.action.USER_STARTED";
	public static String META_KEY_IDENTITY = "X-Identity";
	public static String META_VALUE_STUB = "Stub-User";

	public static String NO_NOTIFICATION_FLAG = ".no_notification";
	public static String FAKE_SIGNATURE_FLAG = ".fake_signature";

	public static final String WECHAT_PACKAGE = EncodeUtils.decode("Y29tLnRlbmNlbnQubW0="); // wechat
	public static final List<String> PRIVILEGE_APP = Arrays.asList(
			WECHAT_PACKAGE,
			EncodeUtils.decode("Y29tLnRlbmNlbnQubW9iaWxlcXE=")); // qq

	/**
	 * Server process name of VA
	 */
	public static String SERVER_PROCESS_NAME = ":x";
	/**
	 * The activity who handle the shortcut.
	 */
	public static String SHORTCUT_PROXY_ACTIVITY_NAME = ShortcutHandleActivity.class.getName();

	public static final String PASS_PKG_NAME_ARGUMENT = "MODEL_ARGUMENT";
	public static final String PASS_KEY_INTENT = "KEY_INTENT";
	public static final String PASS_KEY_USER = "KEY_USER";



	// 一些通用的常量
	public static final String VA_INTENT = "_VA_|_intent_";
	public static final String VA_UID = "_VA_|_uid_";

	public static final String VA_URI = "_VA_|_uri_";

	public static final String VA_FROM_INNER = "_VA_|_from_inner_";

	public static final String VA_USER_ID = "_VA_|_user_id_";

	public static final String VA_CREATOR = "_VA_|_creator_";

	public static final String VA_INFO = "_VA_|_info_";


	public static final String VA_CALLER = "_VA_|_caller_";

	public static final String VA_BINDER = "_VA_|_binder_";

	public static final String VA_VUID = "_VA_|_vuid_";

	public static final String VA_PROCESS = "_VA_|_process_";

	public static final String VA_PKG = "_VA_|_pkg_";

	public static final String VA_INIT_PROCESS = "_VA_|_init_process_";

	public static final String VA_PID = "_VA_|_pid_";

	public static final String VA_CLIENT = "_VA_|_client_";

	public static final String VA_SPLASH = "_VA_|_splash_";

	public static final String VA_COMPONENT = "_VA_|_component_";

	public static final String VA_PRIVILEGE_PKG = "_VA_|_privilege_pkg_";

	public static final String VA_SENDER = "_VA_|_sender_";

	public static final String VA_UI_CALLBACK = "_VA_|_ui_callback_";
}
