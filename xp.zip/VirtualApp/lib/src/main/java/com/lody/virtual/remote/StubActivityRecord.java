package com.lody.virtual.remote;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;

import com.lody.virtual.client.env.Constants;

/**
 * @author Lody
 */

public class StubActivityRecord  {
        public Intent intent;
        public ActivityInfo info;
        public ComponentName caller;
        public int userId;

        public StubActivityRecord(Intent intent, ActivityInfo info, ComponentName caller, int userId) {
            this.intent = intent;
            this.info = info;
            this.caller = caller;
            this.userId = userId;
        }

        public StubActivityRecord(Intent stub) {
            this.intent = stub.getParcelableExtra(Constants.VA_INTENT);
            this.info = stub.getParcelableExtra(Constants.VA_INFO);
            this.caller = stub.getParcelableExtra(Constants.VA_CALLER);
            this.userId = stub.getIntExtra(Constants.VA_USER_ID, 0);
        }

    public void saveToIntent(Intent stub) {
        stub.putExtra(Constants.VA_INTENT, intent);
        stub.putExtra(Constants.VA_INFO, info);
        stub.putExtra(Constants.VA_CALLER, caller);
        stub.putExtra(Constants.VA_USER_ID, userId);
    }

    @Override
    public String toString() {
        return "StubActivityRecord{" +
                "intent=" + intent +
                ", info=" + info +
                ", caller=" + caller +
                ", userId=" + userId +
                '}';
    }
}
