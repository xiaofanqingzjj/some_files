package com.lody.virtual.client;

import static com.lody.virtual.os.VUserHandle.getUserId;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.Instrumentation;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.os.Binder;
import android.os.Build;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;

import com.lody.virtual.client.core.CrashHandler;
import com.lody.virtual.client.core.InvocationStubManager;
import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.env.SpecialComponentList;
import com.lody.virtual.client.env.VirtualRuntime;
import com.lody.virtual.client.fixer.ContextFixer;
import com.lody.virtual.client.hook.delegate.AppInstrumentation;
import com.lody.virtual.client.hook.providers.ProviderHook;
import com.lody.virtual.client.hook.proxies.am.HCallbackStub;
import com.lody.virtual.client.hook.secondary.ProxyServiceFactory;
import com.lody.virtual.client.ipc.VActivityManager;
import com.lody.virtual.client.ipc.VDeviceManager;
import com.lody.virtual.client.ipc.VPackageManager;
import com.lody.virtual.client.stub.VASettings;
import com.lody.virtual.helper.compat.BuildCompat;
import com.lody.virtual.helper.utils.StackTraceUtil;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.os.VUserHandle;
import com.lody.virtual.remote.InstalledAppInfo;
import com.lody.virtual.remote.PendingResultData;
import com.lody.virtual.remote.VDeviceInfo;
import com.lody.virtual.server.interfaces.IUiCallback;
import com.lody.virtual.server.pm.VAppManager;

import org.jdeferred.android.AndroidDeferredManager;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import me.weishu.exposed.ExposedBridge;
import mirror.android.app.ActivityThread;
import mirror.android.app.ActivityThreadNMR1;
import mirror.android.app.ContextImpl;
import mirror.android.app.IActivityManager;
import mirror.android.app.LoadedApk;
import mirror.android.content.ContentProviderHolderOreo;
import mirror.android.providers.Settings;
import mirror.android.renderscript.RenderScriptCacheDir;
import mirror.android.security.net.config.ApplicationConfig;
import mirror.android.view.HardwareRenderer;
import mirror.android.view.RenderScript;
import mirror.android.view.ThreadedRenderer;
import mirror.com.android.internal.content.ReferrerIntent;
import mirror.dalvik.system.VMRuntime;


/**
 * @author Lody
 */
public final class VClientImpl extends IVClient.Stub {

    private static final int NEW_INTENT = 11;
    private static final int RECEIVER = 12;

    private static final String TAG = VClientImpl.class.getSimpleName();
    @SuppressLint("StaticFieldLeak")
    private static final VClientImpl gClient = new VClientImpl();
    private final H mH = new H();
    private ConditionVariable mTempLock;
//    private Instrumentation mInstrumentation = AppInstrumentation.getDefault();

    // 这是一个ProcessRecord对象，表示当前的进程对象
    private IBinder token;
    private int vuid;
    private VDeviceInfo deviceInfo;
    private AppBindData mBoundApplication;
    private Application mInitialApplication;
    CrashHandler crashHandler;
    private IUiCallback mUiCallback;

    AndroidDeferredManager mDeferredManager = new AndroidDeferredManager();

    public static VClientImpl get() {
        return gClient;
    }

    public boolean isBound() {
        return mBoundApplication != null;
    }

    public VDeviceInfo getDeviceInfo() {
        if (deviceInfo == null) {
            synchronized (this) {
                if (deviceInfo == null) {
                    deviceInfo = VDeviceManager.get().getDeviceInfo(getUserId(vuid));
                }
            }
        }
        return deviceInfo;
    }

    public Application getCurrentApplication() {
        return mInitialApplication;
    }

    public String getCurrentPackage() {
        return mBoundApplication != null ?
                mBoundApplication.appInfo.packageName : VPackageManager.get().getNameForUid(getVUid());
    }

    public ApplicationInfo getCurrentApplicationInfo() {
        return mBoundApplication != null ? mBoundApplication.appInfo : null;
    }

    public CrashHandler getCrashHandler() {
        return crashHandler;
    }

    public void setCrashHandler(CrashHandler crashHandler) {
        this.crashHandler = crashHandler;
    }

    /**
     * 当前进程的vuid, 它是userId和appId的混合
     * @return
     */
    public int getVUid() {
        return vuid;
    }

    public int getBaseVUid() {
        return VUserHandle.getAppId(vuid);
    }

    public ClassLoader getClassLoader(ApplicationInfo appInfo) {
        Context context = createPackageContext(appInfo.packageName);
        return context.getClassLoader();
    }

    public ClassLoader getClassLoader(String packageName) {
        Context context = createPackageContext(packageName);
        return context.getClassLoader();
    }

    private void sendMessage(int what, Object obj) {
        Message msg = Message.obtain();
        msg.what = what;
        msg.obj = obj;
        mH.sendMessage(msg);
    }

    @Override
    public IBinder getAppThread() {
        return ActivityThread.getApplicationThread.call(VirtualCore.mainThread());
    }

    @Override
    public IBinder getToken() {
        return token;
    }

    public void initProcess(IBinder token, int vuid) {
        this.token = token;
        this.vuid = vuid;
    }

    private void handleNewIntent(NewIntentData data) {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            intent = ReferrerIntent.ctor.newInstance(data.intent, data.creator);
        } else {
            intent = data.intent;
        }
        if (ActivityThread.performNewIntents != null) {
            ActivityThread.performNewIntents.call(
                    VirtualCore.mainThread(),
                    data.token,
                    Collections.singletonList(intent)
            );
        } else {
            if (BuildCompat.isQ()) {
                ActivityThread.handleNewIntent.call(VirtualCore.mainThread(), data.token, Collections.singletonList(intent));
            } else {
                ActivityThreadNMR1.performNewIntents.call(
                        VirtualCore.mainThread(),
                        data.token,
                        Collections.singletonList(intent),
                        true);
            }
        }
    }

    public void bindApplicationForActivity(final String packageName, final String processName, final Intent intent) {
        VLog.d(TAG, "bindApplicationForActivity packageName:" + packageName + ", processName:" + processName + ", intent:" + intent);
        mUiCallback = VirtualCore.getUiCallback(intent);
        bindApplication(packageName, processName);
    }

    public void bindApplication(final String packageName, final String processName) {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            bindApplicationNoCheck(packageName, processName, new ConditionVariable());
        } else {
            final ConditionVariable lock = new ConditionVariable();
            VirtualRuntime.getUIHandler().post(new Runnable() {
                @Override
                public void run() {
                    bindApplicationNoCheck(packageName, processName, lock);
                    lock.open();
                }
            });
            lock.block();
        }
    }


    private void log( long start, String processName, String msg) {
        long time = System.currentTimeMillis() - start;
        VLog.d(TAG, "[" + processName + "] time:" + time + ", " +  msg);
    }

    private void bindApplicationNoCheck(final String packageName, String pName, ConditionVariable lock) {
        long start = System.currentTimeMillis();
        if (pName == null) {
            pName = packageName;
        }
        final String processName = pName;
        mTempLock = lock;
//        try {
        ClientUncactchCrashHandler.setupUncaughtHandler();
//        } catch (Throwable e) {
//            e.printStackTrace();
//        }
        try {
            fixInstalledProviders();
        } catch (Throwable e) {
            e.printStackTrace();
        }

        final VDeviceInfo deviceInfo = getDeviceInfo();
        mirror.android.os.Build.SERIAL.set(deviceInfo.serial);
        mirror.android.os.Build.DEVICE.set(Build.DEVICE.replace(" ", "_"));
        ActivityThread.mInitialApplication.set(
                VirtualCore.mainThread(),
                null
        );



        // 先获取安装信息
        InstalledAppInfo installedAppInfo = VirtualCore.get().getInstalledAppInfo(packageName, 0);
        // 安装信息不存在直接关闭进程直接退出
        if (installedAppInfo == null) {
            new Exception("App not exist!").printStackTrace();
            Process.killProcess(0);
            System.exit(0);
        }


        log(start, processName, "bindApplicationNoCheck packageName:" + packageName + ", processName:" + processName + ", getInstalledAppInfo:" + installedAppInfo + ", stack:" + StackTraceUtil.getCurrentStackTrace());

        // 要运行的应用信息
        final AppBindData appBindData = new AppBindData();
        // 获取虚拟机里的ApplicationInfo
        appBindData.appInfo = VPackageManager.get().getApplicationInfo(packageName, 0, getUserId(vuid));

        // 进程名
        appBindData.processName = processName;

        // 进程名
        appBindData.appInfo.processName = processName;

        // app的ContentProvider信息
        appBindData.providers = VPackageManager.get().queryContentProviders(processName, getVUid(), PackageManager.GET_META_DATA);
        VLog.i(TAG, String.format("Binding application %s, (%s)", appBindData.appInfo.packageName, appBindData.processName));

        // 当前进程要绑定的App信息
        mBoundApplication = appBindData;

        // 修改进程名为目标包名
        log(start, processName,"setupRuntime:" + appBindData.processName);
        VirtualRuntime.setupRuntime(appBindData.processName, appBindData.appInfo);


//        // 这两端代码忽略
//        int targetSdkVersion = appBindData.appInfo.targetSdkVersion;
//        if (targetSdkVersion < Build.VERSION_CODES.GINGERBREAD) {
//            StrictMode.ThreadPolicy newPolicy = new StrictMode.ThreadPolicy.Builder(StrictMode.getThreadPolicy()).permitNetwork().build();
//            StrictMode.setThreadPolicy(newPolicy);
//        }
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && targetSdkVersion < Build.VERSION_CODES.LOLLIPOP) {
//            mirror.android.os.Message.updateCheckRecycle.call(targetSdkVersion);
//        }

        // io重新定向
        if (VASettings.ENABLE_IO_REDIRECT) {
            IORedirectHelper.startIOUniformer(deviceInfo, mBoundApplication);
            log(start, processName,"after startIOUniformer:");
        }

        log(start, processName, "NativeEngine.launchEngine()");

        // 加载安装好的包信息，用来给openDexFileNative时用
        NativeEngine.startDexOverride();

        // 开启引擎
        NativeEngine.launchEngine();

        // ActivityThread对象
        Object mainThread = VirtualCore.mainThread();


        // 根据目标apk创建Context， context可以加载目标apk的代码和资源，这里借助这个api获取目标app的LoadedApk对象
        //
        // 这里只有包名， 是怎么获取到包名在虚拟机中的路径的呢？
        // PackageManagerStub里拦截了getApplicationInfo()，获取了虚拟机的信息
        //
        // 借助这个api，我们获取了目标app的LoadedApk对象
        // 1.创建目标app的Context
        // 2.通过反射获取ContextImpl.mPackageInfo来获取目标app的LoadedApk对象
        //
        final Context appContext = createPackageContext(appBindData.appInfo.packageName);
        appBindData.loadApkInfo = ContextImpl.mPackageInfo.get(appContext);

        /* 这段代码注释掉了，也可以跑 */
//        try {

            // anti-virus, fuck ESET-NOD32: a variant of Android/AdDisplay.AdLock.AL potentially unwanted
            // we can make direct call... use reflect to bypass.
//             System.setProperty("java.io.tmpdir", context.getCacheDir().getAbsolutePath());
            // 这里直接可以调，为啥要用反射调用
        System.setProperty("java.io.tmpdir", appContext.getCacheDir().getAbsolutePath());
//            Reflect.on(System.class).call("setProperty", "java.io.tmpdir", appContext.getCacheDir().getAbsolutePath());
//            System.class.getDeclaredMethod("setProperty", String.class, String.class)
//                    .invoke(null, "java.io.tmpdir", appContext.getCacheDir().getAbsolutePath());
//        } catch (Throwable ignored) {
//            VLog.e(TAG, "set tmp dir error:", ignored);
//        }

        File codeCacheDir;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            codeCacheDir = appContext.getCodeCacheDir();
        } else {
            codeCacheDir = appContext.getCacheDir();
        }
        log(start, processName, "appContext.getCacheDir:" + codeCacheDir);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            if (HardwareRenderer.setupDiskCache != null) {
                HardwareRenderer.setupDiskCache.call(codeCacheDir);
            }
        } else {
            if (ThreadedRenderer.setupDiskCache != null) {
                ThreadedRenderer.setupDiskCache.call(codeCacheDir);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (RenderScriptCacheDir.setupDiskCache != null) {
                RenderScriptCacheDir.setupDiskCache.call(codeCacheDir);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            if (RenderScript.setupDiskCache != null) {
                RenderScript.setupDiskCache.call(codeCacheDir);
            }
        }
        /* end */




        // 获取ActivityThread的mBoundApplication:AppBindData对象, 这个对象用来关联进程目标app，也就是目标app的LoadedApk对象
        // 真实的对象为：ActivityThread$AppBindData
        final Object targetMBoundApplication = mirror.android.app.ActivityThread.mBoundApplication.get(mainThread);

        // 修改ActivityThread的appInfo、processName、instrumentationName、providers
        mirror.android.app.ActivityThread.AppBindData.appInfo.set(targetMBoundApplication, appBindData.appInfo);
        mirror.android.app.ActivityThread.AppBindData.processName.set(targetMBoundApplication, appBindData.processName);
        mirror.android.app.ActivityThread.AppBindData.instrumentationName.set(
                targetMBoundApplication,
                new ComponentName(appBindData.appInfo.packageName, Instrumentation.class.getName())
        );
        ActivityThread.AppBindData.providers.set(targetMBoundApplication, appBindData.providers);


        //
        // 把app的LoadedApk设置给ActivityThread.appBindData.info
        // 这样就完成了ActivityThread和目标app的关联
        //
        mirror.android.app.ActivityThread.AppBindData.info.set(targetMBoundApplication, appBindData.loadApkInfo);

        // 根据app的targetSdk把VMRuntime的targetSdkVersion设置为app的targetSdk
        // dalvik.system.VMRuntime.getRuntime().setTargetSdkVersion(appBindData.appInfo.targetSdkVersion);
        VMRuntime.setTargetSdkVersion.call(VMRuntime.getRuntime.call(), appBindData.appInfo.targetSdkVersion);

        boolean conflict = SpecialComponentList.ConflictInstrumentation.isConflictingInstrumentation(packageName);
        if (!conflict) {
            InvocationStubManager.getInstance().checkEnv(AppInstrumentation.class);
        }

        // 获取ApplicationInfo
        // appBindData.loadApkInfo.getApplicationInfo;
        final ApplicationInfo applicationInfo = LoadedApk.mApplicationInfo.get(appBindData.loadApkInfo);
        log(start, processName,"applicationInfo:" + applicationInfo);

        if (Build.VERSION.SDK_INT >= 26 && applicationInfo.splitNames == null) {
            applicationInfo.splitNames = new String[1];
        }


        boolean enableXposed = VirtualCore.get().isXposedEnabled();
        enableXposed = false;
        if (enableXposed) {
            VLog.i(TAG, "Xposed is enabled.");

            // 内部报错：java.lang.ClassNotFoundException: Didn't find class "androidx.core.app.CoreComponentFactory" on path: DexPathList[[zip file "/data/user/0/io.va.exposed64/virtual/data/app/com.laolaiwangtech/base.apk"],nativeLibraryDirectories=[/data/user/0/io.va.exposed64/virtual/data/app/com.laolaiwangtech/lib, /data/user/0/io.va.exposed64/virtual/data/app/com.laolaiwangtech/base.apk!/lib/arm64-v8a, /system/lib64, /product_h/lib64, /system_ext/lib64]]

            ClassLoader originClassLoader = null;
            try {
                originClassLoader = appContext.getClassLoader();
            } catch (Exception e) {
                VLog.w(TAG, "appContext.getClassLoader() error", e);
            }
            if (originClassLoader !=null) {
                ExposedBridge.initOnce(appContext, appBindData.appInfo, originClassLoader);

                List<InstalledAppInfo> modules = VAppManager.get().getInstalledApps(0);
                for (InstalledAppInfo module : modules) {
                    ExposedBridge.loadModule(module.apkPath, module.getOdexFile().getParent(), module.libPath,
                            appBindData.appInfo, originClassLoader);
                }
            }
            log(start, processName,"after xposed");
        } else {
            VLog.w(TAG, "Xposed is disable..");
        }




        ClassLoader cl = LoadedApk.getClassLoader.call(appBindData.loadApkInfo);
        log(start, processName,"LoadedApkClassLoader:" + cl);


//        if (BuildCompat.isS()) {
//            ClassLoader parent = cl.getParent();
//            parent = new DelegateLastClassLoader("/system/framework/android.test.base.jar", parent);
//
//            Context context = VirtualCore.get().getContext();
//
//            // 微信里找不到HttpClient， 把当前的app的Path添加到ClassPath中
//            String httpClientPath = PrepareHttpClientHelper.httpClientJarPath(context).getAbsolutePath();
//            parent = new DelegateLastClassLoader(httpClientPath, parent);
//            Reflect.on(cl).set("parent", parent);
//
//            log(start, processName,"DelegateLastClassLoader:" + applicationInfo + ", appPath:" + httpClientPath );
//
//            try {
//                Class httpClientClazz = parent.loadClass("org.apache.http.impl.client.DefaultHttpClient");
//                log(start, processName,"loadHttpClient:" + httpClientClazz);
//            } catch (ClassNotFoundException e) {
//                Log.e(TAG, "loadHttpClientError:", e);
//            }
//        }


        if (Build.VERSION.SDK_INT >= 30) {
            // android.security.net.config.ApplicationConfig.setDefaultInstance(null);
            ApplicationConfig.setDefaultInstance.call(new Object[]{null});
        }


        log(start, processName,"Call app create Application loadedApk:" + appBindData.loadApkInfo);

        // 创建app的Application对象

        // 这个方法执行很耗时，在企业微信嘻哈给你时间差不多2秒？
        // 创建Application对象

        mInitialApplication = LoadedApk.makeApplication.call(appBindData.loadApkInfo, false, null);


        // ExposedBridge.patchAppClassLoader(context);

        log(start, processName,"replace ActivityThread.mInitialApplication obj:" + mInitialApplication);

        // 把application设置回ActivityThread
        mirror.android.app.ActivityThread.mInitialApplication.set(mainThread, mInitialApplication);

        // Fuck AppOps
        ContextFixer.fixContext(mInitialApplication);

        if (Build.VERSION.SDK_INT >= 24 && "com.tencent.mm:recovery".equals(processName)) {
            fixWeChatRecovery(mInitialApplication);
        }



        if (appBindData.providers != null) {
            log(start, processName,"installContentProviders provider:" + appBindData.providers);
            installContentProviders(mInitialApplication, appBindData.providers);
            log(start, processName, "installContentProviders installed");
        }
        if (lock != null) {
            lock.open();
            mTempLock = null;
        }

        VirtualCore.get().getComponentDelegate().beforeApplicationCreate(mInitialApplication);


        try {
            log(start, processName,"call Application onCreate " + mInitialApplication);
            // Application的onCreate
            AppInstrumentation.getInstance().callApplicationOnCreate(mInitialApplication);
            log(start, processName,"call Application onCreate end");

            InvocationStubManager.getInstance().checkEnv(HCallbackStub.class);
            if (conflict) {
                InvocationStubManager.getInstance().checkEnv(AppInstrumentation.class);
            }


            Application createdApp = ActivityThread.mInitialApplication.get(mainThread);
            if (createdApp != null) {
                mInitialApplication = createdApp;
            }
        } catch (Exception e) {
            if (!AppInstrumentation.getInstance().onException(mInitialApplication, e)) {
                // 1. tell ui that do not need wait use now.
                if (mUiCallback != null) {
                    try {
                        mUiCallback.onOpenFailed(packageName, VUserHandle.myUserId());
                    } catch (RemoteException ignored) {
                    }
                }
                // 2. tell vams that launch finish.
                VActivityManager.get().appDoneExecuting();

                // 3. rethrow
                throw new RuntimeException(
                        "Unable to create application " + (mInitialApplication == null ? " [null application] " : mInitialApplication.getClass().getName())
                                + ": " + e.toString(), e);
            }
        }
        VActivityManager.get().appDoneExecuting();
        VirtualCore.get().getComponentDelegate().afterApplicationCreate(mInitialApplication);

        log(start, processName,"bindApplicationNoCheck " + processName + " complete");
    }

    private void fixWeChatRecovery(Application app) {
        try {
            Field field = app.getClassLoader().loadClass("com.tencent.recovery.Recovery").getField("context");
            field.setAccessible(true);
            if (field.get(null) != null) {
                return;
            }
            field.set(null, app.getBaseContext());
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }


//    @SuppressLint("SdCardPath")
//    private void startIOUniformer(String processName) {
//
//
//        // wlan、wifi、eth0的映射
//        final int userId = VUserHandle.myUserId();
//        String wifiMacAddressFile = deviceInfo.getWifiFile(userId).getPath();
//        NativeEngine.redirectDirectory(processName, "/sys/class/net/wlan0/address", wifiMacAddressFile);
//        NativeEngine.redirectDirectory(processName, "/sys/class/net/eth0/address", wifiMacAddressFile);
//        NativeEngine.redirectDirectory(processName, "/sys/class/net/wifi/address", wifiMacAddressFile);
//
//        // app自身的沙盒目录
//        // org: /data/data/<packageName>/
//        final ApplicationInfo info = mBoundApplication.appInfo;
//        NativeEngine.redirectDirectory(processName, "/data/data/" + info.packageName, info.dataDir);
//        NativeEngine.redirectDirectory(processName, "/data/user/0/" + info.packageName, info.dataDir);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            NativeEngine.redirectDirectory(processName, "/data/user_de/0/" + info.packageName, info.dataDir);
//        }
//
//        // org:VA_ROOT/data/user/<userId>/<package-Name>/lib -> new: VA_ROOT/data/app/<packageName>/lib
//        String libPath = VEnvironment.getAppLibDirectory(info.packageName).getAbsolutePath();
//        String userLibPath = new File(VEnvironment.getUserSystemDirectory(userId), info.packageName + "/lib").getAbsolutePath();
//        NativeEngine.redirectDirectory(processName, userLibPath, libPath);
//
//        // so目录映射到沙盒的so目录
//        // org: /data/data/<packageName>/lib -> new: VA_ROOT/data/app/<packageName>/lib
//        NativeEngine.redirectDirectory(processName, "/data/data/" + info.packageName + "/lib/", libPath);
//        NativeEngine.redirectDirectory(processName, "/data/user/0/" + info.packageName + "/lib/", libPath);
//
//        //
//        File dataUserLib = new File(VEnvironment.getDataUserPackageDirectory(userId, info.packageName), "lib");
//        if (!dataUserLib.exists()) {
//            try {
//                Os.symlink(libPath, dataUserLib.getPath());
//            } catch (ErrnoException e) {
//                VLog.w(TAG, "symlink error", e);
//            }
//        }
//
//        setupVirtualStorage(processName, info, userId);
//
//        NativeEngine.enableIORedirect();
//    }

//    // sd卡路径的映射
//    private void setupVirtualStorage(String processName, ApplicationInfo info, int userId) {
//
//
//        VirtualStorageManager vsManager = VirtualStorageManager.get();
//        boolean enable = vsManager.isVirtualStorageEnable(info.packageName, userId);
//        Log.d(TAG, "setupVirtualStorage info:" + info.packageName + ", enable:" + enable);
//        // Android 11, force enable storage redirect.
//        if (!enable && !(Build.VERSION.SDK_INT >= 30)) {
//            // There are lots of situation to deal, I am tired, disable it now.
//            // such as: FileProvider.
//            return;
//        }
//
//
//
//        // 虚拟sd卡
//        // 原来在：/sdcard/VirtualXposed/vsdcard/<userId>/
//        // 新：/sdcard/Android/data/<package-name>/files/VirtualXposed/vsdcard/<userId>
//        File vsDir = VEnvironment.getVirtualStorageDir(info.packageName, userId);
//        Log.d(TAG, "setupVirtualStorage info:" + info.packageName + ", vsDir:" + vsDir + ", vsDir.exits:" + vsDir.exists());
//        if (!vsDir.exists() || !vsDir.isDirectory()) {
//            Log.d(TAG, "setupVirtualStorage not exit return");
//            return;
//        }
//
//
//        // 外部sd卡的挂载目录，比如/sdcard/
//        HashSet<String> storageRoots = getMountPoints();
//
//        //
//        storageRoots.add(VEnvironment.getExternalStorageDirectory().getAbsolutePath());
//
//        // 需要载虚拟sd卡里创建映射目录
//        Set<String> whiteList = new HashSet<>();
//        whiteList.add(Environment.DIRECTORY_PODCASTS);
//        whiteList.add(Environment.DIRECTORY_RINGTONES);
//        whiteList.add(Environment.DIRECTORY_ALARMS);
//        whiteList.add(Environment.DIRECTORY_NOTIFICATIONS);
//        whiteList.add(Environment.DIRECTORY_PICTURES);
//        whiteList.add(Environment.DIRECTORY_MOVIES);
//        whiteList.add(Environment.DIRECTORY_DOWNLOADS);
//        whiteList.add(Environment.DIRECTORY_DCIM);
//        // Android 11, do not tryna fetch this directory directly or crash.
//        // See docs below...
//        if (Build.VERSION.SDK_INT < 30) {
//            whiteList.add("Android/obb");
//        }
//        if (Build.VERSION.SDK_INT >= 19) {
//            whiteList.add(Environment.DIRECTORY_DOCUMENTS);
//        }
//
//        // ensure virtual storage white directory exists.
//        // 把sdcard根目录下的一些目录在虚拟vsdcard/0/中也创建一份。
//        for (String whiteDir : whiteList) {
//            File originalDir = new File(VEnvironment.getExternalStorageDirectory(), whiteDir);
//            File virtualDir = new File(vsDir, whiteDir);
//            if (!originalDir.exists()) {
//                continue;
//            }
//            //noinspection ResultOfMethodCallIgnored
//            virtualDir.mkdirs();
//        }
//
//        String vsPath = vsDir.getAbsolutePath();
//        NativeEngine.whitelist(vsPath, true);
//
//        // 应用的私有目录：/Android/data/<host-packageName>/virtual/<userId>/
//        final String privatePath = VEnvironment.getVirtualPrivateStorageDir(userId).getAbsolutePath();
//
//        NativeEngine.whitelist(privatePath, true);
//
//        for (String storageRoot : storageRoots) {
//            for (String whiteDir : whiteList) {
//                // white list, do not redirect
//                String whitePath = new File(storageRoot, whiteDir).getAbsolutePath();
//                NativeEngine.whitelist(whitePath, true);
//            }
//
//            // Android 11 -> see https://developer.android.com/training/data-storage#scoped-storage
//            // 安卓11 打开这个链接看看 https://developer.android.google.cn/training/data-storage#scoped-storage
//            // see https://android-opengrok.bangnimang.net/android-11.0.0_r8/xref/frameworks/base/core/java/android/os/Environment.java
//
//            // redirect /sdcard/Android/data/ -> /sdcard/Android/data/<host>/virtual/<user>/
//            NativeEngine.redirectDirectory(processName, new File(storageRoot, "Android/data/").getAbsolutePath(), privatePath);
//
//            // redirect /sdcard/Android/obb/ -> /sdcard/Android/data/<host>/virtual/<user>/
//            NativeEngine.redirectDirectory(processName, new File(storageRoot, "Android/obb/").getAbsolutePath(), privatePath);
//
//            // redirect /sdcard/ -> vsdcard
//
//            // 为啥要把根路径也映射过去？
////            NativeEngine.redirectDirectory(processName, storageRoot, vsPath);
//        }
//    }
//
//    @SuppressLint("SdCardPath")
//    private HashSet<String> getMountPoints() {
//        HashSet<String> mountPoints = new HashSet<>(3);
//        mountPoints.add("/mnt/sdcard/");
//        mountPoints.add("/sdcard/");
//        // Redmi 10X Pro, Pixel 5... More mount points?
//        // 1@die.lu
//        mountPoints.add("/storage/self/primary/");
//        String[] points = StorageManagerCompat.getAllPoints(VirtualCore.get().getContext());
//        if (points != null) {
//            Collections.addAll(mountPoints, points);
//        }
//        return mountPoints;
//
//    }

    public static Context createPackageContext(String packageName) {
        try {
            Context hostContext = VirtualCore.get().getContext();
            return hostContext.createPackageContext(packageName, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            VirtualRuntime.crash(new RemoteException());
        }
        throw new RuntimeException();
    }

//    private Object fixBoundApp(AppBindData data) {
//        Object thread = VirtualCore.mainThread();
//        Object boundApp = mirror.android.app.ActivityThread.mBoundApplication.get(thread);
//        mirror.android.app.ActivityThread.AppBindData.appInfo.set(boundApp, data.appInfo);
//        mirror.android.app.ActivityThread.AppBindData.processName.set(boundApp, data.processName);
//        mirror.android.app.ActivityThread.AppBindData.instrumentationName.set(
//                boundApp,
//                new ComponentName(data.appInfo.packageName, Instrumentation.class.getName())
//        );
//        ActivityThread.AppBindData.providers.set(boundApp, data.providers);
//        return boundApp;
//    }

    private void installContentProviders(Context app, List<ProviderInfo> providers) {
        long origId = Binder.clearCallingIdentity();
        Object mainThread = VirtualCore.mainThread();
        try {
            for (ProviderInfo cpi : providers) {
                try {
                    ActivityThread.installProvider(mainThread, app, cpi, null);
                } catch (Throwable e) {
                    Log.e(TAG, "installContentProviders error", e);
                }
            }
        } finally {
            Binder.restoreCallingIdentity(origId);
        }
    }

    @Override
    public IBinder acquireProviderClient(ProviderInfo info) {
        if (mTempLock != null) {
            mTempLock.block();
        }
        if (!isBound()) {
            VClientImpl.get().bindApplication(info.packageName, info.processName);
        }
        IInterface provider = null;
        String[] authorities = info.authority.split(";");
        String authority = authorities.length == 0 ? info.authority : authorities[0];
        ContentResolver resolver = VirtualCore.get().getContext().getContentResolver();
        ContentProviderClient client = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                client = resolver.acquireUnstableContentProviderClient(authority);
            } else {
                client = resolver.acquireContentProviderClient(authority);
            }
        } catch (Throwable e) {
            VLog.e(TAG, "", e);
        }
        if (client != null) {
            provider = mirror.android.content.ContentProviderClient.mContentProvider.get(client);
            client.release();
        }
        return provider != null ? provider.asBinder() : null;
    }

    private void fixInstalledProviders() {
        clearSettingProvider();
        Map clientMap = ActivityThread.mProviderMap.get(VirtualCore.mainThread());
        for (Object clientRecord : clientMap.values()) {
            if (BuildCompat.isOreo()) {
                IInterface provider = ActivityThread.ProviderClientRecordJB.mProvider.get(clientRecord);
                Object holder = ActivityThread.ProviderClientRecordJB.mHolder.get(clientRecord);
                if (holder == null) {
                    continue;
                }
                ProviderInfo info = ContentProviderHolderOreo.info.get(holder);
                if (!info.authority.startsWith(VASettings.STUB_CP_AUTHORITY)) {
                    provider = ProviderHook.createProxy(true, info.authority, provider);
                    ActivityThread.ProviderClientRecordJB.mProvider.set(clientRecord, provider);
                    ContentProviderHolderOreo.provider.set(holder, provider);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                IInterface provider = ActivityThread.ProviderClientRecordJB.mProvider.get(clientRecord);
                Object holder = ActivityThread.ProviderClientRecordJB.mHolder.get(clientRecord);
                if (holder == null) {
                    continue;
                }
                ProviderInfo info = IActivityManager.ContentProviderHolder.info.get(holder);
                if (!info.authority.startsWith(VASettings.STUB_CP_AUTHORITY)) {
                    provider = ProviderHook.createProxy(true, info.authority, provider);
                    ActivityThread.ProviderClientRecordJB.mProvider.set(clientRecord, provider);
                    IActivityManager.ContentProviderHolder.provider.set(holder, provider);
                }
            } else {
                String authority = ActivityThread.ProviderClientRecord.mName.get(clientRecord);
                IInterface provider = ActivityThread.ProviderClientRecord.mProvider.get(clientRecord);
                if (provider != null && !authority.startsWith(VASettings.STUB_CP_AUTHORITY)) {
                    provider = ProviderHook.createProxy(true, authority, provider);
                    ActivityThread.ProviderClientRecord.mProvider.set(clientRecord, provider);
                }
            }
        }

    }

    private void clearSettingProvider() {
        Object cache;
        cache = Settings.System.sNameValueCache.get();
        if (cache != null) {
            clearContentProvider(cache);
        }
        cache = Settings.Secure.sNameValueCache.get();
        if (cache != null) {
            clearContentProvider(cache);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && Settings.Global.TYPE != null) {
            cache = Settings.Global.sNameValueCache.get();
            if (cache != null) {
                clearContentProvider(cache);
            }
        }
    }

    private static void clearContentProvider(Object cache) {
        if (BuildCompat.isOreo()) {
            Object holder = Settings.NameValueCacheOreo.mProviderHolder.get(cache);
            if (holder != null) {
                Settings.ContentProviderHolder.mContentProvider.set(holder, null);
            }
        } else {
            Settings.NameValueCache.mContentProvider.set(cache, null);
        }
    }

    @Override
    public void finishActivity(IBinder token) {
        VActivityManager.get().finishActivity(token);
    }

    @Override
    public void scheduleNewIntent(String creator, IBinder token, Intent intent) {
        NewIntentData data = new NewIntentData();
        data.creator = creator;
        data.token = token;
        data.intent = intent;
        sendMessage(NEW_INTENT, data);
    }

    @Override
    public void scheduleReceiver(String processName, ComponentName component, Intent intent, PendingResultData resultData) {
        ReceiverData receiverData = new ReceiverData();
        receiverData.resultData = resultData;
        receiverData.intent = intent;
        receiverData.component = component;
        receiverData.processName = processName;
        sendMessage(RECEIVER, receiverData);
    }

    private void handleReceiver(ReceiverData data) {
        BroadcastReceiver.PendingResult result = data.resultData.build();
        try {
            if (!isBound()) {
                bindApplication(data.component.getPackageName(), data.processName);
            }
            Context context = mInitialApplication.getBaseContext();
            Context receiverContext = ContextImpl.getReceiverRestrictedContext.call(context);
            String className = data.component.getClassName();
            BroadcastReceiver receiver = (BroadcastReceiver) context.getClassLoader().loadClass(className).newInstance();
            mirror.android.content.BroadcastReceiver.setPendingResult.call(receiver, result);
            data.intent.setExtrasClassLoader(context.getClassLoader());
            if (data.intent.getComponent() == null) {
                data.intent.setComponent(data.component);
            }
            receiver.onReceive(receiverContext, data.intent);
            if (mirror.android.content.BroadcastReceiver.getPendingResult.call(receiver) != null) {
                result.finish();
            }
        } catch (Exception e) {
            // must be this for misjudge of anti-virus!!
            throw new RuntimeException(String.format("Unable to start receiver: %s ", data.component), e);
        }
        VActivityManager.get().broadcastFinish(data.resultData);
    }

    @Override
    public IBinder createProxyService(ComponentName component, IBinder binder) {
        return ProxyServiceFactory.getProxyService(getCurrentApplication(), component, binder);
    }

    @Override
    public String getDebugInfo() {
        return "process : " + VirtualRuntime.getProcessName() + "\n" +
                "initialPkg : " + VirtualRuntime.getInitialPackageName() + "\n" +
                "vuid : " + vuid;
    }



    private final class NewIntentData {
        String creator;
        IBinder token;
        Intent intent;
    }

    final class AppBindData {
        String processName;
        ApplicationInfo appInfo;
        List<ProviderInfo> providers;

        // LoadedApk
        Object loadApkInfo;
    }

    private final class ReceiverData {
        PendingResultData resultData;
        Intent intent;
        ComponentName component;
        String processName;
    }

    private class H extends Handler {

        private H() {
            super(Looper.getMainLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case NEW_INTENT: {
                    handleNewIntent((NewIntentData) msg.obj);
                }
                break;
                case RECEIVER: {
                    handleReceiver((ReceiverData) msg.obj);
                }
            }
        }
    }
}
