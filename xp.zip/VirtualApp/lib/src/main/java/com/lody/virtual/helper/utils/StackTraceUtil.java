package com.lody.virtual.helper.utils;

public class StackTraceUtil {

    /**
     * 打印当前线程的调用堆栈。
     */
    public static String getCurrentStackTrace() {

        StringBuilder sb = new StringBuilder();
        // 获取当前线程的堆栈跟踪元素
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();

        // 打印堆栈跟踪
        sb.append("Current stack trace:\n");
        for (StackTraceElement element : stackTraceElements) {
            sb.append("\tat ").append(element).append("\n");
        }
        return sb.toString();
    }
}
