package com.lody.virtual.helper.utils;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;


import com.lody.virtual.client.core.VirtualCore;

import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import mirror.android.app.ActivityThread;

public class PrepareHttpClientHelper {

    static final String TAG = "PrepareHttpClientHelper";

    static final String fileName = "org.apache.http.legacy-d.jar";



    public static File httpClientJarPath(Context context) {
        return new File(context.getFilesDir(), fileName);
    }


    static void foo() {
        LogFactory lf;
//        DefaultHttpClient httpClient = new DefaultHttpClient();
    }

    public static void prepareHttpClient(Context context) {

        if (!VirtualCore.get().isMainProcess()) {
            // 只有主进程才做这个初始化
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File jarPath = httpClientJarPath(context);
                    Log.e(TAG, "httpClientFile:" + jarPath+"  exits:" + jarPath.exists());
                    if (jarPath.exists()) {
                        return;
                    }

                    // 复制文件到应用的私有目录
                    File privateFile = copyAssetToPrivateDir(context, fileName);

                    // 输出文件路径
                    Log.d(TAG, "File copied to: " + privateFile.getAbsolutePath() + ", path:" + jarPath);

                } catch (IOException e) {
                    Log.e(TAG, "copy to file error", e);
                }
            }
        }).start();

    }

    static private File copyAssetToPrivateDir(Context context, String fileName) throws IOException {
        AssetManager assetManager = context.getAssets();
        InputStream inputStream = assetManager.open(fileName);

        // 获取应用的私有目录
        File privateDir = context.getFilesDir();
        File outFile = new File(privateDir, fileName);

        OutputStream outputStream = new FileOutputStream(outFile);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }

        // 关闭流
        inputStream.close();
        outputStream.close();

        return outFile;
    }
}
