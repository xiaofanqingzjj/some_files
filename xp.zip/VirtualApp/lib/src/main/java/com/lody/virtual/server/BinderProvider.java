package com.lody.virtual.server;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.env.Constants;
import com.lody.virtual.client.ipc.ServiceManagerNative;
import com.lody.virtual.client.stub.DaemonService;
import com.lody.virtual.helper.compat.BundleCompat;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.server.accounts.VAccountManagerService;
import com.lody.virtual.server.am.BroadcastSystem;
import com.lody.virtual.server.am.VActivityManagerService;
import com.lody.virtual.server.device.VDeviceManagerService;
import com.lody.virtual.server.interfaces.IServiceFetcher;
import com.lody.virtual.server.job.VJobSchedulerService;
import com.lody.virtual.server.location.VirtualLocationService;
import com.lody.virtual.server.notification.VNotificationManagerService;
import com.lody.virtual.server.pm.VAppManagerService;
import com.lody.virtual.server.pm.VPackageManagerService;
import com.lody.virtual.server.pm.VUserManagerService;
import com.lody.virtual.server.vs.VirtualStorageService;

/**
 * 服务进程提供者
 * 用来运行VA的虚拟系统服务
 * @author Lody
 */
public final class BinderProvider extends ContentProvider {

    static final String TAG = "BinderProvider";

    private final ServiceFetcher mServiceFetcher = new ServiceFetcher();

    @Override
    public boolean onCreate() {
        final Context context = getContext();


        // 保活服务
        DaemonService.startup(context);

        // 等待Application里的onCreate执行完毕
        if (!VirtualCore.get().isStartup()) {
            return true;
        }

        //  创建VPackageService
        VPackageManagerService.systemReady();
        ServiceCache.addService(ServiceManagerNative.PACKAGE, VPackageManagerService.get());

        // 创建VActivityManagerService
        VActivityManagerService.systemReady(context);
        ServiceCache.addService(ServiceManagerNative.ACTIVITY, VActivityManagerService.get());

        // VUserManagerService， 在VPackageManagerService.systemReady()里会创建该对象
        ServiceCache.addService(ServiceManagerNative.USER, VUserManagerService.get());

        // 创建VAppManagerService对象
        VAppManagerService.systemReady();
        ServiceCache.addService(ServiceManagerNative.APP, VAppManagerService.get());

        // 处理广播
        BroadcastSystem.attach(VActivityManagerService.get(), VAppManagerService.get());

        // 创建VJobSchedulerService对象
        ServiceCache.addService(ServiceManagerNative.JOB, VJobSchedulerService.get());


        VNotificationManagerService.systemReady(context);
        ServiceCache.addService(ServiceManagerNative.NOTIFICATION, VNotificationManagerService.get());

        // 账户服务
        VAccountManagerService.systemReady();
        ServiceCache.addService(ServiceManagerNative.ACCOUNT, VAccountManagerService.get());

        ServiceCache.addService(ServiceManagerNative.VS, VirtualStorageService.get());

        ServiceCache.addService(ServiceManagerNative.DEVICE, VDeviceManagerService.get());

        ServiceCache.addService(ServiceManagerNative.VIRTUAL_LOC, VirtualLocationService.get());

        // Scan all apps cache to memory
        VAppManagerService.get().scanApps();

        return true;
    }


    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        VLog.d(TAG, "call method:" + method + ", arg:" + arg + ", extras:" + extras);
        if ("@".equals(method)) {
            Bundle bundle = new Bundle();
            BundleCompat.putBinder(bundle, Constants.VA_BINDER, mServiceFetcher);
            return bundle;
        }
        return null;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    /**
     * 服务获取器
     */
    private static class ServiceFetcher extends IServiceFetcher.Stub {

        /**
         * 获取服务
         * @param name 服务名
         * @return 服务对象
         * @throws RemoteException
         */
        @Override
        public IBinder getService(String name) throws RemoteException {
            if (name != null) {
                return ServiceCache.getService(name);
            }
            return null;
        }

        @Override
        public void addService(String name, IBinder service) throws RemoteException {
            if (name != null && service != null) {
                ServiceCache.addService(name, service);
            }
        }

        @Override
        public void removeService(String name) throws RemoteException {
            if (name != null) {
                ServiceCache.removeService(name);
            }
        }
    }
}
