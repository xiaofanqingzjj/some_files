package com.lody.virtual.client.hook.proxies.am;

import android.os.IBinder;

import com.lody.virtual.client.hook.base.BinderInvocationProxy;
import com.lody.virtual.client.hook.base.Inject;
import com.lody.virtual.client.hook.base.ReplaceCallingPkgMethodProxy;
import com.lody.virtual.client.hook.base.StaticMethodProxy;
import com.lody.virtual.client.hook.utils.Utils;
import com.lody.virtual.client.ipc.VActivityManager;
import com.lody.virtual.helper.compat.BuildCompat;
import com.lody.virtual.helper.utils.VLog;

import java.lang.reflect.Method;

import mirror.android.app.IActivityTaskManager;

/**
 * @author weishu
 * @date 2019-11-05.
 */
@Inject(AMSMethodProxies.class)
public class ActivityTaskManagerStub extends BinderInvocationProxy {

    static final String TAG = "ActivityTaskManagerStub";

    public ActivityTaskManagerStub() {
        // 替换掉activity_task服务
        super(IActivityTaskManager.Stub.TYPE, "activity_task");
    }

    @Override
    public void inject() throws Throwable {
        super.inject();
    }

    @Override
    protected void onBindMethods() {
        super.onBindMethods();

        addMethodProxy(new StaticMethodProxy("activityDestroyed") {
            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                VLog.d(TAG, "activityDestoryed:" + Utils.argsToString(args));
                IBinder token = (IBinder) args[0];
                VActivityManager.get().onActivityDestroy(token);
                return super.call(who, method, args);
            }
        });
        addMethodProxy(new StaticMethodProxy("activityResumed") {
            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                VLog.d(TAG, "activityResumed:" + Utils.argsToString(args));
                IBinder token = (IBinder) args[0];
                VActivityManager.get().onActivityResumed(token);
                return super.call(who, method, args);
            }
        });
        addMethodProxy(new StaticMethodProxy("finishActivity") {
            @Override
            public Object call(Object who, Method method, Object... args) throws Throwable {
                VLog.d(TAG, "finishActivity:" + Utils.argsToString(args));
                IBinder token = (IBinder) args[0];
                VActivityManager.get().finishActivity(token);
                return super.call(who, method, args);
            }
        });

        if (BuildCompat.isQ()) {
            addMethodProxy(new ReplaceCallingPkgMethodProxy("getAppTasks"));
        }
    }
}
