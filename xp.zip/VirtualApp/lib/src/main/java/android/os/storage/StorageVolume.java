package android.os.storage;

public class StorageVolume {
}
