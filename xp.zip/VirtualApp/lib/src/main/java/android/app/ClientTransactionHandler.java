/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package android.app;

import android.app.servertransaction.ClientTransaction;
import android.app.servertransaction.PendingTransactionActions;
import android.app.servertransaction.TransactionExecutor;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.CompatibilityInfo;
import android.content.res.Configuration;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.MergedConfiguration;
import android.view.DisplayAdjustments;
import android.view.SurfaceControl;
import android.window.ActivityWindowInfo;
import android.window.SplashScreenView;
import android.window.WindowContextInfo;

import java.util.List;
import java.util.Map;

import mirror.com.android.internal.content.ReferrerIntent;

/**
 * Defines operations that a {@link ClientTransaction} or its items
 * can perform on client.
 * @hide
 */
public abstract class ClientTransactionHandler {

    private boolean mIsExecutingLocalTransaction;

    // Schedule phase related logic and handlers.

    void scheduleTransaction(ClientTransaction transaction) {
    }

    public void executeTransaction(ClientTransaction transaction) {
    }

    // Android 15
    public boolean isExecutingLocalTransaction() {
        return mIsExecutingLocalTransaction;
    }


    abstract TransactionExecutor getTransactionExecutor();


    abstract void sendMessage(int what, Object obj);

    public abstract void updatePendingConfiguration(Configuration config);


    public abstract void updateProcessState(int processState, boolean fromIpc);

    public abstract void handleDestroyActivity(IBinder token, boolean finishing, int configChanges,
            boolean getNonConfigInstance, String reason);

    // Android 12
    public abstract void handleDestroyActivity(ActivityThread.ActivityClientRecord r, boolean finishing,
                                               int configChanges, boolean getNonConfigInstance, String reason);


    // Android 15
    public abstract void handleDestroyActivity(ActivityThread.ActivityClientRecord r,
                                               boolean finishing,
                                               boolean getNonConfigInstance,
                                               String reason);


    public abstract void handlePauseActivity(IBinder token,
                                             boolean finished,
                                             boolean userLeaving,
                                             int configChanges,
                                             PendingTransactionActions pendingActions,
                                             String reason);


    public abstract void handlePauseActivity(ActivityThread.ActivityClientRecord r,
                                             boolean finished,
                                             boolean userLeaving,
                                             int configChanges,
                                             PendingTransactionActions pendingActions,
                                             String reason);

    // Android 14
    public abstract void handlePauseActivity(ActivityThread.ActivityClientRecord  r,
                                             boolean finished,
                                             boolean userLeaving,
                                             int configChanges,
                                             boolean autoEnteringPip,
                                             PendingTransactionActions pendingActions,
                                             String reason);


    // Android 15
    public abstract void handlePauseActivity(ActivityThread.ActivityClientRecord r,
                                             boolean finished,
                                             boolean userLeaving,
                                             boolean autoEnteringPip,
                                             PendingTransactionActions pendingActions,
                                             String reason);



    public abstract void handleResumeActivity(IBinder token,
                                              boolean finalStateRequest,
                                              boolean isForward,
                                              String reason);

    // Android 12
    public abstract void handleResumeActivity(ActivityThread.ActivityClientRecord record,
                                              boolean finalStateRequest,
                                              boolean isForward,
                                              String reason);


    // Android 14
    public abstract void handleResumeActivity(ActivityThread.ActivityClientRecord r,
                                              boolean finalStateRequest,
                                              boolean isForward,
                                              boolean shouldSendCompatFakeFocus,
                                              String reason);


    public abstract void handleStopActivity(IBinder token,
                                            boolean show,
                                            int configChanges,
                                            PendingTransactionActions pendingActions,
                                            boolean finalStateRequest,
                                            String reason);

    // Android 11
    public abstract void handleStopActivity(IBinder token,
                                            int configChanges,
                                            PendingTransactionActions pendingActions,
                                            boolean finalStateRequest,
                                            String reason);

    // Android 12
    public abstract void handleStopActivity(ActivityThread.ActivityClientRecord r,
                                            int configChanges,
                                            PendingTransactionActions pendingActions,
                                            boolean finalStateRequest,
                                            String reason);

    // Android 15
    public abstract void handleStopActivity(ActivityThread.ActivityClientRecord r,
                                            PendingTransactionActions pendingActions,
                                            boolean finalStateRequest,
                                            String reason);

    public abstract void reportStop(PendingTransactionActions pendingActions);

    public abstract void performRestartActivity(IBinder token, boolean start);

    public abstract void performRestartActivity(ActivityThread.ActivityClientRecord r,
                                                boolean start);


    // android 15
    public abstract void reportRefresh(ActivityThread.ActivityClientRecord r);

    public abstract void handleActivityConfigurationChanged(IBinder activityToken,
            Configuration overrideConfig, int displayId);
    public abstract void handleActivityConfigurationChanged(ActivityThread.ActivityClientRecord r,
                                                            Configuration overrideConfig,
                                                            int displayId);

    // Android 15
    public abstract void handleActivityConfigurationChanged(ActivityThread.ActivityClientRecord r,
                                                            Configuration overrideConfig,
                                                            int displayId,
                                                            ActivityWindowInfo activityWindowInfo);
    // Android 15
    public abstract void handleWindowContextInfoChanged(IBinder clientToken,
                                                        WindowContextInfo info);
    // Android 15
    public abstract void handleWindowContextWindowRemoval(IBinder clientToken);

    public abstract void handleSendResult(IBinder token, List results, String reason);

    public abstract void handleSendResult(
            ActivityThread.ActivityClientRecord r, List results, String reason);

    public abstract void handleMultiWindowModeChanged(IBinder token, boolean isInMultiWindowMode,
            Configuration overrideConfig);

    public abstract void handleNewIntent(IBinder token, List intents,
            boolean andPause);

    public abstract void handleNewIntent(
            ActivityThread.ActivityClientRecord r, List<ReferrerIntent> intents);

    public abstract void handlePictureInPictureModeChanged(IBinder token, boolean isInPipMode,
            Configuration overrideConfig);

    // Android 11
    public abstract void handlePictureInPictureRequested(IBinder token);

    public abstract void handlePictureInPictureRequested(ActivityThread.ActivityClientRecord r);

    public abstract void handlePictureInPictureStateChanged(ActivityThread.ActivityClientRecord r,
                                                            Parcelable pipState);

    // Android 15
    public abstract void handlePictureInPictureStateChanged(ActivityThread.ActivityClientRecord r,
                                                            PictureInPictureUiState pipState);

    public abstract boolean isHandleSplashScreenExit(IBinder token);

    public abstract void handleAttachSplashScreenView(ActivityThread.ActivityClientRecord r,
                                                      Parcelable parcelable);

    // Android 15
    public abstract void handleAttachSplashScreenView(ActivityThread.ActivityClientRecord r,
                                                      SplashScreenView.SplashScreenViewParcelable parcelable,
                                                      SurfaceControl startingWindowLeash);


    public abstract void handOverSplashScreenView(ActivityThread.ActivityClientRecord r);

    public abstract void handleWindowVisibility(IBinder token, boolean show);

    public abstract Activity handleLaunchActivity(ActivityThread.ActivityClientRecord r,
            PendingTransactionActions pendingActions, Intent customIntent);

    // Android 13
    public abstract Activity handleLaunchActivity(
            ActivityThread.ActivityClientRecord r,
            PendingTransactionActions pendingActions,
            int deviceId,
            Intent customIntent);

    public abstract void handleStartActivity(ActivityThread.ActivityClientRecord r,
            PendingTransactionActions pendingActions);

    // Android 11
    public abstract void handleStartActivity(IBinder binder,
                                             PendingTransactionActions pendingActions);


    // Android 12
    public abstract void handleStartActivity(ActivityThread.ActivityClientRecord r,
                                             PendingTransactionActions pendingActions, ActivityOptions options);


    // Android 15
    public abstract void handleStartActivity(ActivityThread.ActivityClientRecord  r,
                                             PendingTransactionActions pendingActions,
                                             ActivityOptions.SceneTransitionInfo sceneTransitionInfo);

    // Android 14
    public abstract LoadedApk getPackageInfoNoCheck(ApplicationInfo ai);

    public abstract LoadedApk getPackageInfoNoCheck(ApplicationInfo ai,
                                                    CompatibilityInfo compatInfo);
    public abstract void handleConfigurationChanged(Configuration config);

    // android 15
    public abstract void handleConfigurationChanged(Configuration config, int deviceId);


    public abstract void handleFixedRotationAdjustments(IBinder token,
                                                        DisplayAdjustments.FixedRotationAdjustments fixedRotationAdjustments);

    public abstract void addLaunchingActivity(IBinder token, ActivityThread.ActivityClientRecord activity);

    public abstract ActivityThread.ActivityClientRecord getLaunchingActivity(IBinder token);

    public abstract void removeLaunchingActivity(IBinder token);

    public abstract ActivityThread.ActivityClientRecord getActivityClient(IBinder token);

    public abstract ActivityThread.ActivityClientRecord prepareRelaunchActivity(
            IBinder token,
            List pendingResults,
            List pendingNewIntents,
            int configChanges,
            MergedConfiguration config,
            boolean preserveWindow);

    // Android 15
    public abstract ActivityThread.ActivityClientRecord prepareRelaunchActivity(IBinder token,
                                                                                List pendingResults,
                                                                                List<ReferrerIntent> pendingNewIntents, int configChanges,
                                                                                MergedConfiguration config, boolean preserveWindow,
                                                                                ActivityWindowInfo activityWindowInfo);

    public abstract void handleRelaunchActivity(ActivityThread.ActivityClientRecord r,
            PendingTransactionActions pendingActions);

    public abstract void reportRelaunch(IBinder token, PendingTransactionActions pendingActions);

    // android 15
    public abstract void reportRelaunch(ActivityThread.ActivityClientRecord r);

    public abstract Map getActivitiesToBeDestroyed();

    // Android 10
    public abstract Activity getActivity(IBinder token);

    public abstract void updatePendingActivityConfiguration(IBinder token,
                                                            Configuration overrideConfig);

    public abstract void handleTopResumedActivityChanged(IBinder arg1,
                                                         boolean arg2,
                                                         String arg3);

    public abstract void handleTopResumedActivityChanged(ActivityThread.ActivityClientRecord record,
                                                         boolean isTopResumedActivity,
                                                         String reason);


    public abstract void countLaunchingActivities(int num);

    public abstract void handleNewIntent(IBinder token, List intents);
}