package android.app;

public class PictureInPictureUiState {
}
