package android.app;

public class Tags {

    public static final String TAG = "TestTag";
}
