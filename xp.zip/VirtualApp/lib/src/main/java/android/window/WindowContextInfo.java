package android.window;

public class WindowContextInfo {
}
