package android.window;

public class ActivityWindowInfo {
}
