package android.window;

public class SplashScreenView {

    public static class SplashScreenViewParcelable {
    }
}
