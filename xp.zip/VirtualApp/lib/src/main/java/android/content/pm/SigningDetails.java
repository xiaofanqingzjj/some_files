package android.content.pm;

public class SigningDetails {
}
