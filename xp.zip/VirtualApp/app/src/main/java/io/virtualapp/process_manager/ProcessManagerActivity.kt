package io.virtualapp.process_manager

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.fortune.va.lib.VActivity
import com.fortune.va.utils.BaseViewTypeAdapter
import com.lody.virtual.client.ipc.VActivityManager
import com.lody.virtual.helper.utils.VLog
import com.lody.virtual.server.ProcessInfo
import io.virtualapp.R
import io.virtualapp.abs.ui.VUiKit


/**
 * 当前虚拟机运行的所有进程列表
 */
class ProcessManagerActivity : VActivity() {

    companion object {
        const val TAG = "ProcessManagerActivity"

    }

    private var processList: MutableList<ItemBean> = mutableListOf()

    private var adapter: MyAdapter? = null

    private var emptyView: View? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.title = "当前运行的进程列表"

        setContentView(R.layout.activity_process_list)

        emptyView = findViewById(R.id.empty_view)

        val recyclerView = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recycler_view)
        adapter = MyAdapter(this, processList)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = object : LinearLayoutManager(context) {
            init {
                this.orientation = orientation
            }

            override fun generateDefaultLayoutParams(): androidx.recyclerview.widget.RecyclerView.LayoutParams {
                return androidx.recyclerview.widget.RecyclerView.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        }


        loadData()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadData() {
        VUiKit.defer().`when` {
            val processes = VActivityManager.get().runningProcess
            VLog.d(TAG, "proces:$processes")
            // 使用vuid排序
            processes.sortBy {
                it.vuid
            }
            processList.clear()
            processList.addAll(groupProcess(processes))
        }.done {
            adapter?.notifyDataSetChanged()
            emptyView?.visibility = if (processList.isEmpty()) View.VISIBLE else View.GONE
        }

    }

    /**
     * 把进程按所属app进行分组
     */
    private fun groupProcess(processList: List<ProcessInfo>): MutableList<ItemBean> {
        val list = mutableListOf<ItemBean>()
        processList.groupBy {
            it.vuid
        }.forEach {
            val group = it.value.first()
            list.add(ItemBean(
                type = 1,
                vuid = group.vuid,
                packageName = group.info.packageName,
                userId = group.userId))
            it.value.forEach {p->
                val item = ItemBean(0, processInfo = p)
                list.add(item)
            }
        }
        return list
    }

    private class MyAdapter(context: Context, data: List<ItemBean>) : BaseViewTypeAdapter<ItemBean>(context, data) {

        init {
            addViewType(0,  VHProcess::class.java)
            addViewType(1,  VHGroup::class.java)
        }


        override fun getItemViewType(position: Int): Int {
            return getItem(position).type
        }

        class VHGroup : ViewTypeViewHolder<ItemBean>() {

            override fun onCreate() {
                super.onCreate()
                setContentView(R.layout.item_group_process_item)
            }

            override fun bindData(position: Int, data: ItemBean?) {
                data?.run {
                    val textView1 = findViewById<TextView>(R.id.text1)
                    textView1.text = "app:$packageName, vuid:$vuid, userId:$userId"
                }
            }
        }

        class VHProcess : ViewTypeViewHolder<ItemBean>() {

            override fun onCreate() {
                super.onCreate()
                setContentView(R.layout.item_process_item)
            }

            override fun bindData(position: Int, data: ItemBean?) {
                data?.processInfo?.run {
                    val textView1 = findViewById<TextView>(R.id.text1)
                    textView1.text = processName
                    val textView2 = findViewById<TextView>(R.id.text2)
                    textView2.text = "pid:$pid, vuid:$vuid, vpid:$vpid  userId:$userId"
                }
            }
        }

    }

    private class ItemBean(
        // 0: process, 1: group
        var type: Int = 0,

        // group info
        var vuid: Int = 0,
        var packageName: String? = null,
        var userId: Int = 0,

        // process info
        var processInfo: ProcessInfo? = null
    )
}