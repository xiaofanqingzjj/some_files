package io.virtualapp.sys;

import android.app.AlertDialog;
import android.app.Tags;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.fortune.va.lib.VActivity;
import com.lody.virtual.client.core.InstallStrategy;
import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.helper.utils.FileUtils;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.remote.InstallResult;
import com.lody.virtual.remote.InstalledAppInfo;
import com.lody.virtual.server.pm.VAppManager;

import org.jdeferred.DeferredCallable;
import org.jdeferred.Promise;


import java.util.ArrayList;
import java.util.List;

import io.virtualapp.R;
import io.virtualapp.VCommends;
import io.virtualapp.abs.ui.VUiKit;
import io.virtualapp.home.LoadingActivity;
import io.virtualapp.home.models.AppInfo;

/**
 * author: weishu on 18/3/19.
 */
public class InstallerActivity extends VActivity {

    static final String TAG = "InstallerActivity";


    private static ArrayList<AppInfo> getAppInfoLiteFromPath(Context context, String path) {
        if (context == null) {
            return null;
        }
        PackageInfo pkgInfo = null;
        try {
            pkgInfo = context.getPackageManager().getPackageArchiveInfo(path, PackageManager.GET_META_DATA);
            pkgInfo.applicationInfo.sourceDir = path;
            pkgInfo.applicationInfo.publicSourceDir = path;
        } catch (Exception e) {
            // Ignore
        }
        if (pkgInfo == null) {
            return null;
        }

        if (TextUtils.equals(VirtualCore.TAICHI_PACKAGE, pkgInfo.packageName)) {
            return null;
        }

        if (VirtualCore.get().getHostPkg().equals(pkgInfo.packageName)) {
            Toast.makeText(VirtualCore.get().getContext(), R.string.install_self_eggs, Toast.LENGTH_SHORT).show();
            return null;
        }

        boolean isXposed = pkgInfo.applicationInfo.metaData != null
                && pkgInfo.applicationInfo.metaData.containsKey("xposedmodule");

        AppInfo appInfo = new AppInfo(pkgInfo.packageName, path);
        ArrayList<AppInfo> dataList = new ArrayList<>();
        dataList.add(appInfo);
        return dataList;
    }


    /**
     * 从文件路径中安装应用
     * @param context
     * @param path
     */
    public static void handleRequestFromFile(Context context, String path) {
        ArrayList<AppInfo> dataList = getAppInfoLiteFromPath(context, path);
        if (dataList == null) {
            return;
        }
        startInstallerActivity(context, dataList);
    }


    /**
     * 启动安装器
     * @param context
     * @param data 需要安装的应用列表
     */
    public static void startInstallerActivity(Context context, ArrayList<AppInfo> data) {
        if (context == null) {
            return;
        }
        Intent intent = new Intent(context, InstallerActivity.class);
        intent.putParcelableArrayListExtra(VCommends.EXTRA_APP_INFO_LIST, data);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }


    private TextView mTips;
    private Button btnComplete;
    private Button btnOpenApp;
    private ProgressBar mProgressBar;
    private TextView mProgressText;

    private int mInstallCount = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_install);

        mTips = findViewById(R.id.installer_text);
        btnComplete = findViewById(R.id.installer_left_button);
        btnOpenApp = findViewById(R.id.installer_right_button);
        mProgressBar = findViewById(R.id.installer_loading);
        mProgressText = findViewById(R.id.installer_progress_text);

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    public void onBackPressed() {
        // do nothing.
        if (mInstallCount > 0) {

        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null) {
            finish();
            return;
        }

        ArrayList<AppInfo> dataList = intent.getParcelableArrayListExtra(VCommends.EXTRA_APP_INFO_LIST);
        if (dataList == null) {
            handleSystemIntent(intent);
        } else {
            handleSelfIntent(dataList);
        }
    }

    private void handleSelfIntent(ArrayList<AppInfo> appList) {
        if (appList != null) {
            mInstallCount = appList.size();

            // 如果是安装一个app的话，检查下是否已经安装过，如果已经安装过，则提示用户是覆盖安装还是安装新的分身
            if (dealUpdate(appList)) {
                return;
            }
            installSequence(appList, 0);
        }
    }

    private void installSequence(final ArrayList<AppInfo> appList, final int index) {
        if (index < appList.size()) {
            AppInfo item = appList.get(index);

            // 顺序安装
            installApp(item).done(result -> {
                if (result.isSuccess) {
                    installSequence(appList, index + 1);
                }
            });
        }
    }


    private Promise<InstallResult, Throwable, Void> installApp(AppInfo appInfo) {
        VLog.i(TAG, "installApp: " + appInfo);
        mProgressText.setVisibility(View.VISIBLE);
        mProgressBar.setVisibility(View.VISIBLE);
        mProgressText.setText(getResources().getString(R.string.add_app_installing_tips, appInfo.name));

        return VUiKit.defer().when(new DeferredCallable<InstallResult, Void>() {
            @Override
            public InstallResult call() {
                return Installd.install(appInfo);
            }
        }).then(result -> {
            VLog.i(TAG, "installApp: " + appInfo + " result=" + result);
            if (result.isSuccess) {
                onInstallSuccess(appInfo);
            } else {
                onInstallFailed(result.error);
            }
        }).fail(throwable -> {
            String msg = throwable.getMessage();
            VLog.d(TAG, "fail: " + msg);
            if (msg == null) {
                msg = "Unknown";
            }
            onInstallFailed(msg);
        });
    }

    private void onInstallSuccess(final AppInfo appInfo) {
        mInstallCount--;

        // only dismiss when the app is the last to install.
        mProgressText.setText(getResources().getString(R.string.add_app_loading_complete, appInfo.name));
        mProgressBar.setVisibility(View.GONE);

        if (mInstallCount <= 0) {
            mInstallCount = 0;

            btnComplete.setVisibility(View.VISIBLE);
            btnComplete.setText(R.string.install_complete);
            btnComplete.setOnClickListener((vv) -> finish());

            btnOpenApp.setVisibility(View.VISIBLE);
            btnOpenApp.setText(R.string.install_complete_and_open);
            btnOpenApp.setOnClickListener((vv) -> {
                LoadingActivity.launch(getApplicationContext(), appInfo.packageName, 0);
                finish();
            });
        }
    }

    private void onInstallFailed(String msg) {
        VLog.d(TAG, "fail: " + msg);
        if (msg == null) {
            msg = "Unknown";
        }
        mProgressText.setText(getResources().getString(R.string.install_fail, msg));
        mProgressBar.setVisibility(View.GONE);

        btnOpenApp.setVisibility(View.VISIBLE);
        btnOpenApp.setText(R.string.install_complete);
        btnOpenApp.setOnClickListener((vv) -> finish());
    }

    private boolean dealUpdate(List<AppInfo> appList) {
        if (appList == null || appList.size() != 1) {
            return false;
        }
        AppInfo appInfoLite = appList.get(0);
        if (appInfoLite == null) {
            return false;
        }

//        List<String> magicApps = Arrays.asList(EncodeUtils.decode("Y29tLmxiZS5wYXJhbGxlbA=="), // com.lbe.parallel
//                EncodeUtils.decode("aW8udmlydHVhbGFwcC5zYW5kdnhwb3NlZA=="), // io.virtualapp.sandvxposed
//                EncodeUtils.decode("Y29tLnNrLnNwYXRjaA=="), // com.sk.spatch
//                EncodeUtils.decode("Y29tLnFpaG9vLm1hZ2lj"), // com.qihoo.magic
//                EncodeUtils.decode("Y29tLmRvdWJsZW9wZW4=")); // com.doubleopen
//
//        if (magicApps.contains(appInfoLite.packageName)) {
//            Toast.makeText(VirtualCore.get().getContext(), R.string.install_self_eggs, Toast.LENGTH_SHORT).show();
//        }

        if (appInfoLite.disableMultiVersion) {
            return false;
        }
        InstalledAppInfo installedAppInfo = VirtualCore.get().getInstalledAppInfo(appInfoLite.packageName, 0);
        if (installedAppInfo == null) {
            return false;
        }
        String currentVersion;
        String toInstalledVersion;
        int currentVersionCode;
        int toInstalledVersionCode;
        PackageManager packageManager = getPackageManager();
        if (packageManager == null) {
            return false;
        }
        try {
            PackageInfo applicationInfo = installedAppInfo.getPackageInfo(0);
            currentVersion = applicationInfo.versionName;
            currentVersionCode = applicationInfo.versionCode;

            Log.e(Tags.TAG, "dealUpdate installer packge:" + applicationInfo.packageName + ", versionName:" + currentVersion + ", versionCode:" + currentVersionCode);

            PackageInfo packageArchiveInfo = packageManager.getPackageArchiveInfo(appInfoLite.path, 0);
            toInstalledVersion = packageArchiveInfo.versionName;
            toInstalledVersionCode = packageArchiveInfo.versionCode;

            String multiVersionUpdate = getResources().getString(currentVersionCode == toInstalledVersionCode ? R.string.multi_version_cover : (
                    currentVersionCode < toInstalledVersionCode ? R.string.multi_version_upgrade : R.string.multi_version_downgrade
            ));
            AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setTitle(R.string.multi_version_tip_title)
                    .setMessage(getResources().getString(R.string.multi_version_tips_content, currentVersion, toInstalledVersion))
                    .setPositiveButton(R.string.multi_version_multi, (dialog, which) -> {
                        installApp(appInfoLite);
                    })
                    .setOnCancelListener(dialog -> finish())
                    .setNegativeButton(multiVersionUpdate, ((dialog, which) -> {
                        appInfoLite.disableMultiVersion = true;
                        installApp(appInfoLite);
                    }))
                    .create();
            alertDialog.show();
        } catch (Throwable ignored) {
            return false;
        }
        return true;
    }




    private void handleSystemIntent(Intent intent) {

        Context context = VirtualCore.get().getContext();
        String path;
        try {
            path = FileUtils.getFileFromUri(context, intent.getData());
        } catch (Throwable e) {
            e.printStackTrace();
            return;
        }
        PackageInfo pkgInfo = null;
        try {
            pkgInfo = context.getPackageManager().getPackageArchiveInfo(path, PackageManager.GET_META_DATA);
            pkgInfo.applicationInfo.sourceDir = path;
            pkgInfo.applicationInfo.publicSourceDir = path;
        } catch (Exception e) {
            // Ignore
        }
        if (pkgInfo == null) {
            finish();
            return;
        }

        boolean isXposed = pkgInfo.applicationInfo.metaData != null
                && pkgInfo.applicationInfo.metaData.containsKey("xposedmodule");

        InstalledAppInfo installedAppInfo = VirtualCore.get().getInstalledAppInfo(pkgInfo.packageName, 0);

        String tipsText;
        String rightString;
        String leftString = getResources().getString(android.R.string.cancel);

        PackageManager packageManager = getPackageManager();
        if (packageManager == null) {
            finish();
            return;
        }

        final String packageName = pkgInfo.packageName;
        String toInstalledVersion = pkgInfo.versionName;
        int toInstalledVersionCode = pkgInfo.versionCode;
        CharSequence label = packageName;

        if (installedAppInfo != null) {
            String currentVersion;
            int currentVersionCode;

            PackageInfo applicationInfo = installedAppInfo.getPackageInfo(0);
            if (applicationInfo == null) {
                finish();
                return;
            }
            currentVersion = applicationInfo.versionName;
            currentVersionCode = applicationInfo.versionCode;

            label = applicationInfo.applicationInfo.loadLabel(packageManager);

            String multiVersionUpdate = getResources().getString(currentVersionCode == toInstalledVersionCode ? R.string.multi_version_cover : (
                    currentVersionCode < toInstalledVersionCode ? R.string.multi_version_upgrade : R.string.multi_version_downgrade
            ));

            tipsText = getResources().getString(R.string.install_package_version_tips, currentVersion, toInstalledVersion);
            rightString = multiVersionUpdate;

        } else {
            tipsText = getResources().getString(R.string.install_package, label);
            rightString = getResources().getString(R.string.install);
        }

        final CharSequence apkName = label;
        mTips.setText(tipsText);
        btnComplete.setText(leftString);
        btnOpenApp.setText(rightString);

        btnComplete.setOnClickListener(v -> finish());
        btnOpenApp.setOnClickListener(v -> {

            mProgressBar.setVisibility(View.VISIBLE);
            mTips.setVisibility(View.GONE);
            btnComplete.setVisibility(View.GONE);
            btnOpenApp.setEnabled(false);

            VUiKit.defer().when(() -> {
                return VAppManager.get().installPackage(path, InstallStrategy.UPDATE_IF_EXIST);
            }).done((res) -> {
                // install success
                mTips.setVisibility(View.GONE);
                mProgressText.setVisibility(View.VISIBLE);
                mProgressText.setText(getResources().getString(R.string.add_app_loading_complete, apkName));
                mProgressBar.setVisibility(View.GONE);
                btnOpenApp.setVisibility(View.VISIBLE);
                btnOpenApp.setEnabled(true);
                btnOpenApp.setText(R.string.install_complete_and_open);
                btnOpenApp.setOnClickListener(vv -> {
                    LoadingActivity.launch(this, packageName, 0);
                    finish();
                });
                btnComplete.setVisibility(View.VISIBLE);
                btnComplete.setEnabled(true);
                btnComplete.setText(res.isSuccess ? getResources().getString(R.string.install_complete) :
                        getResources().getString(R.string.install_fail, res.error));
                btnComplete.setOnClickListener((vv) -> finish());
            }).fail((res) -> {
                String msg = res.getMessage();
                if (msg == null) {
                    msg = "Unknown";
                }
                mProgressText.setVisibility(View.VISIBLE);
                mProgressText.setText(getResources().getString(R.string.install_fail, msg));
                btnOpenApp.setEnabled(true);
                mProgressBar.setVisibility(View.GONE);
                btnOpenApp.setText(android.R.string.ok);
                btnOpenApp.setOnClickListener((vv) -> finish());
            });
        });
    }
}
