package io.virtualapp.home.myhome

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import android.content.Context
import com.lody.virtual.client.core.VirtualCore
import com.lody.virtual.client.ipc.VActivityManager
import com.lody.virtual.helper.utils.VLog
import com.lody.virtual.os.VUserManager
import com.lody.virtual.remote.InstalledAppInfo
import com.lody.virtual.server.ProcessInfo
import com.lody.virtual.server.interfaces.IPackageObserver
import com.lody.virtual.server.interfaces.IProcessObserver
import com.lody.virtual.server.pm.VAppManager
import io.virtualapp.abs.ui.VUiKit
import io.virtualapp.home.models.BaseAppInfo
import org.jdeferred.DeferredCallable


class HomeController(var context: Context): ViewModel() {

    companion object {
        const val TAG = "HomeController"
    }

    var mListLiveData: MutableLiveData<List<HomeAppItem>> = MutableLiveData()
    var isLoading: MutableLiveData<Boolean> = MutableLiveData()


    private val packageObserver: IPackageObserver = object : VAppManager.PackageObserver() {
        override fun onPackageInstalled(packageName: String) {
            loadAsync()
        }

        override fun onPackageUninstalled(packageName: String) {
            loadAsync()
        }

        override fun onPackageInstalledAsUser(userId: Int, packageName: String) {
            loadAsync()
        }

        override fun onPackageUninstalledAsUser(userId: Int, packageName: String) {
            loadAsync()
        }
    }

    private val processObserver: IProcessObserver = object : IProcessObserver.Stub() {

        override fun onProcessCreated(processInfo: ProcessInfo?) {
            val processInfos = mListLiveData.value
            if (processInfos != null) {
                val index = processInfos.indexOfFirst {
                    // 监听主进程，所以使用processName进行匹配
                    it.baseAppInfo?.packageName == processInfo?.processName && it.userId == processInfo?.userId
                }
                if (index != -1) {
                    processInfos[index].isRunning = true
                    mListLiveData.postValue(processInfos)
                }
            }
        }

        override fun onProcessDied(processInfo: ProcessInfo?) {
            VLog.d(TAG, "onProcessDied: $processInfo")
            val processInfos = mListLiveData.value
            if (processInfos != null) {
                val index = processInfos.indexOfFirst {
                    // 监听主进程，所以使用processName进行匹配
                    it.baseAppInfo?.packageName == processInfo?.processName && it.userId == processInfo?.userId
                }
                if (index != -1) {
                    processInfos[index].isRunning = false
                    mListLiveData.postValue(processInfos)
                }
            }
        }
    }

    init {
        VAppManager.get().registerObserver(packageObserver)
        VActivityManager.get().registerProcessObserver(processObserver)
    }


    fun onDestroy() {
        VAppManager.get().unregisterObserver(packageObserver)
        VActivityManager.get().unregisterProcessObserver(processObserver)
    }

    fun loadAsync() {
        isLoading.postValue(true)

        VUiKit.defer().`when`(object : DeferredCallable<List<HomeAppItem>, Int>() {
            override fun call(): List<HomeAppItem> {
                return loadApp()
            }
        }).done { data ->
            // 成功
            isLoading.postValue(false)
            mListLiveData.postValue(data)
        }
    }

    private fun loadApp(): MutableList<HomeAppItem> {
        val ret: MutableList<HomeAppItem> = ArrayList()


        // 根据用户进行分组
        val allUsers = VUserManager.get().users
        for (user in allUsers) {
            val userApps: List<InstalledAppInfo> = VAppManager.get().getInstalledAppsAsUser(user.id, 0)
            if (userApps.isEmpty()) {
                continue
            }
            ret.add(HomeAppItem().apply {
                userId = user.id
                viewType = 1
            })
            for (app in userApps) {
                val appItem = HomeAppItem().apply {
                    userId = user.id

                    val applicationInfo = app.getApplicationInfo(user.id)
                    isRunning = VActivityManager.get().isAppRunning(app.packageName, user.id)

                    baseAppInfo = BaseAppInfo(
                        name = applicationInfo.loadLabel(context.packageManager),
                        packageName = app.packageName,
                        path = applicationInfo.sourceDir
                    )
                }
                VLog.d(TAG, "appItem: $appItem")
                ret.add(appItem)
            }
        }
        return ret
    }
}