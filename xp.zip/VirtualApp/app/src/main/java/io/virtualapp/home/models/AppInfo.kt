package io.virtualapp.home.models

import android.graphics.drawable.Drawable
import android.os.Parcel
import android.os.Parcelable

/**
 * app信息, 已经安装的app列表，以及app安装过程中的信息对象
 */
open class AppInfo @JvmOverloads constructor(
    packageName: String?,
    path: String? = null,
    icon: Drawable? = null,
    name: CharSequence? = null,

    // 版本
    @JvmField
    var version: CharSequence? = null,

    // 克隆数量，用来在列表中显示当前app被克隆了多少次
    @JvmField
    @Transient
    var cloneCount: Int = 0,

    // 是否是拆分apk
    @JvmField
    var splitApk: Boolean = false,

    // 目前只有魅族手机这个值会被设置成true
    // 如果该标志为true， 则安装的时候不会copy apk文件到app目录下，而是直接使用外部安装的原始的apk文件
    @JvmField
    var fastOpen: Boolean = false,

    // 禁止多开，只能覆盖安装
    @JvmField
    var disableMultiVersion: Boolean = false

) : BaseAppInfo(
    packageName = packageName,
    path = path,
    icon = icon,
    name = name
), Parcelable {

    fun clone(): AppInfo {
        return AppInfo(
            packageName,
            path,
            icon,
            name,
            version,
            cloneCount,
            splitApk,
            fastOpen,
            disableMultiVersion
        )
    }

    override fun toString(): String {
        return "AppInfo(packageName=$packageName, path=$path, icon=$icon, name=$name, version=$version, " +
                "cloneCount=$cloneCount, splitApk=$splitApk, fastOpen=$fastOpen, disableMultiVersion=$disableMultiVersion)"
    }


    constructor(parcel: Parcel) : this(
        packageName = parcel.readString(),
        path = parcel.readString(),
        name = parcel.readString(),
        version = parcel.readString(),
        splitApk = parcel.readByte() != 0.toByte(),
        fastOpen = parcel.readByte() != 0.toByte(),
        disableMultiVersion = parcel.readByte() != 0.toByte()
    ) {
    }

    override fun describeContents(): Int {
        return 0
    }


    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(packageName)
        dest.writeString(path)
        dest.writeString(name.toString())
        dest.writeString(version.toString())
        dest.writeByte(if (splitApk) 1 else 0)
        dest.writeByte(if (fastOpen) 1 else 0)
        dest.writeByte(if (disableMultiVersion) 1 else 0)
    }


    companion object CREATOR : Parcelable.Creator<AppInfo> {
        override fun createFromParcel(parcel: Parcel): AppInfo {
            return AppInfo(parcel)
        }

        override fun newArray(size: Int): Array<AppInfo?> {
            return arrayOfNulls(size)
        }
    }

}