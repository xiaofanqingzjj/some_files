package io.virtualapp.widgets

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import kotlin.math.roundToInt


class LoadingView @JvmOverloads constructor(context: Context, attributeView: AttributeSet? = null) :
    RelativeLayout(context, attributeView) {

    private var animView: EatBeansView
    private var icon: ImageView
    private var text: TextView

    init {
        setBackgroundColor(Color.parseColor("#F8F8F8")) // 设置背景颜色

        animView = EatBeansView(context).apply {
            id = View.generateViewId()
            layoutParams = LayoutParams(
                LayoutParams.MATCH_PARENT,
                dpToPx(30) // 30dp 转换为像素
            )
        }
        addView(animView) // 添加到布局中

        icon = ImageView(context).apply {
            layoutParams = LayoutParams(
                dpToPx(64),  // 64dp 转换为像素
                dpToPx(64) // 64dp 转换为像素
            ).apply {
                addRule(CENTER_VERTICAL)
                setMargins(dpToPx(64), 0, 0, 0)
            }
            id = View.generateViewId()
        }
        addView(icon) // 添加到布局中

        text = TextView(context).apply {
            layoutParams = LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT
            ).apply {
                addRule(ALIGN_BOTTOM, icon.id)
                setMargins(dpToPx(20), 0, 0, dpToPx(25))
                addRule(RIGHT_OF, icon.id)
            }
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK) // 设置文本颜色
        }
        addView(text) // 添加到布局中
    }

    // dp 转 px
    private fun dpToPx(dp: Int): Int {
        val density: Float = resources.displayMetrics.density
        return (dp * density).roundToInt()
    }

    fun setText(text: String) {
        this.text.text = text
    }

    fun setIcon(icon: Drawable?) {
        this.icon.setImageDrawable(icon)
    }

    fun startAnim() {
        animView.startAnim();
    }

    fun stopAnim() {
        animView.stopAnim();
    }


}