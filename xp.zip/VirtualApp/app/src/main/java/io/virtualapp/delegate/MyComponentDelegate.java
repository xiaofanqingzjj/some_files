package io.virtualapp.delegate;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.hook.delegate.AppInstrumentation;
import com.lody.virtual.client.hook.delegate.ComponentDelegate;
import com.lody.virtual.client.hook.utils.ExternalStorageHook;
import com.lody.virtual.helper.utils.Reflect;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.wchat.LogProxy;
import com.lody.virtual.wchat.WWorkLogProxy;

import java.lang.reflect.Constructor;

import io.virtualapp.compat.WChatCompat;


public class MyComponentDelegate implements ComponentDelegate {

    static final String TAG = "MyComponentDelegate";

    private WChatCompat wChatCompat = new WChatCompat();

    @Override
    public void beforeApplicationCreate(Application application) {
        ExternalStorageHook.processContext(VirtualCore.get().getContext(), application);
        String packageName = application.getPackageName();
        if ("com.tencent.mm".equals(packageName)) {
            Log.e(TAG, "hookWchatLog:" + packageName + ", process:" + packageName);
            LogProxy.hookWChatLog(application, packageName);
        }

        if ("com.tencent.wework".equals(packageName)) {
            Log.e(TAG, "hookWworkLog:" + packageName + ", process:" + packageName);
            WWorkLogProxy.hookWChatLog(application, packageName);
        }

    }

    @Override
    public void afterApplicationCreate(Application application) {
        VLog.d(TAG, "afterApplicationCreate:"  + application);
        // 有些app(企业微信)会自己hook Instrumentation，这使得va里的hook失效了，这里重新补hook一次
        AppInstrumentation.install();
    }

    @Override
    public void beforeActivityCreate(Activity activity) {
        ExternalStorageHook.processContext(VirtualCore.get().getContext(), activity);
    }

    @Override
    public void beforeActivityResume(Activity activity) {

    }

    @Override
    public void beforeActivityPause(Activity activity) {

    }

    @Override
    public void beforeActivityDestroy(Activity activity) {

    }



    @Override
    public void afterActivityCreate(Activity activity) {
        wChatCompat.afterActivityCreate(activity);
    }

    @Override
    public void afterActivityResume(Activity activity) {

    }

    @Override
    public void afterActivityPause(Activity activity) {

    }

    @Override
    public void afterActivityDestroy(Activity activity) {
        wChatCompat.afterActivityDestroy(activity);
    }

    @Override
    public void onSendBroadcast(Intent intent) {

    }
}
