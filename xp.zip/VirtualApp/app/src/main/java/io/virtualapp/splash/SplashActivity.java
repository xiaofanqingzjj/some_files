package io.virtualapp.splash;

import io.virtualapp.home.myhome.MyHomeActivity;

public class SplashActivity extends BaseSplashActivity {


    @Override
    public void onDone() {
        super.onDone();
        MyHomeActivity.show(this);
        finish();
    }

}
