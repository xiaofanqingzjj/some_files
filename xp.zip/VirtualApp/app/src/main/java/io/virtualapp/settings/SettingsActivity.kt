package io.virtualapp.settings

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreference
import com.fortune.va.MyTestMenu
import com.fortune.va.lib.VActivity
import com.lody.virtual.client.ipc.VActivityManager
import io.virtualapp.BuildConfig
import io.virtualapp.R
import io.virtualapp.abs.ui.VUiKit
import io.virtualapp.process_manager.ProcessManagerActivity

/**
 * Settings activity for Launcher. Currently implements the following setting: Allow rotation
 */
class SettingsActivity : VActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            // Display the fragment as the main content.
            supportFragmentManager.beginTransaction()
                .replace(R.id.fl_content, SettingsFragment())
                .commit()
        }
    }

    companion object {
        private const val ADVANCE_SETTINGS_KEY = "settings_advance"
        private const val ADD_APP_KEY = "settings_add_app"
        private const val MODULE_MANAGE_KEY = "settings_module_manage"
        private const val APP_MANAGE_KEY = "settings_app_manage"
        private const val TASK_MANAGE_KEY = "settings_task_manage"
        private const val DESKTOP_SETTINGS_KEY = "settings_desktop"
        private const val FAQ_SETTINGS_KEY = "settings_faq"
        private const val DONATE_KEY = "settings_donate"
        private const val ABOUT_KEY = "settings_about"
        private const val REBOOT_KEY = "settings_reboot"
        private const val HIDE_SETTINGS_KEY = "advance_settings_hide_settings"
        private const val DISABLE_INSTALLER_KEY = "advance_settings_disable_installer"
        const val ENABLE_LAUNCHER = "advance_settings_enable_launcher"
        private const val INSTALL_GMS_KEY = "advance_settings_install_gms"
        const val DIRECTLY_BACK_KEY = "advance_settings_directly_back"
        private const val RECOMMEND_PLUGIN = "settings_plugin_recommend"
        private const val DISABLE_RESIDENT_NOTIFICATION =
            "advance_settings_disable_resident_notification"
        private const val ALLOW_FAKE_SIGNATURE = "advance_settings_allow_fake_signature"
        private const val DISABLE_XPOSED = "advance_settings_disable_xposed"
        private const val FILE_MANAGE = "settings_file_manage"
        private const val PERMISSION_MANAGE = "settings_permission_manage"

        const val SETTING_TEST = "settings_test"

        const val SETTING_DUAL_USER_CAN_NOT_START_AT_SAME_TIME = "setting_dual_user_can_not_start_at_same_time"

        fun show(context: Context) {
            context.startActivity(Intent(context, SettingsActivity::class.java))
        }
    }

    /**
     * This fragment shows the launcher preferences.
     */
    class SettingsFragment : PreferenceFragmentCompat() {


//
//        @RequiresApi(Build.VERSION_CODES.M)
//        override fun onCreate(savedInstanceState: Bundle?) {
//            super.onCreate(savedInstanceState)
//            preferenceManager.sharedPreferencesName = LauncherFiles.SHARED_PREFERENCES_KEY
//            addPreferencesFromResource(R.xml.settings_preferences)
//
//            findPreference("setting_container")
//
//            // Setup allow rotation preference
//
////            Preference addApp = findPreference(ADD_APP_KEY);
////            Preference moduleManage = findPreference(MODULE_MANAGE_KEY);
////            Preference recommend = findPreference(RECOMMEND_PLUGIN);
////            Preference appManage = findPreference(APP_MANAGE_KEY);
////            Preference taskManage = findPreference(TASK_MANAGE_KEY);
////            Preference desktop = findPreference(DESKTOP_SETTINGS_KEY);
////            Preference faq = findPreference(FAQ_SETTINGS_KEY);
////            Preference donate = findPreference(DONATE_KEY);
//
//            //            Preference reboot = findPreference(REBOOT_KEY);
////            Preference fileMange = findPreference(FILE_MANAGE);
////            Preference permissionManage = findPreference(PERMISSION_MANAGE);
//
//
////            SwitchPreference disableInstaller = (SwitchPreference) findPreference(DISABLE_INSTALLER_KEY);
////            SwitchPreference enableLauncher = (SwitchPreference) findPreference(ENABLE_LAUNCHER);
////            SwitchPreference disableResidentNotification = (SwitchPreference) findPreference(DISABLE_RESIDENT_NOTIFICATION);
////            SwitchPreference allowFakeSignature = (SwitchPreference) findPreference(ALLOW_FAKE_SIGNATURE);
////            SwitchPreference disableXposed = (SwitchPreference) findPreference(DISABLE_XPOSED);
//
//            val about = findPreference(ABOUT_KEY)
//            about.onPreferenceClickListener = OnPreferenceClickListener {
//                startActivity(Intent(activity, AboutActivity::class.java))
//                false
//            }
//
//            val test = findPreference(SETTING_TEST);
//            test.onPreferenceClickListener = OnPreferenceClickListener {
//                MyTestMenu.Companion.show(context)
//                false
//            }
//
//            if (!BuildConfig.DEBUG) {
//                preferenceScreen.removePreference(test)
//            }
//
//            findPreference("settings_kill_all").onPreferenceClickListener = OnPreferenceClickListener {
//                VUiKit.defer().`when` {
//                    VActivityManager.get().killAllApps();
//                }.done {
//                    Toast.makeText(context, "已经关闭所有进程", Toast.LENGTH_SHORT).show()
//                }
//                false
//            }
//
//
//            findPreference("settings_process_list").onPreferenceClickListener = OnPreferenceClickListener {
//                startActivity(Intent(context, ProcessManagerActivity::class.java))
//                false
//            }
//
//            val canNotDul = (findPreference("setting_dual_user_can_not_start_at_same_time") as SwitchPreference)
//            (findPreference("setting_dual_user_can_not_start_at_same_time") as SwitchPreference).onPreferenceChangeListener =
//                OnPreferenceChangeListener { preference, newValue ->
//
//                    false
//                }
//
//
////            (findPreference("setting_dual_user_can_not_start_at_same_time") as SwitchPreference).setOnPreferenceChangeListener((preference, newValue) -> {
////                if (!(newValue instanceof Boolean)) {
////                    return false;
////                }
////                try {
////                    boolean disable = (boolean) newValue;
////                    PackageManager packageManager = getActivity().getPackageManager();
////                    packageManager.setComponentEnabledSetting(new ComponentName(getActivity().getPackageName(), "vxp.installer"),
////                    !disable ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
////                    PackageManager.DONT_KILL_APP);
////                    return true;
////                } catch (Throwable ignored) {
////                    return false;
////                }
////            });
//
//
////            addApp.setOnPreferenceClickListener(preference -> {
////                ListAppActivity.gotoListApp(getActivity());
////                return false;
////            });
////
////            moduleManage.setOnPreferenceClickListener(preference -> {
////                try {
////                    Intent t = new Intent();
////                    t.setComponent(new ComponentName("de.robv.android.xposed.installer", "de.robv.android.xposed.installer.WelcomeActivity"));
////                    t.putExtra("fragment", 1);
////                    int ret = VActivityManager.get().startActivity(t, 0);
////                    if (ret < 0) {
////                        Toast.makeText(getActivity(), R.string.xposed_installer_not_found, Toast.LENGTH_SHORT).show();
////                    }
////                } catch (Throwable ignored) {
////                    ignored.printStackTrace();
////                }
////                return false;
////            });
////
////            recommend.setOnPreferenceClickListener(preference -> {
////                startActivity(new Intent(getActivity(), RecommendPluginActivity.class));
////                return false;
////            });
////
////            boolean xposedEnabled = VirtualCore.get().isXposedEnabled();
////            if (!xposedEnabled) {
////                getPreferenceScreen().removePreference(moduleManage);
////                getPreferenceScreen().removePreference(recommend);
////            }
////
////            appManage.setOnPreferenceClickListener(preference -> {
////                startActivity(new Intent(getActivity(), AppManageActivity.class));
////                return false;
////            });
////
////            taskManage.setOnPreferenceClickListener(preference -> {
////                startActivity(new Intent(getActivity(), TaskManageActivity.class));
////                return false;
////            });
////
////            faq.setOnPreferenceClickListener(preference -> {
////                Uri uri = Uri.parse("https://github.com/android-hacker/VAExposed/wiki/FAQ");
////                Intent t = new Intent(Intent.ACTION_VIEW, uri);
////                startActivity(t);
////                return false;
////            });
////
////            desktop.setOnPreferenceClickListener(preference -> {
//////                startActivity(new Intent(getActivity(), com.google.android.apps.nexuslauncher.SettingsActivity.class));
////                return false;
////            });
////
////            donate.setOnPreferenceClickListener(preference -> {
////                Misc.showDonate(getActivity());
////                return false;
////            });
////            about.setOnPreferenceClickListener(preference -> {
////                startActivity(new Intent(getActivity(), AboutActivity.class));
////                return false;
////            });
////
////            reboot.setOnPreferenceClickListener(preference -> {
////                android.app.AlertDialog alertDialog = new android.app.AlertDialog.Builder(getActivity())
////                        .setTitle(R.string.settings_reboot_title)
////                        .setMessage(getResources().getString(R.string.settings_reboot_content))
////                        .setPositiveButton(android.R.string.yes, (dialog, which) -> {
////                            VirtualCore.get().killAllApps();
////                            Toast.makeText(getActivity(), R.string.reboot_tips_1, Toast.LENGTH_SHORT).show();
////                        })
////                        .setNegativeButton(android.R.string.no, null)
////                        .create();
////                try {
////                    alertDialog.show();
////                } catch (Throwable ignored) {
////                }
////                return false;
////            });
////
//
////
////            enableLauncher.setOnPreferenceChangeListener((preference, newValue) -> {
////                if (!(newValue instanceof Boolean)) {
////                    return false;
////                }
////                try {
////                    boolean enable = (boolean) newValue;
////                    PackageManager packageManager = getActivity().getPackageManager();
////                    packageManager.setComponentEnabledSetting(new ComponentName(getActivity().getPackageName(), "vxp.launcher"),
////                            enable ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
////                            PackageManager.DONT_KILL_APP);
////                    return true;
////                } catch (Throwable ignored) {
////                    return false;
////                }
////            });
////
////            Preference installGms = findPreference(INSTALL_GMS_KEY);
////            installGms.setOnPreferenceClickListener(preference -> {
////                boolean alreadyInstalled = FakeGms.isAlreadyInstalled(getActivity());
////                if (alreadyInstalled) {
////                    FakeGms.uninstallGms(getActivity());
////                } else {
////                    FakeGms.installGms(getActivity());
////                }
////                return true;
////            });
////
////            fileMange.setOnPreferenceClickListener(preference -> {
////                OnlinePlugin.openOrDownload(getActivity(), OnlinePlugin.FILE_MANAGE_PACKAGE,
////                        OnlinePlugin.FILE_MANAGE_URL, getString(R.string.install_file_manager_tips));
////                return false;
////            });
////
////            permissionManage.setOnPreferenceClickListener(preference -> {
////                OnlinePlugin.openOrDownload(getActivity(), OnlinePlugin.PERMISSION_MANAGE_PACKAGE,
////                        OnlinePlugin.PERMISSION_MANAGE_URL, getString(R.string.install_permission_manager_tips));
////                return false;
////            });
////
////            disableXposed.setOnPreferenceChangeListener((preference, newValue) -> {
////
////                if (!(newValue instanceof Boolean)) {
////                    return false;
////                }
////
////                boolean on = (boolean) newValue;
////
////                File disableXposedFile = getActivity().getFileStreamPath(".disable_xposed"); // 文件不存在代表是保守模式
////                if (on) {
////                    boolean success;
////                    try {
////                        success = disableXposedFile.createNewFile();
////                    } catch (IOException e) {
////                        success = false;
////                    }
////                    return success;
////                } else {
////                    return !disableXposedFile.exists() || disableXposedFile.delete();
////                }
////            });
////
////            disableResidentNotification.setOnPreferenceChangeListener(((preference, newValue) -> {
////
////                if (!(newValue instanceof Boolean)) {
////                    return false;
////                }
////
////                boolean on = (boolean) newValue;
////
////                File flag = getActivity().getFileStreamPath(Constants.NO_NOTIFICATION_FLAG);
////                if (on) {
////                    boolean success;
////                    try {
////                        success = flag.createNewFile();
////                    } catch (IOException e) {
////                        success = false;
////                    }
////                    return success;
////                } else {
////                    return !flag.exists() || flag.delete();
////                }
////            }));
////
////            if (android.os.Build.VERSION.SDK_INT < 25) {
////                // Android NR1 below do not need this.
////                PreferenceScreen advance = (PreferenceScreen) findPreference(ADVANCE_SETTINGS_KEY);
////                advance.removePreference(disableResidentNotification);
////            }
////
////            allowFakeSignature.setOnPreferenceChangeListener((preference, newValue) -> {
////                if (!(newValue instanceof Boolean)) {
////                    return false;
////                }
////
////                boolean on = (boolean) newValue;
////                File flag = getActivity().getFileStreamPath(Constants.FAKE_SIGNATURE_FLAG);
////                if (on) {
////                    boolean success;
////                    try {
////                        success = flag.createNewFile();
////                    } catch (IOException e) {
////                        success = false;
////                    }
////                    return success;
////                } else {
////                    return !flag.exists() || flag.delete();
////                }
////            });
//        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.settings_preferences, rootKey)
            val about = findPreference(ABOUT_KEY)
            about.onPreferenceClickListener = Preference.OnPreferenceClickListener {
                startActivity(Intent(activity, AboutActivity::class.java))
                false
            }

            val test = findPreference(SETTING_TEST);
            test.onPreferenceClickListener = Preference.OnPreferenceClickListener {
                MyTestMenu.Companion.show(it.context)
                false
            }

            if (!BuildConfig.DEBUG) {
                preferenceScreen.removePreference(test)
            }

            findPreference("settings_kill_all").onPreferenceClickListener =
                Preference.OnPreferenceClickListener {
                    VUiKit.defer().`when` {
                        VActivityManager.get().killAllApps();
                    }.done {
                        Toast.makeText(context, "已经关闭所有进程", Toast.LENGTH_SHORT).show()
                    }
                    false
                }


            findPreference("settings_process_list").onPreferenceClickListener =
                Preference.OnPreferenceClickListener {
                    startActivity(Intent(context, ProcessManagerActivity::class.java))
                    false
                }

            (findPreference(SETTING_DUAL_USER_CAN_NOT_START_AT_SAME_TIME) as SwitchPreference).onPreferenceChangeListener =
                Preference.OnPreferenceChangeListener { preference, newValue ->
                    // 在这里处理开关状态的变化
                    val switchedOn = newValue as Boolean
                    // 执行相应的操作
                    true // 返回 true 表示接受新的值
                }


//            (findPreference("setting_dual_user_can_not_start_at_same_time") as SwitchPreference).setOnPreferenceChangeListener((preference, newValue) -> {
//                if (!(newValue instanceof Boolean)) {
//                    return false;
//                }
//                try {
//                    boolean disable = (boolean) newValue;
//                    PackageManager packageManager = getActivity().getPackageManager();
//                    packageManager.setComponentEnabledSetting(new ComponentName(getActivity().getPackageName(), "vxp.installer"),
//                    !disable ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
//                    PackageManager.DONT_KILL_APP);
//                    return true;
//                } catch (Throwable ignored) {
//                    return false;
//                }
//            });
        }

        protected fun dp2px(dp: Float): Int {
            val scale = resources.displayMetrics.density
            return (dp * scale + 0.5f).toInt()
        }

        override fun startActivity(intent: Intent) {
            try {
                super.startActivity(intent)
            } catch (ignored: Throwable) {
                Toast.makeText(activity, "startActivity failed.", Toast.LENGTH_SHORT).show()
                ignored.printStackTrace()
            }
        }

        companion object {
            private fun dismiss(dialog: ProgressDialog) {
                try {
                    dialog.dismiss()
                } catch (ignored: Throwable) {
                }
            }
        }
    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
//        if (requestCode == VCommends.REQUEST_SELECT_APP) {
//            if (resultCode == RESULT_OK) {
//                finish()
//            }
//        }
//    }


}