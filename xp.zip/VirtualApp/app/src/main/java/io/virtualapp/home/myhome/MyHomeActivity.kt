package io.virtualapp.home.myhome

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.fortune.va.lib.VActivity
import com.lody.virtual.client.ipc.VActivityManager
import com.tencent.da.permissionrequestor.PermissionsRequestor
import io.virtualapp.R
import io.virtualapp.abs.ui.VUiKit
import io.virtualapp.home.ListAppActivity
import io.virtualapp.home.LoadingActivity
import io.virtualapp.settings.SettingsActivity
import io.virtualapp.utils.PreferenceUtils

/**
 * 首页
 */
class MyHomeActivity : VActivity() {

    companion object {
        @JvmStatic
        fun show(context: Context) {
            context.startActivity(Intent(context, MyHomeActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    private lateinit var homeController: HomeController

    private var mAdapter: AppListAdapter = AppListAdapter(this, mutableListOf())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 启用返回按钮
        supportActionBar?.setDisplayHomeAsUpEnabled(false);
        supportActionBar?.setDisplayShowHomeEnabled(false);
        supportActionBar?.title = "  应用多开"

        setContentView(R.layout.activity_my_home)

        findViewById<View>(R.id.fab_add_app).setOnClickListener { _: View? ->
            ListAppActivity.gotoListApp(activity)
        }

        val progressBar = findViewById<View>(R.id.progress);
        val tvEmpty = findViewById<View>(R.id.empty_view)
        val mListView = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.list)
        mListView.layoutManager = LinearLayoutManager(context)
        mListView.adapter = mAdapter
        mAdapter.setOnItemClickListener { _, item ->

            // 先关闭其他分身进程
            VUiKit.defer().`when` {
                val  canNotLaunchSameTime = PreferenceUtils.getBoolean(SettingsActivity.SETTING_DUAL_USER_CAN_NOT_START_AT_SAME_TIME, true)
                if (canNotLaunchSameTime) {
                    VActivityManager.get().killAppByPackageNameUnlessUser(item.baseAppInfo?.packageName, item.userId)
                    Thread.sleep(200)
                }
            }.done {
                LoadingActivity.launch(
                    applicationContext,
                    item.baseAppInfo?.packageName,
                    item.userId
                )
            }
            true
        }

        homeController = HomeController(this)


        homeController.mListLiveData.observe(this,
            Observer<List<HomeAppItem>> { appItems ->
                mAdapter.datas = appItems
                tvEmpty.visibility = if (appItems.isNullOrEmpty()) View.VISIBLE else View.GONE
            })
        homeController.isLoading.observe(this, Observer<Boolean> { isLoading ->
            progressBar.visibility = if (isLoading == true) View.VISIBLE else View.GONE
        })


        homeController.loadAsync()

        // 读取相机权限
        val permissionsRequestor = PermissionsRequestor(this)
        permissionsRequestor.request(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE))


    }

    override fun onDestroy() {
        super.onDestroy()
        homeController.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // 加载菜单布局
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                SettingsActivity.show(this)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}