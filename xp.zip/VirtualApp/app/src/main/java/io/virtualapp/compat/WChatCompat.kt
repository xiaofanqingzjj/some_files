package io.virtualapp.compat

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.lody.virtual.client.hook.utils.Utils
import com.lody.virtual.helper.utils.Reflect
import io.virtualapp.home.repo.PackageAppDataStorage
import io.virtualapp.widgets.LoadingView


/**
 * 微信兼容起
 *
 * 当未启动微信，在其他的app点击使用微信登录时，微信打开：com.tencent.mm.plugin.base.stub.UIEntryStub时，界面是透明的，而且这个有时候停留时间特别长
 * 给用户的感觉就是微信退出来了，这个给这个类增加一个Loading页
 */
class WChatCompat {

    companion object {
        const val TAG = "MMUIEntryStubCompat"

        const val UI_ENTRY_STUB_CLASS_NAME = "com.tencent.mm.plugin.base.stub.UIEntryStub"
    }

    private var loadingView: LoadingView? = null
    private var container: ViewGroup? = null


    fun afterActivityCreate(activity: Activity) {
        if (UI_ENTRY_STUB_CLASS_NAME == activity.javaClass.name) {
            addLoadingView(activity)
        }

        // 修复微信8.0.54版本分身的一个crash
        /**
         *
         *                                                                                                     java.lang.RuntimeException: java.lang.NullPointerException: Attempt to invoke virtual method 'void android.view.View.setVisibility(int)' on a null object reference
         *                                                                                                         at com.tencent.mm.ui.ve.run(Unknown Source:4)
         *                                                                                                         at android.os.Handler.handleCallback(Handler.java:958)
         *                                                                                                         at android.os.Handler.dispatchMessage(Handler.java:99)
         *                                                                                                         at android.os.Looper.loopOnce(Looper.java:255)
         *                                                                                                         at android.os.Looper.loop(Looper.java:364)
         *                                                                                                         at android.app.ActivityThread.main(ActivityThread.java:8979)
         *                                                                                                         at java.lang.reflect.Method.invoke(Native Method)
         *                                                                                                         at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:572)
         *                                                                                                         at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1053)
         *                                                                                                     Caused by: java.lang.NullPointerException: Attempt to invoke virtual method 'void android.view.View.setVisibility(int)' on a null object reference
         *                                                                                                         at com.tencent.mm.ui.we.queueIdle(Unknown Source:57)
         *                                                                                                         at android.os.MessageQueue.next(MessageQueue.java:432)
         *                                                                                                         at android.os.Looper.loopOnce(Looper.java:187)
         *                                                                                                         at android.os.Looper.loop(Looper.java:364)
         *                                                                                                         at android.app.ActivityThread.main(ActivityThread.java:8979)
         *                                                                                                         at java.lang.reflect.Method.invoke(Native Method)
         *                                                                                                         at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:572)
         *                                                                                                         at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:1053)
         */
        if ("com.tencent.mm.ui.LauncherUI" == activity.javaClass.name) {
            val chattingTabUI = Reflect.on(activity).get<Any>("chattingTabUI")
            Log.d(TAG, "chattingTabUI:$chattingTabUI")
            if (chattingTabUI != null) {
                val chattingTabUIRef = Reflect.on(chattingTabUI)
                val testTimeForChatting = chattingTabUIRef.get<Any>("c")
                Log.d(TAG, "testTimeForChatting:$testTimeForChatting")
                try {
                    val testTimeForChattingClazz = Class.forName(
                        "com.tencent.mm.ui.tools.TestTimeForChatting",
                        true,
                        activity.classLoader
                    )
                    Log.d(
                        TAG,
                        "testTimeForChattingClazz$testTimeForChattingClazz"
                    )
                    val constructor = testTimeForChattingClazz.getConstructor(
                        Context::class.java
                    )
                    val testTimeForChattingNew = constructor.newInstance(activity)
                    chattingTabUIRef["c"] = testTimeForChattingNew
                    Log.d(
                        TAG,
                        "testTimeForChatting new" + chattingTabUIRef.get<Any>("c")
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "", e)
                }
            }
        }
    }


    fun afterActivityDestroy(activity: Activity) {
        if (UI_ENTRY_STUB_CLASS_NAME == activity.javaClass.name) {
            removeLoadingView(activity)
        }
    }

    private fun addLoadingView(activity: Activity) {
        val decorView = activity.window.decorView as ViewGroup
        val appModel = PackageAppDataStorage.get().acquire("com.tencent.mm")
        loadingView = LoadingView(activity).apply {
            setText("正在打开微信...")
            setIcon(appModel.icon)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Utils.dip2px(activity, 130f))).apply {
                gravity = Gravity.BOTTOM
            }
        }

        // 创建一个 FrameLayout 作为容器
        container = FrameLayout(activity).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.TRANSPARENT) // 设置背景为透明
            addView(loadingView)
        }
        decorView.addView(container)
        loadingView?.startAnim()
    }

    private fun removeLoadingView(activity: Activity) {
        if (loadingView != null) {
            loadingView?.stopAnim()
            val decorView = activity.window.decorView as ViewGroup
            decorView.removeView(container)
        }
    }




}