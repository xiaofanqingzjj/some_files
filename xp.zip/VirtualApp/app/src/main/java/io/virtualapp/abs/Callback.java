package io.virtualapp.abs;

/**
 * @author Lody
 */

public interface Callback<T> {
    void callback(T result);
}
