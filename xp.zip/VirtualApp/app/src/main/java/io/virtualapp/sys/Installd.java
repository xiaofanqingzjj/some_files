package io.virtualapp.sys;

import com.lody.virtual.client.core.InstallStrategy;
import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.helper.utils.DeviceUtil;
import com.lody.virtual.helper.utils.VLog;
import com.lody.virtual.os.VUserInfo;
import com.lody.virtual.os.VUserManager;
import com.lody.virtual.remote.InstallResult;
import com.lody.virtual.remote.InstalledAppInfo;
import com.lody.virtual.server.pm.VAppManager;

import io.virtualapp.home.models.AppInfo;

/**
 * author: weishu on 18/3/19.
 */
public class Installd {

    static final String TAG = "Installd";

    private static int genNextUserIdForApp(InstalledAppInfo installedAppInfo) {
        int[] userIds = installedAppInfo.getInstalledUsers();
        // 生成一个userId
        int nextUserId = userIds.length;
        /*
          Input : userIds = {0, 1, 3}
          Output: nextUserId = 2
         */
        for (int i = 0; i < userIds.length; i++) {
            if (userIds[i] != i) {
                nextUserId = i;
                break;
            }
        }
        return nextUserId;
    }


    /**
     * 安装一个app到VA中
     * @param appInfo app信息
     * @return 安装结果
     */
    public static InstallResult install(AppInfo appInfo) {
        // 检查是否已经安装了对应的app
        final InstalledAppInfo installedAppInfo = VirtualCore.get().getInstalledAppInfo(appInfo.packageName, 0);
        if (installedAppInfo != null && !appInfo.disableMultiVersion) { // 已经安装过， 安装分身
            return installAppClone(installedAppInfo);
        } else { // 第一次安装
            return installApp(appInfo);
        }
    }


    /**
     * 对已经安装过的app进行分身安装
     * @param installedAppInfo 已经安装的app信息
     * @return 安装结果
     */
    public static InstallResult installAppClone(InstalledAppInfo installedAppInfo) {
        // 为app生成一个userId
        int nextUserId = genNextUserIdForApp(installedAppInfo);
        // 检查userId是否有UserInfo信息，如果没有则创建创建一个
        if (VUserManager.get().getUserInfo(nextUserId) == null) {
            // user not exist, create it automatically.
            String nextUserName = "Space " + (nextUserId + 1);
            VUserInfo newUserInfo = VUserManager.get().createUser(nextUserName, VUserInfo.FLAG_ADMIN);
            if (newUserInfo == null) {
                throw new IllegalStateException();
            }
            VLog.d(TAG, "createUserInfo nextUserId:" + nextUserId + ", newUserInfo:" + newUserInfo);
        }
        // 太快了，加点停顿
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            // ignore
        }
        // 为用户安装app
        boolean success = VAppManager.get().installPackageAsUser(nextUserId, installedAppInfo.packageName);
        InstallResult result =  new InstallResult();
        result.isSuccess = success;
        return result;
    }


    /**
     * 安装一个app到VA中
     * @param appInfo app信息
     * @return 安装结果
     */
    public static InstallResult installApp(AppInfo appInfo) {
        int flags = InstallStrategy.COMPARE_VERSION | InstallStrategy.SKIP_DEX_OPT;
        appInfo.fastOpen = false; // disable fast open for compile.
        if (DeviceUtil.isMeizuBelowN()) {
            appInfo.fastOpen = true;
        }
        if (appInfo.fastOpen) {
            flags |= InstallStrategy.DEPEND_SYSTEM_IF_EXIST;
        }
        if (appInfo.disableMultiVersion) {
            flags |= InstallStrategy.UPDATE_IF_EXIST;
        }
        return VAppManager.get().installPackage(appInfo.path, flags);
    }



//    public static void addGmsSupport() {
//        List<String> gApps = new ArrayList<>();
//        gApps.addAll(GmsSupport.GOOGLE_APP);
//        gApps.addAll(GmsSupport.GOOGLE_SERVICE);
//
//        VirtualCore core = VirtualCore.get();
//        final int userId = 0;
//
//        ArrayList<AppInfo> toInstalled = new ArrayList<>();
//        for (String packageName : gApps) {
//            if (core.isAppInstalledAsUser(userId, packageName)) {
//                continue;
//            }
//            ApplicationInfo info = null;
//            try {
//                info = VirtualCore.get().getUnHookPackageManager().getApplicationInfo(packageName, 0);
//            } catch (PackageManager.NameNotFoundException e) {
//                // Ignore
//            }
//            if (info == null || info.sourceDir == null) {
//                continue;
//            }
//
//            AppInfo lite = new AppInfo("", info.packageName, info.sourceDir, false, true);
//            toInstalled.add(lite);
//        }
//        startInstallerActivity(VirtualCore.get().getContext(), toInstalled);
//    }
}
