package io.virtualapp.home.models

import android.graphics.drawable.Drawable
import android.os.Parcel
import android.os.Parcelable

/**
 * app的基础信息
 */
open class BaseAppInfo @JvmOverloads constructor(
    /**
     * 包名
     */
    @JvmField
    var packageName: String? = null,

    /**
     * apk路径
     */
    @JvmField
    var path: String? = null,

    /**
     * icon
     */
    @JvmField
    var icon: Drawable? = null,

    /**
     * app名称
     */
    @JvmField
    var name: CharSequence? = null
)