package io.virtualapp.utils

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStoreOwner

object ViewModeProviderUtils {
    fun <T : ViewModel>  getViewModel(storeOwner: ViewModelStoreOwner, clazz: Class<T>): T {
        return ViewModelProvider(storeOwner, ViewModelFactory()).get(clazz)
    }


    class ViewModelFactory : ViewModelProvider.Factory {
        override fun <T : ViewModel>  create(modelClass: Class<T>): T {
            return  modelClass.newInstance()
        }
    }
}
