package io.virtualapp.home.myhome

import io.virtualapp.home.models.BaseAppInfo

/**
 * 首页的应用信息
 */
class HomeAppItem(var baseAppInfo: BaseAppInfo? = null){


    // 显示在里表上的名字
    val label: String
        get() {
            return "${baseAppInfo?.name} ${if (userId != 0) "[$userId]" else ""}"
        }

    // 用户id
    @JvmField
    var userId = 0

    // app是否正在运行
    var isRunning: Boolean = false

    /**
     * 0: app, 1: group
     */
    var viewType: Int = 0

    override fun toString(): String {
        return "AppItem(name=${baseAppInfo?.name}, userId=$userId, icon=${baseAppInfo?.icon}, pkgName=${baseAppInfo?.packageName}, path=${baseAppInfo?.path})"
    }
}