package io.virtualapp.home

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import io.virtualapp.R
import io.virtualapp.VCommends
import com.fortune.va.lib.VActivity

/**
 * @author Lody
 */
class ListAppActivity : VActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.setTitle(R.string.clone_apps)
        replaceFragment(ListAppFragment.newInstance(null))
    }

    companion object {
        @JvmStatic
        fun gotoListApp(activity: Activity) {
            val intent = Intent(activity, ListAppActivity::class.java)
            activity.startActivityForResult(intent, VCommends.REQUEST_SELECT_APP)
        }
    }
}