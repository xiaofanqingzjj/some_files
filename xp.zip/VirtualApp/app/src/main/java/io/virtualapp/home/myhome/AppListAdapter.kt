package io.virtualapp.home.myhome

import android.content.Context
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.fortune.va.utils.BaseViewTypeAdapter
import com.lody.virtual.client.core.VirtualCore
import io.virtualapp.R
import io.virtualapp.glide.GlideUtils

internal class AppListAdapter(context: Context, apps: List<HomeAppItem>) :
    BaseViewTypeAdapter<HomeAppItem>(context, apps) {

    init {
        addViewType(0, VAApp::class.java)
        addViewType(1, VAGroup::class.java)
    }


    override fun getItemViewType(position: Int): Int {
        return getItem(position).viewType
    }

    class VAGroup : ViewTypeViewHolder<HomeAppItem>() {

        private lateinit var tvText: TextView

        override fun onCreate() {
            super.onCreate()
            setContentView(R.layout.item_group_app_item)
            tvText = findViewById(R.id.text1)
        }

        override fun bindData(position: Int, data: HomeAppItem?) {
            tvText.text = "userId: ${data?.userId}"
        }
    }

    class VAApp : ViewTypeViewHolder<HomeAppItem>() {

        private lateinit var icon: ImageView
        private lateinit var tvName: TextView
        private lateinit var moreMenu: View
        private lateinit var ivRunning: View

        override fun onCreate() {
            super.onCreate()
            setContentView(R.layout.item_home_app_cell)
            icon = findViewById(R.id.item_app_icon)
            tvName = findViewById(R.id.item_app_name)
            moreMenu = findViewById(R.id.item_app_button)
            ivRunning = findViewById(R.id.iv_running)
        }

        override fun bindData(position: Int, item: HomeAppItem) {
            val baseAppInfo = item.baseAppInfo!!
            if (VirtualCore.get().isOutsideInstalled(baseAppInfo.packageName)) {
                GlideUtils.loadInstalledPackageIcon(
                    context,
                    baseAppInfo.packageName,
                    icon,
                    android.R.drawable.sym_def_app_icon
                )
            } else {
                GlideUtils.loadPackageIconFromApkFile(
                    context,
                    baseAppInfo.path,
                    icon,
                    android.R.drawable.sym_def_app_icon
                )
            }
            tvName.text = item.label
            moreMenu.setOnClickListener { v ->
                AppContextMenuHelper.showContextMenu(item, v)
            }
            ivRunning.visibility = if (item.isRunning) View.VISIBLE else View.GONE
        }
    }
}