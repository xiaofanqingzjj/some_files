package io.virtualapp.home.repo;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.remote.InstalledAppInfo;

import java.util.HashMap;
import java.util.Map;

import io.virtualapp.XApp;
import io.virtualapp.abs.Callback;
import io.virtualapp.abs.ui.VUiKit;
import io.virtualapp.home.models.AppInfo;
import io.virtualapp.home.models.BaseAppInfo;

/**
 * @author Lody
 *         <p>
 *         Cache the loaded PackageAppData.
 */
public class PackageAppDataStorage {

    private static final PackageAppDataStorage STORAGE = new PackageAppDataStorage();
    private final Map<String, PackageAppData> packageDataMap = new HashMap<>();

    public static PackageAppDataStorage get() {
        return STORAGE;
    }

    public PackageAppData acquire(String packageName) {
        PackageAppData data;
        synchronized (packageDataMap) {
            data = packageDataMap.get(packageName);
            if (data == null) {
                data = loadAppData(packageName);
            }
        }
        return data;
    }

    public void acquire(String packageName, Callback<PackageAppData> callback) {
        VUiKit.defer()
                .when(() -> acquire(packageName))
                .done(callback::callback);
    }

    private PackageAppData loadAppData(String packageName) {
        InstalledAppInfo setting = VirtualCore.get().getInstalledAppInfo(packageName, 0);
        if (setting != null) {
            PackageAppData data = new PackageAppData(XApp.getApp(), setting);
            synchronized (packageDataMap) {
                packageDataMap.put(packageName, data);
            }
            return data;
        }
        return null;
    }

    public PackageAppData acquire(ApplicationInfo appInfo) {
        PackageAppData data;
        synchronized (packageDataMap) {
            data = packageDataMap.get(appInfo.packageName);
            if (data == null) {
                data = loadAppData(appInfo);
            }
        }
        return data;
    }

    public void acquire(ApplicationInfo appInfo, Callback<PackageAppData> callback) {
        VUiKit.defer()
                .when(() -> acquire(appInfo))
                .done(callback::callback);
    }

    private PackageAppData loadAppData(ApplicationInfo appInfo) {
        PackageAppData data = new PackageAppData(XApp.getApp(), appInfo);
        synchronized (packageDataMap) {
            packageDataMap.put(appInfo.packageName, data);
        }
        return data;
    }


    /**
     * @author Lody
     */
    public static class PackageAppData extends BaseAppInfo {


        public PackageAppData(Context context, InstalledAppInfo installedAppInfo) {
            super(installedAppInfo.packageName);
            loadData(context, installedAppInfo.getApplicationInfo(installedAppInfo.getInstalledUsers()[0]));
        }

        public PackageAppData(Context context, ApplicationInfo appInfo) {
            super(appInfo.packageName);
            loadData(context, appInfo);
        }

        private void loadData(Context context, ApplicationInfo appInfo) {
            if (appInfo == null) {
                return;
            }
            PackageManager pm = context.getPackageManager();
            try {
                CharSequence sequence = appInfo.loadLabel(pm);
                name = sequence.toString();
                icon = appInfo.loadIcon(pm);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }
}
