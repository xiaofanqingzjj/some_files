package io.virtualapp.utils

import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import io.virtualapp.XApp


object PreferenceUtils {

    private var sharedPreferences: SharedPreferences =
        PreferenceManager.getDefaultSharedPreferences(XApp.getApp())

    fun getBoolean(key: String, defValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(key, defValue)
    }
}