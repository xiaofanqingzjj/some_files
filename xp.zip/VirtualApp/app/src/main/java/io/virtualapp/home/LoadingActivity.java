package io.virtualapp.home;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.lody.virtual.client.core.VirtualCore;
import com.lody.virtual.client.env.Constants;
import com.lody.virtual.client.ipc.VActivityManager;
import com.lody.virtual.helper.utils.VLog;

import java.util.List;
import java.util.Locale;

import io.virtualapp.R;
import io.virtualapp.abs.ui.VUiKit;
import io.virtualapp.home.repo.PackageAppDataStorage;
import io.virtualapp.widgets.LoadingView;

/**
 * @author Lody
 */

public class LoadingActivity extends Activity {

    private static final String TAG = "LoadingActivity";

    private PackageAppDataStorage.PackageAppData appModel;
    private LoadingView loadingView;

    private long start;

    public static boolean launch(Context context, String packageName, int userId) {
        Intent appLaunchIntent = VirtualCore.get().getLaunchIntent(packageName, userId);
        if (appLaunchIntent != null) {
            Intent loadingPageIntent = new Intent(context, LoadingActivity.class);
            loadingPageIntent.putExtra(Constants.PASS_PKG_NAME_ARGUMENT, packageName);
            loadingPageIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            loadingPageIntent.putExtra(Constants.PASS_KEY_INTENT, appLaunchIntent);
            loadingPageIntent.putExtra(Constants.PASS_KEY_USER, userId);
            context.startActivity(loadingPageIntent);
            return true;
        } else {
            return false;
        }
    }


    /**
     * 判断对应的app进程是否已经启动
     */
    private static boolean isAppIsRunning(Context context, String packageName, int userId) {
        try {
            // 如果已经在运行了，那么直接拉起，不做任何检测。

            boolean uiRunning = false;
            ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
                for (ActivityManager.RunningAppProcessInfo runningAppProcess : runningAppProcesses) {
                    String appProcessName = VActivityManager.get().getAppProcessName(runningAppProcess.pid);
                    if (TextUtils.equals(appProcessName, packageName)) {
                        uiRunning = true;
                        break;
                    }
                }
            }

            if (uiRunning) {
                // 如果检测到包名已启动，再检查一次对应的分身是否已经启动
                uiRunning = VActivityManager.get().isAppRunning(packageName, userId);
            }
            return uiRunning;
        } catch (Throwable ignored) {
            ignored.printStackTrace();
        }
        return false;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        start = SystemClock.elapsedRealtime();

        int userId = getIntent().getIntExtra(Constants.PASS_KEY_USER, -1);
        String pkg = getIntent().getStringExtra(Constants.PASS_PKG_NAME_ARGUMENT);
        appModel = PackageAppDataStorage.get().acquire(pkg);

        // 未安装
        if (appModel == null) {
            Toast.makeText(getApplicationContext(), "Open App:" + pkg + " failed.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_loading);


        loadingView = findViewById(R.id.loading_view);
        loadingView.setIcon(appModel.icon);
        loadingView.setText(String.format(Locale.ENGLISH, "正在打开 %s...", appModel.name));


        Intent appLaunchIntent = getIntent().getParcelableExtra(Constants.PASS_KEY_INTENT);
        if (appLaunchIntent == null) {
            finish();
            return;
        }

        // 监听app的启动过程
        VirtualCore.get().setUiCallback(appLaunchIntent, mUiCallback);

        // 如果app已经启动，执行热启动
        if (isAppIsRunning(this, pkg, userId)) {
            Log.d(TAG,"isAppIsRunning:" + pkg + ", userId:" + userId);
            launchActivity(appLaunchIntent, userId);
            return;
        }

        Log.d(TAG,"launchActivityWithDelay");

        // 冷启动
        launchActivityWithDelay(appLaunchIntent, userId);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VLog.e(TAG, "onDestroy");
    }

    private void launchActivityWithDelay(Intent intent, int userId) {
        final int MAX_WAIT = 500;
        long delta = SystemClock.elapsedRealtime() - start;
        long waitTime = MAX_WAIT - delta;

        if (waitTime <= 0) {
            launchActivity(intent, userId);
        } else {
            loadingView.postDelayed(() -> launchActivity(intent, userId), waitTime);
        }
    }

    private void launchActivity(Intent intent, int userId) {
        try {
            VActivityManager.get().startActivity(intent, userId);
        } catch (Throwable e) {
            VLog.e(TAG, "start activity failed:", e);
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.start_app_failed, appModel.name), Toast.LENGTH_SHORT).show();
            finish();
        }
    }


    private final VirtualCore.UiCallback mUiCallback = new VirtualCore.UiCallback() {

        @Override
        public void onAppOpened(String packageName, int userId) throws RemoteException {
            VLog.d(TAG, "onAppOpened packageName:" + packageName + ", userId:" + userId);
            finish();
        }

        @Override
        public void onOpenFailed(String packageName, int userId) throws RemoteException {
            VLog.d(TAG, "onOpenFailed packageName:" + packageName + ", userId:" + userId);
            VUiKit.defer().when(() -> {
            }).done((v) -> {
                if (!isFinishing()) {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.start_app_failed, packageName),
                            Toast.LENGTH_SHORT).show();
                }
            });

            finish();
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        VLog.w(TAG, "onResume");
        startAnim();
    }

    @Override
    protected void onPause() {
        super.onPause();
        VLog.w(TAG, "onPause");
    }

    private void startAnim() {
        if (loadingView != null) {
            loadingView.startAnim();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        VLog.w(TAG, "onStop");
        if (loadingView != null) {
            loadingView.stopAnim();
        }
    }
}
