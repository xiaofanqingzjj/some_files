package io.virtualapp.home.myhome

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.text.InputType
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import com.lody.virtual.client.core.VirtualCore
import com.lody.virtual.client.hook.utils.Utils
import com.lody.virtual.client.ipc.VActivityManager
import com.lody.virtual.helper.utils.VLog
import com.lody.virtual.server.pm.VAppManager
import io.virtualapp.R
import io.virtualapp.abs.ui.VUiKit
import io.virtualapp.home.models.AppInfo
import io.virtualapp.sys.Installd
import io.virtualapp.sys.InstallerActivity
import io.virtualapp.widgets.LoadingDialog
import java.util.concurrent.Callable


object AppContextMenuHelper {

    private const val TAG = "AppContextMenuHelper"



    private fun toast(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun showContextMenu(appManageInfo: HomeAppItem?, anchor: View) {
        if (appManageInfo == null) {
            return
        }
        val context = anchor.context

        val popupMenu = PopupMenu(context, anchor)
        popupMenu.inflate(R.menu.app_manage_menu)

        val baseAppInfo = appManageInfo.baseAppInfo ?: return

        popupMenu.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.action_uninstall -> {
                    confirm(context, "确认卸载${baseAppInfo.name}吗？") {
                        VUiKit.defer().`when` {
                            VAppManager.get()
                                .uninstallPackageAsUser(baseAppInfo.packageName, appManageInfo.userId)
                        }.done {
                            toast(context, "卸载成功")
                        }
                    }
                }

                R.id.action_delete_data -> {
                    confirm(context, "清空数据将会清楚app下所有的数据，你要确定吗？") {
                        VUiKit.defer().`when` {
                            VAppManager.get()
                                .clearPackageAsUser(appManageInfo.userId, baseAppInfo.packageName)
                        }.done {
                            toast(context, "数据已经清空")
                        }
                    }
                }

                R.id.action_reintall -> {
                    confirm(context, "确认重新安装${baseAppInfo.name}吗？") {
                        val loadingDialog = LoadingDialog(context).show("正在安装...")
                        VUiKit.defer().`when`(Callable {
                            val packageName = baseAppInfo.packageName ?: return@Callable null
                            val path = VirtualCore.get().getOutsideApkPath(packageName)
                            VLog.d(TAG, "apkPath:$path")
                            if (path == null) {
                                Toast.makeText(context, "未找到安装包", Toast.LENGTH_SHORT).show()
                                return@Callable null
                            }

                            val appInfoLite = AppInfo(
                                packageName = baseAppInfo.packageName,
                                path = path,
                                disableMultiVersion = true)
                            val result = Installd.installApp(appInfoLite)
                            VLog.d(TAG, "install result:$result")
                            result
                        }).done {
                            loadingDialog.dismiss()
                            if (it == null) {
                                toast(context, "未找到安装包")
                                return@done
                            }
                            if (it.isSuccess) {
                                toast(context, "安装成功")
                            } else {
                                toast(context, it.error)
                            }
                        }
                    }
                }

                R.id.action_kill_app -> {
                    VUiKit.defer().`when` {
                        VActivityManager.get().killAppByPkg(baseAppInfo.packageName, appManageInfo.userId)
                    }.done {
                        toast(context, "程序已关闭")
                    }
                }

                R.id.action_copy_app -> {
                    showNumberInputDialog(context) {
                        val appInfoLite =
                            AppInfo(
                                baseAppInfo.packageName,
                                baseAppInfo.path,
                                name = baseAppInfo.name
                            )

                        // 复制it个appInfoLite
                        val appList = mutableListOf<AppInfo>()
                        for (i in 0 until it) {
                            appList.add(appInfoLite.clone())
                        }
                        InstallerActivity.startInstallerActivity(
                            context, appList as ArrayList<AppInfo>?
                        )
                    }


                }

            }
            false
        }
        popupMenu.show()
    }

    private fun showNumberInputDialog(context: Context, callback: (Int) -> Unit) {
        // 创建一个 EditText 作为输入框
        val input = EditText(context)
        input.setText("1")

        input.inputType = InputType.TYPE_CLASS_NUMBER
        val contentView = FrameLayout(context).apply {
            addView(
                input, ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            val padding = Utils.dip2px(context, 10f)
            setPadding(padding, 0, padding, 0)
        }

        input.setSelection(input.text.length)


        // 创建并显示对话框
        AlertDialog.Builder(context)
            .setTitle("复制多个App")
            .setMessage("输入要复制的分身数量：")
            .setView(contentView)
            .setPositiveButton("确定") { _, _ ->
                val inputText = input.text.toString()
                if (inputText.isNotEmpty()) {
                    val number = inputText.toInt()
                    callback.invoke(number)
                } else {
                    Toast.makeText(
                        context,
                        "未输入任何数字",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton(
                "取消"
            ) { dialog, _ -> dialog.cancel() }
            .show()
    }


    private fun confirm(context: Context, msg: String, confirm: () -> Unit) {
        val alertDialog = AlertDialog.Builder(context).setTitle(android.R.string.dialog_alert_title)
            .setMessage(msg)
            .setPositiveButton(android.R.string.yes) { _: DialogInterface?, _: Int ->
                confirm.invoke()
            }.setNegativeButton(android.R.string.no, null).create()
        alertDialog.show()
    }


}