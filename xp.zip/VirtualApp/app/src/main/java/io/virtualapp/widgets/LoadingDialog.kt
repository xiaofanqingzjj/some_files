package io.virtualapp.widgets

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import io.virtualapp.R


class LoadingDialog(context: Context) {

    private var loadingDialog: AlertDialog? = null

    private var text: TextView

    init {
        // 使用 LayoutInflater 加载自定义布局
        val inflater: LayoutInflater = LayoutInflater.from(context)
        val dialogView: View = inflater.inflate(R.layout.view_loading, null)
        text = dialogView.findViewById(R.id.tv_loading_text)

        // 创建 AlertDialog
        val builder: AlertDialog.Builder = AlertDialog.Builder(context, android.R.style.Theme_Panel)
        builder.setView(dialogView)
        builder.setCancelable(false)
        loadingDialog = builder.create()
    }

    fun show(text: String? = null): LoadingDialog {
        loadingDialog?.show()
        text?.let {
            this.text.text = it
        }
        return this
    }

    fun dismiss(): LoadingDialog {
        loadingDialog?.dismiss()
        return this
    }

}