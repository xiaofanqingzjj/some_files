package com.tencent.da

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.lody.virtual.client.ipc.VActivityManager
import com.lody.virtual.helper.utils.VLog
import io.virtualapp.R
import io.virtualapp.home.LoadingActivity
import io.virtualapp.splash.BaseSplashActivity

/**
 * 通过intent用户界面对外提供一定的操作接口。
 *
 * 通过intent的参数来控制VA，比如启动某个应用，关闭个应用，关闭所有应用等。
 *
 *
 * cmd:
 *  start
 *       userId 0
 *       packageName 'com.tencent.wework'
 *  kill
 *      userId 0
 *      packageName 'com.tencent.wework'
 *  killAll
 *
 * 下面是一个例子，启动userId为0下的企业微信：
 *  adb shell am start -n com.tencent.mulapp/com.tencent.da.AdbCommandActivity -e cmd start -e userId 0 -e packageName 'com.tencent.wework'
 */
class AdbCommandActivity : BaseSplashActivity() {

    companion object {
        private const val TAG = "AppLaunchActivity"

        const val PARAM_CMD = "cmd"
        const val PARAM_USER_ID = "userId"
        const val PARAM_PACKAGE_NAME = "packageName"

        const val CMD_START = "start"
        const val CMD_KILL = "kill"
        const val CMD_KILL_ALL = "killAll"
    }

    private var cmd: String? = null

    private var userId: Int = 0
    private var mPackageName: String? = null

    private var handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cmd = intent.getStringExtra(PARAM_CMD)
        userId = intent.getStringExtra(PARAM_USER_ID)?.toIntOrNull() ?: 0
        mPackageName = intent.getStringExtra(PARAM_PACKAGE_NAME)

        VLog.d(TAG, "cmd:$cmd packageNam: $mPackageName, userId: $userId")

        if (cmd.isNullOrEmpty()) {
            VLog.e(TAG, "cmd is null or empty")
            toast("cmd is null or empty")
            finish()
            return
        }

        setContentView(R.layout.activity_adb_command)
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        VLog.d(TAG, "onDestroy")
    }

    override fun onDone() {
        super.onDone()
        when (cmd) {
            CMD_START -> {
                val packageName = mPackageName
                if (packageName.isNullOrEmpty()) {
                    VLog.e(TAG, "packageName is null or empty")
                    toast("packageName is null or empty")
                    finish()
                    return
                }

                LoadingActivity.launch(
                    applicationContext,
                    packageName,
                    userId)
            }
            CMD_KILL -> {
                val packageName = mPackageName
                if (packageName.isNullOrEmpty()) {
                    VLog.e(TAG, "packageName is null or empty")
                    toast("packageName is null or empty")
                    finish()
                    return
                }
                VActivityManager.get().killAppByPkg(packageName, userId)
                handler.postDelayed({
                    finish()
                }, 100)
            }
            CMD_KILL_ALL -> {
                VActivityManager.get().killAllApps()
                handler.postDelayed({
                    finish()
                }, 100)
            }
            else -> {
                VLog.e(TAG, "unknown cmd: $cmd")
                toast("unknown cmd: $cmd")
                finish()
            }
        }
    }
}